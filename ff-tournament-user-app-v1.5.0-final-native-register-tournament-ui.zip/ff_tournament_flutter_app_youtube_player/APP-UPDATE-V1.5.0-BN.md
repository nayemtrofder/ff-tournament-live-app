# FF Tournament User App v1.5.0

এই source ZIPটি **বর্তমান app source** ধরে তৈরি। আগের Native Buy Gold, Wallet-এর `৳ BDT` Winning Balance, Home, Leaderboard, Live, Video, Notification এবং Host Live flow রাখা হয়েছে।

## এই update-এ যা যোগ/পরিবর্তন হয়েছে

### 1. Native Registration
- Login screen-এ `CREATE NEW ACCOUNT` যোগ হয়েছে।
- Username, Mobile Number অথবা Email, Password ও Confirm Password দিয়ে account তৈরি করা যায়।
- Account Website/WordPress-এই তৈরি হয়; App নিজের কোনো database ব্যবহার করে না।
- Register সফল হলে auto login হয় এবং existing Game Profile screen খুলে।
- FF UID ও IGN save না করলে Website-এর join rule অনুযায়ী tournament join হবে না।

> এই feature চালাতে Website-এ **FF Tournament Live Bridge v1.8.0** active থাকতে হবে।

### 2. Tournament Browser
- API-এর real tournament data দিয়ে `All / Live / Upcoming / Completed / Cancelled` filter আছে।
- `All modes / Solo / Duo / Squad` filter এবং title search আছে।
- Card-এ শুধু API-এর real banner, title, mode, entry Gold, prize, joined/slot, schedule এবং status দেখায়।
- `JOIN NOW` শুধু server `can_join=true` দিলে দেখা যায়। Join করলে Website-এর Gold hold rule চলবে।

### 3. My Matches
- Existing bottom navigation রাখা হয়েছে; আলাদা Scaffold বা duplicate navigation যোগ করা হয়নি।
- `Upcoming / Live / Completed / Cancelled` status tab আছে।
- Joined match-এর Room access hint শুধু room data API-তে থাকলে দেখা যাবে।
- Rank, kills ও credited prize শুধু result data API-তে থাকলে দেখা যাবে।
- কোনো fake refund, winner বা live URL যোগ করা হয়নি।

### 4. Profile / Wallet
- Profile-এ existing real-data layout রাখা হয়েছে:
  - এক Gold Wallet summary
  - এক Buy Gold action
  - Player Stats, Account info, Notifications, App Update, Host control
- Duplicate Gold option যোগ করা হয়নি।
- Wallet-এর Winning Balance আগের মতো `৳ BDT` format-এ আছে।

## যেগুলো এই batch-এ বদলানো হয়নি
- Home screen
- Leaderboard screen
- Native Buy Gold page
- Website payment/admin approval rules
- Withdraw enable/approval system
- WordPress Main Plugin ও Bridge API logic

## Codespaces-এ install করার আগে

```bash
flutter pub get
flutter analyze
flutter test
flutter build apk --release --dart-define=FFTS_API_BASE_URL=https://fftrustbd.com/wp-json/ffts-app/v1
```

## Changed files

- `lib/core/api_client.dart`
- `lib/core/app_state.dart`
- `lib/screens/login_screen.dart`
- `lib/screens/register_screen.dart` (new)
- `lib/screens/tournaments_screen.dart`
- `lib/screens/my_matches_screen.dart`
- `lib/widgets/compact_tournament_card.dart` (new)
- `test/my_matches_screen_test.dart`
- `pubspec.yaml`
