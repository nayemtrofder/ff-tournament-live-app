# Current FF Tournament User App Source

এই source হলো current Flutter project-এর updated version।

## Existing features retained

- Native Buy Gold: Website-controlled packages, payment methods, order status
- Wallet: Available Gold, Held Gold, Winning Balance in `৳ BDT`
- Home, Live stream, Leaderboard, Videos, Notifications, Like, Comment
- Tournament detail, Gold hold join flow, Profile Edit, Host Live Control
- MainShell bottom navigation: Home, Tournaments, Leaderboard, My Matches, Profile

## v1.5.0 update

- Native player registration through Bridge v1.8.0
- Compact real-data Tournament browser with search and status/mode filters
- Stable compact My Matches card layout with status filters, room/result hints
- Existing Profile Gold summary + one Buy Gold action retained without duplicates

See `APP-UPDATE-V1.5.0-BN.md` for the full change list and Codespaces build steps.
