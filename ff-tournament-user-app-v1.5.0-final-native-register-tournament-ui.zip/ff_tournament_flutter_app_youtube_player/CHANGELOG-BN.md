# Changelog

## v1.2.0 — YouTube In‑App Player

- `youtube_player_iframe` v6.0.2 dependency যোগ করা হয়েছে।
- নতুন `YouTubePlayerScreen` যোগ করা হয়েছে।
- `LiveWatchScreen`-এর Watch button এখন browser/YouTube app না খুলে app-এর ভিতরের player page খোলে।
- Home highlight card এবং Replays & Highlights page এখন app-এর ভিতরেই YouTube video চালায়।
- YouTube watch, short, live, shorts, embed URL এবং direct video ID validate করা হয়।
- Non-YouTube/invalid URL external open করা হয় না; clear error দেখানো হয়।
- 200px minimum player viewport রাখা হয়েছে এবং YouTube controls/fullscreen দৃশ্যমান রাখা হয়েছে।
- কোনো demo video, fake video URL বা local fallback যোগ করা হয়নি।

## v1.5.0 — Native Registration + Tournament App Flow

- Bridge v1.8.0 supported native Register + auto login flow added.
- Tournament tab updated with real-data search, status filters and mode filters.
- My Matches card layout rebuilt for narrow Android devices.
- Current Native Buy Gold, Wallet BDT and Profile Gold cleanup retained.
