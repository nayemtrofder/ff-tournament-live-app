import 'dart:async';
import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../core/app_theme.dart';
import '../core/formatters.dart';
import '../models/live_session.dart';
import '../models/tournament.dart';
import 'common.dart';

class HeroSlideData {
  const HeroSlideData({
    required this.id,
    required this.title,
    required this.subtitle,
    required this.status,
    required this.prize,
    required this.icon,
    required this.accent,
    required this.buttonLabel,
    this.thumbnailUrl = '',
    this.onTap,
    this.isLive = false,
  });
  /// Stable identity used to detect a newly-prioritized live slide.
  final String id;
  final String title;
  final String subtitle;
  final String status;
  final String prize;
  final IconData icon;
  final Color accent;
  final String buttonLabel;
  final String thumbnailUrl;
  final VoidCallback? onTap;
  final bool isLive;

  factory HeroSlideData.live(LiveSession live, VoidCallback? onTap) => HeroSlideData(
        id: 'live:${live.matchId}:${live.status}:${live.bestWatchUrl}',
        title: live.match?.title.isNotEmpty == true ? live.match!.title : live.title,
        subtitle: 'Live leaderboard এখনই পরিবর্তন হচ্ছে',
        status: 'LIVE NOW',
        prize: live.match?.prize.isNotEmpty == true ? live.match!.prize : 'Watch live',
        icon: Icons.play_circle_fill_rounded,
        accent: AppColors.red,
        buttonLabel: 'WATCH LIVE',
        thumbnailUrl: live.match?.bannerUrl.isNotEmpty == true ? live.match!.bannerUrl : (live.match?.thumbnailUrl ?? ''),
        onTap: onTap,
        isLive: true,
      );

  factory HeroSlideData.tournament(Tournament tournament, VoidCallback? onTap) => HeroSlideData(
        id: 'tournament:${tournament.id}:${tournament.status}',
        title: tournament.title,
        subtitle: '${tournament.mode.toUpperCase()} • ${conciseDate(tournament.startAt, tournament.matchDate, tournament.matchTime)}',
        status: tournament.statusLabel,
        prize: tournament.prize.isNotEmpty ? tournament.prize : goldText(tournament.entryGold),
        icon: Icons.emoji_events_rounded,
        accent: tournament.isLive ? AppColors.red : AppColors.orange,
        buttonLabel: tournament.isLive ? 'VIEW MATCH' : 'JOIN NOW',
        thumbnailUrl: tournament.bannerUrl.isNotEmpty ? tournament.bannerUrl : tournament.thumbnailUrl,
        onTap: onTap,
      );
}

class HeroCarousel extends StatefulWidget {
  const HeroCarousel({super.key, required this.items});
  final List<HeroSlideData> items;

  @override
  State<HeroCarousel> createState() => _HeroCarouselState();
}

class _HeroCarouselState extends State<HeroCarousel> {
  late final PageController _controller;
  Timer? _timer;
  int _page = 0;

  @override
  void initState() {
    super.initState();
    _controller = PageController(viewportFraction: .92);
    _startTimer();
  }

  @override
  void didUpdateWidget(covariant HeroCarousel oldWidget) {
    super.didUpdateWidget(oldWidget);
    final oldFirst = oldWidget.items.isEmpty ? '' : oldWidget.items.first.id;
    final newFirst = widget.items.isEmpty ? '' : widget.items.first.id;
    final hasNewPriorityFirstSlide = oldFirst != newFirst;

    if (widget.items.length != oldWidget.items.length && _page >= widget.items.length) {
      _page = 0;
    }

    // A live item is inserted at index 0 by Home. Move users to it immediately
    // instead of waiting for the normal carousel timer.
    if (hasNewPriorityFirstSlide && widget.items.isNotEmpty) {
      _page = 0;
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (!mounted || !_controller.hasClients) return;
        _controller.animateToPage(0, duration: const Duration(milliseconds: 320), curve: Curves.easeOutCubic);
      });
    }
  }

  void _startTimer() {
    _timer?.cancel();
    _timer = Timer.periodic(const Duration(seconds: 5), (_) {
      if (!mounted || widget.items.length < 2) return;
      _page = (_page + 1) % widget.items.length;
      _controller.animateToPage(_page, duration: const Duration(milliseconds: 480), curve: Curves.easeOutCubic);
    });
  }

  @override
  void dispose() {
    _timer?.cancel();
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (widget.items.isEmpty) return const SizedBox.shrink();
    return Column(
      children: [
        SizedBox(
          height: 205,
          child: PageView.builder(
            controller: _controller,
            itemCount: widget.items.length,
            onPageChanged: (index) => setState(() => _page = index),
            itemBuilder: (context, index) => Padding(
              padding: const EdgeInsets.only(right: 10),
              child: _HeroSlide(item: widget.items[index]),
            ),
          ),
        ),
        const SizedBox(height: 10),
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: List.generate(widget.items.length, (index) => AnimatedContainer(
            duration: const Duration(milliseconds: 220),
            margin: const EdgeInsets.symmetric(horizontal: 3),
            width: _page == index ? 19 : 6,
            height: 6,
            decoration: BoxDecoration(
              color: _page == index ? AppColors.orange : AppColors.border,
              borderRadius: BorderRadius.circular(10),
            ),
          )),
        ),
      ],
    );
  }
}

class _HeroSlide extends StatefulWidget {
  const _HeroSlide({required this.item});
  final HeroSlideData item;

  @override
  State<_HeroSlide> createState() => _HeroSlideState();
}

class _HeroSlideState extends State<_HeroSlide> with TickerProviderStateMixin {
  late final AnimationController _glowController;
  late final AnimationController _pressController;
  bool _pressed = false;

  @override
  void initState() {
    super.initState();
    _glowController = AnimationController(vsync: this, duration: const Duration(milliseconds: 1600));
    _pressController = AnimationController(vsync: this, duration: const Duration(milliseconds: 120));
    if (widget.item.isLive) {
      _glowController.repeat(reverse: true);
    }
  }

  @override
  void didUpdateWidget(covariant _HeroSlide oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.item.isLive != widget.item.isLive) {
      if (widget.item.isLive) {
        _glowController.repeat(reverse: true);
      } else {
        _glowController.stop(canceled: false);
        _pressController.stop(canceled: false);
        if (mounted) {
          setState(() => _pressed = false);
        }
      }
    }
  }

  @override
  void dispose() {
    _glowController.dispose();
    _pressController.dispose();
    super.dispose();
  }

  void _handleTapDown(TapDownDetails _) {
    if (!widget.item.isLive) return;
    setState(() => _pressed = true);
    _pressController.forward();
  }

  void _handleTapUp(TapUpDetails _) {
    if (!widget.item.isLive) return;
    setState(() => _pressed = false);
    _pressController.reverse();
  }

  void _handleTapCancel() {
    if (!widget.item.isLive) return;
    setState(() => _pressed = false);
    _pressController.reverse();
  }

  @override
  Widget build(BuildContext context) {
    final live = widget.item.isLive;
    return InkWell(
      onTap: widget.item.onTap,
      onTapDown: live ? _handleTapDown : null,
      onTapUp: live ? _handleTapUp : null,
      onTapCancel: live ? _handleTapCancel : null,
      borderRadius: BorderRadius.circular(26),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 260),
        clipBehavior: Clip.antiAlias,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(26),
          color: AppColors.surface,
          border: Border.all(color: widget.item.accent.withValues(alpha: live ? .72 : .55)),
          boxShadow: live
              ? [
                  BoxShadow(
                    color: widget.item.accent.withValues(alpha: .18),
                    blurRadius: 22,
                    spreadRadius: 1.6,
                  ),
                ]
              : null,
        ),
        child: Stack(
          fit: StackFit.expand,
          children: [
            if (widget.item.thumbnailUrl.isNotEmpty)
              Image.network(widget.item.thumbnailUrl, fit: BoxFit.cover, errorBuilder: (_, __, ___) => const SizedBox.shrink()),
            DecoratedBox(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [
                    widget.item.accent.withValues(alpha: live ? .46 : .43),
                    AppColors.surface.withValues(alpha: .78),
                    AppColors.bg,
                  ],
                ),
              ),
            ),
            if (live)
              Positioned.fill(
                child: ClipRect(
                  child: AnimatedBuilder(
                    animation: _glowController,
                    builder: (context, child) {
                      final offset = Tween<double>(begin: -1.35, end: 1.35).transform(_glowController.value);
                      return Transform.translate(
                        offset: Offset(offset * 220, 0),
                        child: FractionallySizedBox(
                          widthFactor: .35,
                          child: Container(
                            decoration: BoxDecoration(
                              gradient: LinearGradient(
                                begin: Alignment.centerLeft,
                                end: Alignment.centerRight,
                                colors: [
                                  Colors.transparent,
                                  Colors.white.withValues(alpha: .16),
                                  Colors.transparent,
                                ],
                              ),
                            ),
                          ),
                        ),
                      );
                    },
                  ),
                ),
              ),
            Positioned(
              right: -28,
              bottom: -33,
              child: AnimatedBuilder(
                animation: _glowController,
                builder: (context, child) {
                  final pulse = live ? 0.94 + 0.06 * math.sin(_glowController.value * math.pi * 2) : 1.0;
                  return Transform.scale(
                    scale: pulse,
                    child: Icon(widget.item.icon, size: 178, color: Colors.white.withValues(alpha: live ? .12 : .10)),
                  );
                },
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(19),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(children: [
                    if (live)
                      AnimatedBuilder(
                        animation: _glowController,
                        builder: (context, child) {
                          final pulse = 0.84 + 0.16 * (0.5 + 0.5 * math.sin(_glowController.value * math.pi * 2));
                          return Container(
                            padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 6),
                            decoration: BoxDecoration(
                              color: AppColors.red.withValues(alpha: .16 + pulse * .05),
                              borderRadius: BorderRadius.circular(20),
                              border: Border.all(color: AppColors.orange.withValues(alpha: .7)),
                              boxShadow: [
                                BoxShadow(color: AppColors.red.withValues(alpha: live ? .23 : 0), blurRadius: 10 + pulse * 8, spreadRadius: 1),
                              ],
                            ),
                            child: Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                AnimatedContainer(
                                  duration: const Duration(milliseconds: 420),
                                  width: 6,
                                  height: 6,
                                  decoration: BoxDecoration(
                                    color: AppColors.red.withValues(alpha: pulse),
                                    shape: BoxShape.circle,
                                    boxShadow: [
                                      BoxShadow(color: AppColors.orange.withValues(alpha: pulse * .6), blurRadius: 6),
                                    ],
                                  ),
                                ),
                                const SizedBox(width: 5),
                                Text(widget.item.status.toUpperCase(), style: const TextStyle(color: AppColors.red, fontWeight: FontWeight.w900, fontSize: 10, letterSpacing: .65)),
                              ],
                            ),
                          );
                        },
                      )
                    else
                      StatusBadge(status: widget.item.status),
                    const Spacer(),
                    AnimatedBuilder(
                      animation: _glowController,
                      builder: (context, child) {
                        final pulse = live ? 1.0 - 0.06 * (0.5 + 0.5 * math.sin(_glowController.value * math.pi * 2)) : 1.0;
                        return Transform.scale(
                          scale: pulse,
                          child: const Icon(Icons.bolt_rounded, color: AppColors.gold, size: 20),
                        );
                      },
                    ),
                  ]),
                  const Spacer(),
                  Text(widget.item.title, maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w900, height: 1.05, letterSpacing: -.5)),
                  const SizedBox(height: 7),
                  Text(widget.item.subtitle, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: AppColors.muted, fontWeight: FontWeight.w600)),
                  const SizedBox(height: 10),
                  Row(
                    children: [
                      Expanded(child: GoldPill(value: widget.item.prize, compact: true)),
                      const SizedBox(width: 10),
                      AnimatedBuilder(
                        animation: Listenable.merge([_glowController, _pressController]),
                        builder: (context, child) {
                          final glow = live ? 0.22 + 0.1 * (0.5 + 0.5 * math.sin(_glowController.value * math.pi * 2)) : 0.0;
                          final scale = live ? (1.0 - (_pressed ? 0.03 : 0.0) + (_pressController.value * 0.0)) : 1.0;
                          return Transform.scale(
                            scale: scale,
                            child: Container(
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(15),
                                boxShadow: live
                                    ? [
                                        BoxShadow(
                                          color: widget.item.accent.withValues(alpha: glow * 0.8),
                                          blurRadius: 12 + glow * 8,
                                          spreadRadius: 1.2,
                                        ),
                                      ]
                                    : null,
                              ),
                              child: FilledButton(
                                onPressed: widget.item.onTap,
                                style: FilledButton.styleFrom(backgroundColor: widget.item.accent, foregroundColor: Colors.white, padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 9)),
                                child: Text(widget.item.buttonLabel, style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w900)),
                              ),
                            ),
                          );
                        },
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
