import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../core/api_client.dart';
import '../core/app_state.dart';
import '../core/app_theme.dart';
import '../core/formatters.dart';
import '../models/tournament.dart';
import '../models/tournament_interaction.dart';
import 'common.dart';

class TournamentCard extends StatelessWidget {
  const TournamentCard({super.key, required this.tournament, this.onTap, this.compact = false});
  final Tournament tournament;
  final VoidCallback? onTap;
  final bool compact;

  @override
  Widget build(BuildContext context) {
    final image = tournament.bannerUrl.isNotEmpty ? tournament.bannerUrl : tournament.thumbnailUrl;
    final showInteractions = tournament.interactions.likesEnabled || tournament.interactions.commentsEnabled || tournament.interactions.showViewCount;
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(22),
      child: Container(
        height: compact ? 172 : 216,
        clipBehavior: Clip.antiAlias,
        decoration: BoxDecoration(
          color: AppColors.surface,
          borderRadius: BorderRadius.circular(22),
          border: Border.all(color: tournament.isLive ? AppColors.red.withValues(alpha: .75) : AppColors.border),
        ),
        child: Stack(
          fit: StackFit.expand,
          children: <Widget>[
            if (image.isNotEmpty) Image.network(image, fit: BoxFit.cover, errorBuilder: (_, __, ___) => const SizedBox.shrink()),
            DecoratedBox(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: <Color>[
                    Colors.black.withValues(alpha: image.isNotEmpty ? .12 : .02),
                    AppColors.surface.withValues(alpha: .74),
                    AppColors.surface,
                  ],
                ),
              ),
            ),
            if (image.isEmpty)
              const Positioned(
                right: -18,
                top: -20,
                child: Icon(Icons.sports_esports_rounded, size: 150, color: AppColors.surfaceSoft),
              ),
            Padding(
              padding: const EdgeInsets.all(14),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Expanded(child: Align(alignment: Alignment.centerLeft, child: StatusBadge(status: tournament.statusLabel))),
                      const SizedBox(width: 8),
                      GoldPill(value: goldText(tournament.entryGold), compact: true),
                    ],
                  ),
                  const SizedBox(height: 10),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        Text(
                          tournament.title,
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w900, letterSpacing: -.2, height: 1.18, decoration: TextDecoration.none),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          '${tournament.mode.toUpperCase()} • ${conciseDate(tournament.startAt, tournament.matchDate, tournament.matchTime)}',
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(color: AppColors.muted, fontSize: 11, decoration: TextDecoration.none),
                        ),
                        const SizedBox(height: 8),
                        Row(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: <Widget>[
                            const Icon(Icons.workspace_premium_rounded, color: AppColors.gold, size: 16),
                            const SizedBox(width: 5),
                            Expanded(
                              child: Text(
                                tournament.prize.isNotEmpty ? tournament.prize : 'Prize announced soon',
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                                style: const TextStyle(color: AppColors.gold, fontWeight: FontWeight.w800, fontSize: 12, decoration: TextDecoration.none),
                              ),
                            ),
                            const SizedBox(width: 6),
                            Text('${tournament.joined}/${tournament.slots}', style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 12, decoration: TextDecoration.none)),
                          ],
                        ),
                        if (showInteractions) ...<Widget>[
                          const SizedBox(height: 8),
                          _InteractionRow(tournament: tournament),
                        ],
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _InteractionRow extends StatefulWidget {
  const _InteractionRow({required this.tournament});
  final Tournament tournament;

  @override
  State<_InteractionRow> createState() => _InteractionRowState();
}

class _InteractionRowState extends State<_InteractionRow> {
  late TournamentInteractions _interactions;
  bool _liking = false;

  @override
  void initState() {
    super.initState();
    _interactions = widget.tournament.interactions;
  }

  @override
  void didUpdateWidget(covariant _InteractionRow oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.tournament.id != widget.tournament.id || oldWidget.tournament.interactions.likeCount != widget.tournament.interactions.likeCount || oldWidget.tournament.interactions.userHasLiked != widget.tournament.interactions.userHasLiked) {
      _interactions = widget.tournament.interactions;
    }
  }

  Future<void> _toggleLike() async {
    if (_liking || !_interactions.likesEnabled) return;
    final state = context.read<AppState>();
    if (!state.isLoggedIn) {
      showAppMessage(context, 'Like করতে আগে Login করুন।', error: true);
      return;
    }
    setState(() => _liking = true);
    try {
      final next = await state.api.toggleTournamentLike(widget.tournament.id);
      if (!mounted) return;
      setState(() => _interactions = next);
      showAppMessage(context, next.userHasLiked ? 'Tournament liked.' : 'Like removed.');
    } on ApiException catch (error) {
      if (mounted) showAppMessage(context, error.message, error: true);
    } finally {
      if (mounted) setState(() => _liking = false);
    }
  }

  @override
  Widget build(BuildContext context) => Row(
        children: <Widget>[
          if (_interactions.showViewCount) _CountChip(icon: Icons.visibility_outlined, value: '${_interactions.viewCount}'),
          if (_interactions.showViewCount && _interactions.likesEnabled) const SizedBox(width: 7),
          if (_interactions.likesEnabled)
            _CountChip(
              icon: _liking ? Icons.hourglass_top_rounded : (_interactions.userHasLiked ? Icons.favorite_rounded : Icons.favorite_border_rounded),
              value: '${_interactions.likeCount}',
              active: _interactions.userHasLiked,
              onTap: _liking ? null : _toggleLike,
            ),
          if ((_interactions.showViewCount || _interactions.likesEnabled) && _interactions.commentsEnabled) const SizedBox(width: 7),
          if (_interactions.commentsEnabled) _CountChip(icon: Icons.chat_bubble_outline_rounded, value: '${_interactions.commentCount}'),
        ],
      );
}

class _CountChip extends StatelessWidget {
  const _CountChip({required this.icon, required this.value, this.active = false, this.onTap});
  final IconData icon;
  final String value;
  final bool active;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    final chip = Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 5),
      decoration: BoxDecoration(
        color: Colors.black.withValues(alpha: .18),
        border: Border.all(color: active ? AppColors.red.withValues(alpha: .65) : AppColors.border.withValues(alpha: .7)),
        borderRadius: BorderRadius.circular(99),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: <Widget>[
          Icon(icon, size: 14, color: active ? AppColors.red : AppColors.muted),
          const SizedBox(width: 4),
          Text(value, style: TextStyle(color: active ? AppColors.red : AppColors.muted, fontSize: 11, fontWeight: FontWeight.w800, decoration: TextDecoration.none)),
        ],
      ),
    );
    if (onTap == null) return chip;
    return GestureDetector(onTap: onTap, behavior: HitTestBehavior.opaque, child: chip);
  }
}
