import 'package:flutter/material.dart';

import '../core/app_theme.dart';
import '../core/formatters.dart';
import '../models/tournament.dart';
import 'common.dart';

/// A compact, real-data-only tournament card shared by Tournament browser and
/// My Matches. It intentionally hides fields that the API does not provide.
class CompactTournamentCard extends StatelessWidget {
  const CompactTournamentCard({
    super.key,
    required this.tournament,
    required this.onOpen,
    required this.primaryLabel,
    required this.primaryIcon,
    required this.primaryColor,
    this.onPrimary,
    this.showPlayerResult = false,
    this.showRoomHint = false,
  });

  final Tournament tournament;
  final VoidCallback onOpen;
  final String primaryLabel;
  final IconData primaryIcon;
  final Color primaryColor;
  final VoidCallback? onPrimary;
  final bool showPlayerResult;
  final bool showRoomHint;

  @override
  Widget build(BuildContext context) {
    final image = tournament.bannerUrl.isNotEmpty
        ? tournament.bannerUrl
        : tournament.thumbnailUrl;
    final hasResult = showPlayerResult &&
        tournament.isEnded &&
        (tournament.myPlacement > 0 ||
            tournament.myKills > 0 ||
            tournament.prizeCredited > 0);
    final hasRoom = showRoomHint &&
        (tournament.roomId.trim().isNotEmpty ||
            tournament.roomPassword.trim().isNotEmpty);
    final hasInteractions = tournament.interactions.showViewCount ||
        tournament.interactions.likesEnabled ||
        tournament.interactions.commentsEnabled;
    final height = 190.0 +
        (hasResult || hasRoom ? 24.0 : 0.0) +
        (hasInteractions ? 18.0 : 0.0);

    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onOpen,
        borderRadius: BorderRadius.circular(20),
        child: Container(
          height: height,
          clipBehavior: Clip.antiAlias,
          decoration: BoxDecoration(
            color: AppColors.surface,
            borderRadius: BorderRadius.circular(20),
            border: Border.all(
              color: tournament.isLive
                  ? AppColors.red.withValues(alpha: .72)
                  : AppColors.border,
            ),
            boxShadow: tournament.isLive
                ? <BoxShadow>[
                    BoxShadow(
                      color: AppColors.red.withValues(alpha: .12),
                      blurRadius: 18,
                      spreadRadius: 1,
                    ),
                  ]
                : null,
          ),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: <Widget>[
              SizedBox(
                width: 112,
                child: _CardArtwork(
                  image: image,
                  tournament: tournament,
                ),
              ),
              Expanded(
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(12, 11, 11, 11),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget>[
                          Expanded(
                            child: Text(
                              tournament.title,
                              maxLines: 2,
                              overflow: TextOverflow.ellipsis,
                              style: const TextStyle(
                                color: AppColors.text,
                                fontSize: 16,
                                height: 1.15,
                                fontWeight: FontWeight.w900,
                                decoration: TextDecoration.none,
                              ),
                            ),
                          ),
                          const SizedBox(width: 7),
                          _SlotsBadge(
                            joined: tournament.joined,
                            slots: tournament.slots,
                          ),
                        ],
                      ),
                      const SizedBox(height: 7),
                      _MetaLine(
                        icon: Icons.calendar_today_outlined,
                        text: conciseDate(
                          tournament.startAt,
                          tournament.matchDate,
                          tournament.matchTime,
                        ),
                      ),
                      const SizedBox(height: 5),
                      _MetaLine(
                        icon: Icons.workspace_premium_rounded,
                        text: '${goldText(tournament.entryGold)} • ${_prizeText(tournament.prize)}',
                        accent: AppColors.gold,
                      ),
                      if (hasInteractions) ...<Widget>[
                        const SizedBox(height: 7),
                        _InteractionStrip(tournament: tournament),
                      ],
                      if (hasResult) ...<Widget>[
                        const SizedBox(height: 8),
                        _PersonalResult(tournament: tournament),
                      ] else if (hasRoom) ...<Widget>[
                        const SizedBox(height: 8),
                        const _RoomReadyHint(),
                      ],
                      const Spacer(),
                      SizedBox(
                        width: double.infinity,
                        height: 36,
                        child: _PrimaryAction(
                          label: primaryLabel,
                          icon: primaryIcon,
                          color: primaryColor,
                          onTap: onPrimary ?? onOpen,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _CardArtwork extends StatelessWidget {
  const _CardArtwork({required this.image, required this.tournament});

  final String image;
  final Tournament tournament;

  @override
  Widget build(BuildContext context) {
    return Stack(
      fit: StackFit.expand,
      children: <Widget>[
        if (image.isNotEmpty)
          Image.network(
            image,
            fit: BoxFit.cover,
            errorBuilder: (_, __, ___) => const _ArtworkFallback(),
          )
        else
          const _ArtworkFallback(),
        DecoratedBox(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: <Color>[
                Colors.black.withValues(alpha: .03),
                Colors.black.withValues(alpha: .22),
                AppColors.bg.withValues(alpha: .88),
              ],
            ),
          ),
        ),
        Positioned(
          top: 8,
          left: 8,
          right: 8,
          child: StatusBadge(status: tournament.statusLabel),
        ),
        Positioned(
          left: 8,
          right: 8,
          bottom: 9,
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 5),
            decoration: BoxDecoration(
              color: Colors.black.withValues(alpha: .45),
              borderRadius: BorderRadius.circular(8),
              border: Border.all(color: AppColors.orange.withValues(alpha: .40)),
            ),
            child: Text(
              tournament.mode.toUpperCase(),
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              textAlign: TextAlign.center,
              style: const TextStyle(
                color: AppColors.gold,
                fontSize: 9,
                fontWeight: FontWeight.w900,
                letterSpacing: .5,
                decoration: TextDecoration.none,
              ),
            ),
          ),
        ),
      ],
    );
  }
}

class _ArtworkFallback extends StatelessWidget {
  const _ArtworkFallback();

  @override
  Widget build(BuildContext context) => const DecoratedBox(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: <Color>[Color(0xFF1B3454), AppColors.surfaceSoft],
          ),
        ),
        child: Center(
          child: Icon(
            Icons.sports_esports_rounded,
            color: AppColors.orange,
            size: 42,
          ),
        ),
      );
}

class _SlotsBadge extends StatelessWidget {
  const _SlotsBadge({required this.joined, required this.slots});

  final int joined;
  final int slots;

  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 5),
        decoration: BoxDecoration(
          color: AppColors.surfaceSoft,
          borderRadius: BorderRadius.circular(9),
          border: Border.all(color: AppColors.border),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: <Widget>[
            const Icon(Icons.groups_2_outlined, size: 13, color: AppColors.muted),
            const SizedBox(width: 3),
            Text(
              '$joined/$slots',
              style: const TextStyle(
                color: AppColors.muted,
                fontSize: 10,
                fontWeight: FontWeight.w900,
                decoration: TextDecoration.none,
              ),
            ),
          ],
        ),
      );
}

class _MetaLine extends StatelessWidget {
  const _MetaLine({
    required this.icon,
    required this.text,
    this.accent = AppColors.muted,
  });

  final IconData icon;
  final String text;
  final Color accent;

  @override
  Widget build(BuildContext context) => Row(
        children: <Widget>[
          Icon(icon, size: 14, color: accent),
          const SizedBox(width: 6),
          Expanded(
            child: Text(
              text,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: TextStyle(
                color: accent,
                fontSize: 11,
                fontWeight: FontWeight.w700,
                decoration: TextDecoration.none,
              ),
            ),
          ),
        ],
      );
}


class _InteractionStrip extends StatelessWidget {
  const _InteractionStrip({required this.tournament});

  final Tournament tournament;

  @override
  Widget build(BuildContext context) {
    final interaction = tournament.interactions;
    final values = <Widget>[
      if (interaction.showViewCount)
        _InteractionValue(
          icon: Icons.visibility_outlined,
          value: '${interaction.viewCount}',
        ),
      if (interaction.likesEnabled)
        _InteractionValue(
          icon: interaction.userHasLiked
              ? Icons.favorite_rounded
              : Icons.favorite_border_rounded,
          value: '${interaction.likeCount}',
          color: interaction.userHasLiked ? AppColors.red : AppColors.muted,
        ),
      if (interaction.commentsEnabled)
        _InteractionValue(
          icon: Icons.chat_bubble_outline_rounded,
          value: '${interaction.commentCount}',
        ),
    ];
    return Wrap(spacing: 10, runSpacing: 3, children: values);
  }
}

class _InteractionValue extends StatelessWidget {
  const _InteractionValue({
    required this.icon,
    required this.value,
    this.color = AppColors.muted,
  });

  final IconData icon;
  final String value;
  final Color color;

  @override
  Widget build(BuildContext context) => Row(
        mainAxisSize: MainAxisSize.min,
        children: <Widget>[
          Icon(icon, size: 13, color: color),
          const SizedBox(width: 4),
          Text(
            value,
            style: TextStyle(
              color: color,
              fontSize: 10,
              fontWeight: FontWeight.w800,
              decoration: TextDecoration.none,
            ),
          ),
        ],
      );
}

class _PersonalResult extends StatelessWidget {
  const _PersonalResult({required this.tournament});

  final Tournament tournament;

  @override
  Widget build(BuildContext context) => Container(
        width: double.infinity,
        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 6),
        decoration: BoxDecoration(
          color: AppColors.green.withValues(alpha: .08),
          borderRadius: BorderRadius.circular(9),
          border: Border.all(color: AppColors.green.withValues(alpha: .25)),
        ),
        child: Row(
          children: <Widget>[
            Expanded(
              child: _ResultValue(
                label: 'RANK',
                value: tournament.myPlacement > 0
                    ? '#${tournament.myPlacement}'
                    : '—',
                color: AppColors.orange,
              ),
            ),
            Expanded(
              child: _ResultValue(
                label: 'KILLS',
                value: '${tournament.myKills}',
                color: AppColors.cyan,
              ),
            ),
            Expanded(
              child: _ResultValue(
                label: 'PRIZE',
                value: tournament.prizeCredited > 0
                    ? '৳${tournament.prizeCredited.toStringAsFixed(0)}'
                    : '—',
                color: AppColors.gold,
              ),
            ),
          ],
        ),
      );
}

class _ResultValue extends StatelessWidget {
  const _ResultValue({
    required this.label,
    required this.value,
    required this.color,
  });

  final String label;
  final String value;
  final Color color;

  @override
  Widget build(BuildContext context) => Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Text(
            label,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: const TextStyle(
              color: AppColors.muted,
              fontSize: 8,
              fontWeight: FontWeight.w900,
              letterSpacing: .45,
              decoration: TextDecoration.none,
            ),
          ),
          const SizedBox(height: 2),
          Text(
            value,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: TextStyle(
              color: color,
              fontSize: 12,
              fontWeight: FontWeight.w900,
              decoration: TextDecoration.none,
            ),
          ),
        ],
      );
}

class _RoomReadyHint extends StatelessWidget {
  const _RoomReadyHint();

  @override
  Widget build(BuildContext context) => Container(
        width: double.infinity,
        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 6),
        decoration: BoxDecoration(
          color: AppColors.cyan.withValues(alpha: .08),
          borderRadius: BorderRadius.circular(9),
          border: Border.all(color: AppColors.cyan.withValues(alpha: .28)),
        ),
        child: const Row(
          children: <Widget>[
            Icon(Icons.lock_open_rounded, size: 13, color: AppColors.cyan),
            SizedBox(width: 5),
            Expanded(
              child: Text(
                'Room access is ready',
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(
                  color: AppColors.cyan,
                  fontSize: 10,
                  fontWeight: FontWeight.w800,
                  decoration: TextDecoration.none,
                ),
              ),
            ),
          ],
        ),
      );
}

class _PrimaryAction extends StatelessWidget {
  const _PrimaryAction({
    required this.label,
    required this.icon,
    required this.color,
    required this.onTap,
  });

  final String label;
  final IconData icon;
  final Color color;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) => Material(
        color: color.withValues(alpha: .15),
        borderRadius: BorderRadius.circular(10),
        child: InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(10),
          child: Container(
            alignment: Alignment.center,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(10),
              border: Border.all(color: color.withValues(alpha: .68)),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                Icon(icon, size: 16, color: color),
                const SizedBox(width: 6),
                Text(
                  label,
                  style: TextStyle(
                    color: color,
                    fontSize: 11,
                    fontWeight: FontWeight.w900,
                    letterSpacing: .3,
                    decoration: TextDecoration.none,
                  ),
                ),
              ],
            ),
          ),
        ),
      );
}

String _prizeText(String value) {
  final text = value.trim();
  return text.isEmpty ? 'Prize announced soon' : text;
}
