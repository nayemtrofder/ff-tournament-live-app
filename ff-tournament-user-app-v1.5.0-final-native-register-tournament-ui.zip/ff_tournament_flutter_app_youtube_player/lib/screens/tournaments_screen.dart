import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../core/api_client.dart';
import '../core/app_state.dart';
import '../core/app_theme.dart';
import '../models/tournament.dart';
import '../widgets/common.dart';
import '../widgets/compact_tournament_card.dart';
import 'login_screen.dart';
import 'tournament_detail_screen.dart';

enum _TournamentStatus { all, live, upcoming, completed, cancelled }

class TournamentsScreen extends StatefulWidget {
  const TournamentsScreen({super.key});

  @override
  State<TournamentsScreen> createState() => _TournamentsScreenState();
}

class _TournamentsScreenState extends State<TournamentsScreen> {
  late Future<List<Tournament>> _future;
  _TournamentStatus _status = _TournamentStatus.all;
  String _mode = 'All';
  String _query = '';

  @override
  void initState() {
    super.initState();
    _future = _loadData();
  }

  Future<List<Tournament>> _loadData() =>
      context.read<AppState>().api.getTournaments(status: 'all');

  void _reload() => setState(() => _future = _loadData());

  Future<void> _refresh() async {
    _reload();
    await _future;
  }

  Future<void> _openDetails(Tournament tournament) async {
    await Navigator.push<void>(
      context,
      MaterialPageRoute<void>(
        builder: (_) => TournamentDetailScreen(matchId: tournament.id),
      ),
    );
    if (mounted) _reload();
  }

  Future<void> _join(Tournament tournament) async {
    final app = context.read<AppState>();
    if (!app.isLoggedIn) {
      await Navigator.push<bool>(
        context,
        MaterialPageRoute<bool>(builder: (_) => const LoginScreen()),
      );
      if (mounted) _reload();
      return;
    }

    final confirmed = await showModalBottomSheet<bool>(
      context: context,
      backgroundColor: AppColors.surface,
      showDragHandle: true,
      builder: (context) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(20, 4, 20, 24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Text(
                tournament.title,
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(fontSize: 19, fontWeight: FontWeight.w900),
              ),
              const SizedBox(height: 10),
              Text(
                '${tournament.entryGold.toStringAsFixed(0)} Gold hold হবে। Website-এর নিয়ম অনুযায়ী join complete হবে।',
                style: const TextStyle(color: AppColors.muted, height: 1.4),
              ),
              const SizedBox(height: 18),
              SizedBox(
                width: double.infinity,
                child: FilledButton.icon(
                  onPressed: () => Navigator.pop(context, true),
                  icon: const Icon(Icons.check_circle_outline_rounded),
                  label: const Text('CONFIRM JOIN'),
                ),
              ),
              const SizedBox(height: 8),
              SizedBox(
                width: double.infinity,
                child: OutlinedButton(
                  onPressed: () => Navigator.pop(context, false),
                  child: const Text('CANCEL'),
                ),
              ),
            ],
          ),
        ),
      ),
    );
    if (confirmed != true) return;

    try {
      final result = await app.api.joinTournament(tournament.id);
      await app.refreshProfile();
      if (!mounted) return;
      final message = result['message']?.toString().trim() ?? '';
      showAppMessage(
        context,
        message.isNotEmpty ? message : 'Tournament join হয়েছে।',
      );
      _reload();
    } on ApiException catch (error) {
      if (mounted) showAppMessage(context, error.message, error: true);
    }
  }

  List<Tournament> _filtered(List<Tournament> items) {
    final normalizedQuery = _query.trim().toLowerCase();
    return items.where((item) {
      final statusMatch = switch (_status) {
        _TournamentStatus.all => true,
        _TournamentStatus.live => item.isLive,
        _TournamentStatus.upcoming => item.isUpcoming,
        _TournamentStatus.completed => item.isEnded,
        _TournamentStatus.cancelled => item.isCancelled,
      };
      final modeMatch = _mode == 'All' ||
          item.mode.trim().toLowerCase() == _mode.toLowerCase();
      final queryMatch = normalizedQuery.isEmpty ||
          item.title.toLowerCase().contains(normalizedQuery) ||
          item.mode.toLowerCase().contains(normalizedQuery);
      return statusMatch && modeMatch && queryMatch;
    }).toList();
  }

  @override
  Widget build(BuildContext context) => FutureBuilder<List<Tournament>>(
        future: _future,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const PageLoading(label: 'Tournaments loading...');
          }
          if (snapshot.hasError) {
            return Padding(
              padding: const EdgeInsets.all(16),
              child: ErrorPanel(
                message: snapshot.error.toString(),
                onRetry: _reload,
              ),
            );
          }

          final items = snapshot.data ?? const <Tournament>[];
          final visible = _filtered(items);
          return RefreshIndicator(
            color: AppColors.orange,
            onRefresh: _refresh,
            child: ListView(
              physics: const AlwaysScrollableScrollPhysics(),
              padding: const EdgeInsets.fromLTRB(16, 16, 16, 30),
              children: <Widget>[
                Row(
                  children: <Widget>[
                    const Expanded(
                      child: Text(
                        'Tournaments',
                        style: TextStyle(fontSize: 24, fontWeight: FontWeight.w900),
                      ),
                    ),
                    IconButton(
                      tooltip: 'Refresh',
                      onPressed: _reload,
                      icon: const Icon(Icons.refresh_rounded),
                    ),
                  ],
                ),
                const SizedBox(height: 4),
                const Text(
                  'Find a match, join with Gold, and compete for rank.',
                  style: TextStyle(color: AppColors.muted, height: 1.35),
                ),
                const SizedBox(height: 16),
                TextField(
                  onChanged: (value) => setState(() => _query = value),
                  textInputAction: TextInputAction.search,
                  decoration: const InputDecoration(
                    hintText: 'Search tournament',
                    prefixIcon: Icon(Icons.search_rounded),
                  ),
                ),
                const SizedBox(height: 14),
                _FilterScroller<_TournamentStatus>(
                  items: const <_FilterOption<_TournamentStatus>>[
                    _FilterOption(_TournamentStatus.all, 'All'),
                    _FilterOption(_TournamentStatus.live, 'Live'),
                    _FilterOption(_TournamentStatus.upcoming, 'Upcoming'),
                    _FilterOption(_TournamentStatus.completed, 'Completed'),
                    _FilterOption(_TournamentStatus.cancelled, 'Cancelled'),
                  ],
                  selected: _status,
                  onSelect: (value) => setState(() => _status = value),
                  colorFor: _statusFilterColor,
                ),
                const SizedBox(height: 10),
                _FilterScroller<String>(
                  items: const <_FilterOption<String>>[
                    _FilterOption('All', 'All modes'),
                    _FilterOption('Solo', 'Solo'),
                    _FilterOption('Duo', 'Duo'),
                    _FilterOption('Squad', 'Squad'),
                  ],
                  selected: _mode,
                  onSelect: (value) => setState(() => _mode = value),
                  colorFor: (_) => AppColors.cyan,
                ),
                const SizedBox(height: 20),
                if (visible.isEmpty)
                  const EmptyState(
                    icon: Icons.emoji_events_outlined,
                    title: 'No tournament found',
                    message: 'Filter change করুন অথবা Website Admin নতুন match publish করলে এখানে দেখা যাবে।',
                  )
                else
                  ...visible.map(
                    (tournament) => Padding(
                      padding: const EdgeInsets.only(bottom: 13),
                      child: CompactTournamentCard(
                        tournament: tournament,
                        onOpen: () => _openDetails(tournament),
                        primaryLabel: _actionLabel(tournament),
                        primaryIcon: _actionIcon(tournament),
                        primaryColor: _actionColor(tournament),
                        onPrimary: tournament.canJoin
                            ? () => _join(tournament)
                            : () => _openDetails(tournament),
                      ),
                    ),
                  ),
              ],
            ),
          );
        },
      );

  Color _statusFilterColor(_TournamentStatus status) {
    switch (status) {
      case _TournamentStatus.live:
        return AppColors.red;
      case _TournamentStatus.completed:
        return AppColors.green;
      case _TournamentStatus.cancelled:
        return AppColors.muted;
      case _TournamentStatus.all:
      case _TournamentStatus.upcoming:
        return AppColors.orange;
    }
  }

  String _actionLabel(Tournament tournament) {
    if (tournament.canJoin) return 'JOIN NOW';
    if (tournament.isJoined) return 'VIEW MATCH';
    if (tournament.isEnded && tournament.resultPublished) return 'VIEW RESULT';
    return 'VIEW MATCH';
  }

  IconData _actionIcon(Tournament tournament) {
    if (tournament.canJoin) return Icons.add_circle_outline_rounded;
    if (tournament.isEnded && tournament.resultPublished) {
      return Icons.emoji_events_outlined;
    }
    return Icons.arrow_forward_rounded;
  }

  Color _actionColor(Tournament tournament) {
    if (tournament.canJoin) return AppColors.orange;
    if (tournament.isLive) return AppColors.red;
    if (tournament.isEnded) return AppColors.green;
    if (tournament.isJoined) return AppColors.cyan;
    return AppColors.cyan;
  }
}

class _FilterOption<T> {
  const _FilterOption(this.value, this.label);
  final T value;
  final String label;
}

class _FilterScroller<T> extends StatelessWidget {
  const _FilterScroller({
    required this.items,
    required this.selected,
    required this.onSelect,
    required this.colorFor,
  });

  final List<_FilterOption<T>> items;
  final T selected;
  final ValueChanged<T> onSelect;
  final Color Function(T value) colorFor;

  @override
  Widget build(BuildContext context) => SingleChildScrollView(
        scrollDirection: Axis.horizontal,
        child: Row(
          children: items
              .map(
                (item) => Padding(
                  padding: const EdgeInsets.only(right: 8),
                  child: _FilterChip(
                    label: item.label,
                    selected: item.value == selected,
                    color: colorFor(item.value),
                    onTap: () => onSelect(item.value),
                  ),
                ),
              )
              .toList(),
        ),
      );
}

class _FilterChip extends StatelessWidget {
  const _FilterChip({
    required this.label,
    required this.selected,
    required this.color,
    required this.onTap,
  });

  final String label;
  final bool selected;
  final Color color;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) => Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(12),
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 160),
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 9),
            decoration: BoxDecoration(
              color: selected ? color.withValues(alpha: .16) : AppColors.surface,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(
                color: selected ? color : AppColors.border,
                width: selected ? 1.25 : 1,
              ),
            ),
            child: Text(
              label,
              style: TextStyle(
                color: selected ? AppColors.text : AppColors.muted,
                fontSize: 12,
                fontWeight: FontWeight.w800,
                decoration: TextDecoration.none,
              ),
            ),
          ),
        ),
      );
}
