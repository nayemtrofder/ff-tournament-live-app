import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../core/api_client.dart';
import '../core/app_state.dart';
import '../core/app_theme.dart';
import '../core/formatters.dart';
import '../models/wallet_transaction.dart';
import '../widgets/common.dart';
import 'buy_gold_screen.dart';

class WalletScreen extends StatefulWidget {
  const WalletScreen({super.key});

  @override
  State<WalletScreen> createState() => _WalletScreenState();
}

class _WalletScreenState extends State<WalletScreen>
    with WidgetsBindingObserver {
  late Future<_WalletBundle> _future;
  bool _opening = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _future = _loadData();
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) _reload();
  }

  Future<_WalletBundle> _loadData() async {
    final api = context.read<AppState>().api;
    final results = await Future.wait<dynamic>(<Future<dynamic>>[
      api.getWallet(),
      api.getWalletHistory(),
    ]);
    return _WalletBundle(
      wallet: results[0] as WalletPayload,
      history: results[1] as WalletHistoryPayload,
    );
  }

  void _reload() => setState(() => _future = _loadData());

  Future<void> _refresh() async {
    _reload();
    await _future;
  }

  Future<void> _buyGold() async {
    setState(() => _opening = true);
    try {
      await Navigator.push<bool>(
        context,
        MaterialPageRoute<bool>(builder: (_) => const BuyGoldScreen()),
      );
      if (mounted) {
        await context.read<AppState>().refreshProfile();
        _reload();
      }
    } finally {
      if (mounted) setState(() => _opening = false);
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('My Wallet')),
    body: FutureBuilder<_WalletBundle>(
      future: _future,
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting)
          return const PageLoading(label: 'Wallet loading...');
        if (snapshot.hasError)
          return Padding(
            padding: const EdgeInsets.all(16),
            child: ErrorPanel(
              message: snapshot.error.toString(),
              onRetry: _reload,
            ),
          );
        final bundle = snapshot.data;
        if (bundle == null)
          return Padding(
            padding: const EdgeInsets.all(16),
            child: ErrorPanel(
              message: 'Wallet data পাওয়া যায়নি।',
              onRetry: _reload,
            ),
          );
        final wallet = bundle.wallet;
        return RefreshIndicator(
          color: AppColors.orange,
          onRefresh: _refresh,
          child: ListView(
            padding: const EdgeInsets.all(16),
            physics: const AlwaysScrollableScrollPhysics(),
            children: <Widget>[
              Container(
                padding: const EdgeInsets.all(23),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(26),
                  gradient: const LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: <Color>[Color(0xFF4C3511), Color(0xFF151A25)],
                  ),
                  border: Border.all(
                    color: AppColors.gold.withValues(alpha: .5),
                  ),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    const Icon(
                      Icons.workspace_premium_rounded,
                      color: AppColors.gold,
                      size: 39,
                    ),
                    const SizedBox(height: 18),
                    const Text(
                      'AVAILABLE GOLD',
                      style: TextStyle(
                        color: AppColors.muted,
                        fontWeight: FontWeight.w900,
                        letterSpacing: 1.1,
                      ),
                    ),
                    const SizedBox(height: 5),
                    Text(
                      '${wallet.gold.toStringAsFixed(0)} Gold',
                      style: const TextStyle(
                        color: AppColors.gold,
                        fontSize: 37,
                        fontWeight: FontWeight.w900,
                      ),
                    ),
                    const SizedBox(height: 7),
                    Text(
                      'Live balance from the website wallet',
                      style: const TextStyle(
                        color: AppColors.muted,
                        height: 1.4,
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 12),
              _BalanceCard(
                title: 'Held Gold',
                value: wallet.heldGold,
                icon: Icons.lock_outline_rounded,
                accent: AppColors.cyan,
              ),
              const SizedBox(height: 12),
              _BalanceCard(
                title: 'Winning Balance',
                value: wallet.winningBalance,
                icon: Icons.emoji_events_rounded,
                accent: AppColors.green,
                isMoney: true,
              ),
              const SizedBox(height: 16),
              FilledButton.icon(
                onPressed: _opening ? null : _buyGold,
                icon: _opening
                    ? const SizedBox.square(
                        dimension: 18,
                        child: CircularProgressIndicator(
                          color: Colors.black,
                          strokeWidth: 2,
                        ),
                      )
                    : const Icon(Icons.add_circle_rounded),
                label: Text(_opening ? 'OPENING...' : 'BUY GOLD'),
              ),
              const SizedBox(height: 22),
              const SectionHeading(title: 'Gold History'),
              const SizedBox(height: 9),
              if (bundle.history.items.isEmpty)
                const SurfaceBox(
                  child: Text(
                    'Gold transaction history এখনো নেই। Website থেকে Gold buy, join, refund বা prize হলে এখানে real history আসবে।',
                    style: TextStyle(color: AppColors.muted, height: 1.45),
                  ),
                )
              else
                ...bundle.history.items.map(
                  (item) => Padding(
                    padding: const EdgeInsets.only(bottom: 9),
                    child: _TransactionRow(item: item),
                  ),
                ),
              const SizedBox(height: 12),
              const Text(
                'Payment App-এর ভিতরে খুলবে। সমস্যা হলে একই পেজ Website Browser-এও খোলা যাবে।',
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: AppColors.muted,
                  fontSize: 11,
                  height: 1.4,
                ),
              ),
            ],
          ),
        );
      },
    ),
  );
}

class _WalletBundle {
  const _WalletBundle({required this.wallet, required this.history});
  final WalletPayload wallet;
  final WalletHistoryPayload history;
}

class _BalanceCard extends StatelessWidget {
  const _BalanceCard({
    required this.title,
    required this.value,
    required this.icon,
    required this.accent,
    this.isMoney = false,
  });
  final String title;
  final double value;
  final IconData icon;
  final Color accent;
  final bool isMoney;

  @override
  Widget build(BuildContext context) => SurfaceBox(
    padding: const EdgeInsets.all(14),
    color: accent.withValues(alpha: .09),
    borderColor: accent.withValues(alpha: .35),
    child: Row(
      children: <Widget>[
        Container(
          padding: const EdgeInsets.all(10),
          decoration: BoxDecoration(
            color: accent.withValues(alpha: .16),
            borderRadius: BorderRadius.circular(14),
          ),
          child: Icon(icon, color: accent),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Text(title, style: const TextStyle(fontWeight: FontWeight.w800)),
              const SizedBox(height: 4),
              Text(
                isMoney ? '৳${value.toStringAsFixed(2)} BDT' : goldText(value),
                style: TextStyle(
                  color: accent,
                  fontSize: 18,
                  fontWeight: FontWeight.w900,
                ),
              ),
            ],
          ),
        ),
      ],
    ),
  );
}

class _TransactionRow extends StatelessWidget {
  const _TransactionRow({required this.item});
  final WalletTransaction item;

  @override
  Widget build(BuildContext context) {
    final normalized = item.type.toLowerCase();
    final isDebit =
        item.direction == 'debit' ||
        normalized.contains('deduct') ||
        normalized.contains('hold') ||
        normalized.contains('entry') ||
        normalized.contains('join');
    final color = isDebit
        ? AppColors.red
        : (normalized.contains('refund')
              ? AppColors.orange
              : (normalized.contains('prize') ||
                        normalized.contains('win') ||
                        normalized.contains('deposit') ||
                        normalized.contains('buy')
                    ? AppColors.green
                    : AppColors.cyan));
    final sign = isDebit ? '−' : '+';
    final amount = item.effectiveAmount.abs().toStringAsFixed(0);
    return SurfaceBox(
      padding: const EdgeInsets.symmetric(horizontal: 13, vertical: 12),
      child: Row(
        children: <Widget>[
          Container(
            width: 38,
            height: 38,
            alignment: Alignment.center,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: color.withValues(alpha: .14),
            ),
            child: Icon(_iconForType(normalized), color: color, size: 20),
          ),
          const SizedBox(width: 11),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Text(
                  _displayTitle(),
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(fontWeight: FontWeight.w800),
                ),
                const SizedBox(height: 4),
                Text(
                  _subtitle(),
                  style: const TextStyle(
                    color: AppColors.muted,
                    fontSize: 11,
                    height: 1.35,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  _formattedTime(item.createdAt),
                  style: const TextStyle(color: AppColors.muted, fontSize: 10),
                ),
              ],
            ),
          ),
          const SizedBox(width: 10),
          Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: <Widget>[
              Text(
                '$sign$amount',
                style: TextStyle(
                  color: color,
                  fontWeight: FontWeight.w900,
                  fontSize: 17,
                ),
              ),
              const SizedBox(height: 4),
              Text(
                _statusLabel(normalized),
                style: TextStyle(
                  color: color,
                  fontWeight: FontWeight.w800,
                  fontSize: 10,
                  letterSpacing: .6,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  IconData _iconForType(String normalized) {
    if (normalized.contains('hold')) return Icons.lock_outline_rounded;
    if (normalized.contains('refund')) return Icons.undo_rounded;
    if (normalized.contains('deduct') ||
        normalized.contains('debit') ||
        normalized.contains('join') ||
        normalized.contains('entry'))
      return Icons.remove_circle_outline_rounded;
    if (normalized.contains('prize') || normalized.contains('win'))
      return Icons.emoji_events_rounded;
    if (normalized.contains('deposit') ||
        normalized.contains('buy') ||
        normalized.contains('credit'))
      return Icons.add_circle_outline_rounded;
    return Icons.swap_horiz_rounded;
  }

  String _displayTitle() {
    final title = item.description.isNotEmpty ? item.description : item.type;
    return title
        .replaceAll('_', ' ')
        .split(' ')
        .map(
          (word) =>
              word.isEmpty ? word : word[0].toUpperCase() + word.substring(1),
        )
        .join(' ');
  }

  String _subtitle() {
    if (item.matchTitle.isNotEmpty) return item.matchTitle;
    if (item.description.isNotEmpty)
      return item.type.replaceAll('_', ' ').toUpperCase();
    return 'Gold balance update';
  }

  String _statusLabel(String normalized) {
    if (normalized.contains('hold')) return 'HOLD';
    if (normalized.contains('refund')) return 'REFUND';
    if (normalized.contains('deduct')) return 'DEDUCT';
    if (normalized.contains('prize')) return 'PRIZE';
    if (normalized.contains('deposit')) return 'DEPOSIT';
    if (normalized.contains('buy')) return 'BUY';
    return item.direction.toUpperCase().isNotEmpty
        ? item.direction.toUpperCase()
        : 'UPDATE';
  }

  String _formattedTime(String raw) {
    if (raw.isEmpty) return '—';
    final date = DateTime.tryParse(raw);
    if (date == null) return raw;
    final local = date.toLocal();
    final day = local.day.toString().padLeft(2, '0');
    final month = local.month.toString().padLeft(2, '0');
    final hour = local.hour.toString().padLeft(2, '0');
    final minute = local.minute.toString().padLeft(2, '0');
    return '$day/$month/${local.year} • $hour:$minute';
  }
}
