import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../core/api_client.dart';
import '../core/app_state.dart';
import '../core/app_theme.dart';
import '../widgets/common.dart';
import 'profile_edit_screen.dart';

class RegisterScreen extends StatefulWidget {
  const RegisterScreen({super.key});

  @override
  State<RegisterScreen> createState() => _RegisterScreenState();
}

class _RegisterScreenState extends State<RegisterScreen> {
  final _formKey = GlobalKey<FormState>();
  final _username = TextEditingController();
  final _contact = TextEditingController();
  final _password = TextEditingController();
  final _confirmPassword = TextEditingController();
  bool _obscurePassword = true;
  bool _obscureConfirm = true;
  bool _loading = false;

  @override
  void dispose() {
    _username.dispose();
    _contact.dispose();
    _password.dispose();
    _confirmPassword.dispose();
    super.dispose();
  }

  Future<void> _register() async {
    if (_loading || !(_formKey.currentState?.validate() ?? false)) return;
    setState(() => _loading = true);
    try {
      await context.read<AppState>().register(
            username: _username.text.trim(),
            contact: _contact.text.trim(),
            password: _password.text,
          );
      if (!mounted) return;
      showAppMessage(
        context,
        'Account তৈরি হয়েছে। এখন Game Profile complete করুন।',
      );
      final user = context.read<AppState>().user;
      if (user != null) {
        await Navigator.push<bool>(
          context,
          MaterialPageRoute<bool>(
            builder: (_) => ProfileEditScreen(user: user),
          ),
        );
      }
      if (mounted) Navigator.pop(context, true);
    } on ApiException catch (error) {
      if (mounted) showAppMessage(context, error.message, error: true);
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('Create Player Account')),
        body: SafeArea(
          child: Form(
            key: _formKey,
            child: ListView(
              padding: const EdgeInsets.fromLTRB(20, 18, 20, 30),
              children: <Widget>[
                Align(
                  alignment: Alignment.centerLeft,
                  child: Container(
                    width: 72,
                    height: 72,
                    alignment: Alignment.center,
                    decoration: BoxDecoration(
                      color: AppColors.orange.withValues(alpha: .14),
                      borderRadius: BorderRadius.circular(22),
                      border: Border.all(
                        color: AppColors.orange.withValues(alpha: .48),
                      ),
                    ),
                    child: const Icon(
                      Icons.person_add_alt_1_rounded,
                      color: AppColors.gold,
                      size: 38,
                    ),
                  ),
                ),
                const SizedBox(height: 18),
                const Text(
                  'Start your tournament journey',
                  style: TextStyle(fontSize: 24, fontWeight: FontWeight.w900),
                ),
                const SizedBox(height: 6),
                const Text(
                  'Account Website-এ তৈরি হবে। এরপর FF UID ও IGN দিয়ে Game Profile complete করবেন।',
                  style: TextStyle(color: AppColors.muted, height: 1.4),
                ),
                const SizedBox(height: 24),
                TextFormField(
                  controller: _username,
                  textInputAction: TextInputAction.next,
                  autocorrect: false,
                  decoration: const InputDecoration(
                    labelText: 'Username',
                    hintText: 'English letter, number, . _ -',
                    prefixIcon: Icon(Icons.person_outline_rounded),
                  ),
                  validator: (value) {
                    final username = (value ?? '').trim();
                    if (!RegExp(r'^[A-Za-z0-9_.-]{3,40}$').hasMatch(username)) {
                      return 'Username 3–40 অক্ষরের English letter, number, . _ - দিয়ে দিন।';
                    }
                    return null;
                  },
                ),
                const SizedBox(height: 13),
                TextFormField(
                  controller: _contact,
                  textInputAction: TextInputAction.next,
                  keyboardType: TextInputType.emailAddress,
                  decoration: const InputDecoration(
                    labelText: 'Mobile number or Email',
                    hintText: '01XXXXXXXXX অথবা email',
                    prefixIcon: Icon(Icons.phone_android_rounded),
                  ),
                  validator: (value) => (value ?? '').trim().isEmpty
                      ? 'Mobile number অথবা Email দিন।'
                      : null,
                ),
                const SizedBox(height: 13),
                TextFormField(
                  controller: _password,
                  obscureText: _obscurePassword,
                  textInputAction: TextInputAction.next,
                  decoration: InputDecoration(
                    labelText: 'Password',
                    hintText: 'Minimum 8 characters',
                    prefixIcon: const Icon(Icons.lock_outline_rounded),
                    suffixIcon: IconButton(
                      onPressed: () => setState(
                        () => _obscurePassword = !_obscurePassword,
                      ),
                      icon: Icon(
                        _obscurePassword
                            ? Icons.visibility_outlined
                            : Icons.visibility_off_outlined,
                      ),
                    ),
                  ),
                  validator: (value) => (value ?? '').length < 8
                      ? 'Password কমপক্ষে 8 অক্ষরের দিন।'
                      : null,
                ),
                const SizedBox(height: 13),
                TextFormField(
                  controller: _confirmPassword,
                  obscureText: _obscureConfirm,
                  onFieldSubmitted: (_) => _register(),
                  decoration: InputDecoration(
                    labelText: 'Confirm password',
                    prefixIcon: const Icon(Icons.verified_user_outlined),
                    suffixIcon: IconButton(
                      onPressed: () => setState(
                        () => _obscureConfirm = !_obscureConfirm,
                      ),
                      icon: Icon(
                        _obscureConfirm
                            ? Icons.visibility_outlined
                            : Icons.visibility_off_outlined,
                      ),
                    ),
                  ),
                  validator: (value) => value != _password.text
                      ? 'Password দুইটি একই নয়।'
                      : null,
                ),
                const SizedBox(height: 21),
                FilledButton.icon(
                  onPressed: _loading ? null : _register,
                  icon: _loading
                      ? const SizedBox.square(
                          dimension: 18,
                          child: CircularProgressIndicator(
                            color: Colors.black,
                            strokeWidth: 2,
                          ),
                        )
                      : const Icon(Icons.person_add_alt_1_rounded),
                  label: Text(_loading ? 'CREATING ACCOUNT...' : 'CREATE ACCOUNT'),
                ),
                const SizedBox(height: 13),
                const Text(
                  'Account create করার পর tournament join করতে FF UID এবং IGN অবশ্যই save করবেন।',
                  textAlign: TextAlign.center,
                  style: TextStyle(color: AppColors.muted, fontSize: 12, height: 1.4),
                ),
              ],
            ),
          ),
        ),
      );
}
