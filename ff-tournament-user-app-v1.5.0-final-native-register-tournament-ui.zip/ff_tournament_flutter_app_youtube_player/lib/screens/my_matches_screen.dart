import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../core/app_state.dart';
import '../core/app_theme.dart';
import '../models/tournament.dart';
import '../widgets/common.dart';
import '../widgets/compact_tournament_card.dart';
import 'login_screen.dart';
import 'tournament_detail_screen.dart';
import 'youtube_player_screen.dart';

enum _MatchStatus { upcoming, live, completed, cancelled }

class MyMatchesScreen extends StatefulWidget {
  const MyMatchesScreen({super.key});

  @override
  State<MyMatchesScreen> createState() => _MyMatchesScreenState();
}

class _MyMatchesScreenState extends State<MyMatchesScreen> {
  late Future<MyMatchesPayload> _future;
  _MatchStatus _selected = _MatchStatus.upcoming;

  @override
  void initState() {
    super.initState();
    _future = _loadData();
  }

  Future<MyMatchesPayload> _loadData() {
    final state = context.read<AppState>();
    if (!state.isLoggedIn) {
      return Future<MyMatchesPayload>.value(
        const MyMatchesPayload(items: <Tournament>[], summary: <String, int>{}),
      );
    }
    return state.api.getMyMatches(status: 'all');
  }

  void _reload() => setState(() => _future = _loadData());

  Future<void> _refresh() async {
    _reload();
    await _future;
  }

  Future<void> _openDetails(Tournament tournament) async {
    await Navigator.push<void>(
      context,
      MaterialPageRoute<void>(
        builder: (_) => TournamentDetailScreen(matchId: tournament.id),
      ),
    );
    if (mounted) _reload();
  }

  Future<void> _watchLive(Tournament tournament) async {
    final video = tournament.liveVideo;
    if (video == null || video.url.trim().isEmpty) {
      await _openDetails(tournament);
      return;
    }
    await Navigator.push<void>(
      context,
      MaterialPageRoute<void>(
        builder: (_) => YouTubePlayerScreen(
          title: video.title,
          youtubeUrl: video.url,
          subtitle: video.typeLabel,
          isLive: video.isLive,
        ),
      ),
    );
    if (mounted) _reload();
  }

  List<Tournament> _visible(List<Tournament> items) {
    return items.where((item) {
      switch (_selected) {
        case _MatchStatus.live:
          return item.isLive;
        case _MatchStatus.completed:
          return item.isEnded;
        case _MatchStatus.cancelled:
          return item.isCancelled;
        case _MatchStatus.upcoming:
          return item.isUpcoming;
      }
    }).toList();
  }

  int _count(MyMatchesPayload payload, _MatchStatus status) {
    final key = switch (status) {
      _MatchStatus.upcoming => 'upcoming',
      _MatchStatus.live => 'live',
      _MatchStatus.completed => 'ended',
      _MatchStatus.cancelled => 'cancelled',
    };
    if (payload.summary.containsKey(key)) return payload.summary[key] ?? 0;
    return _visibleFor(status, payload.items).length;
  }

  List<Tournament> _visibleFor(_MatchStatus status, List<Tournament> items) {
    return items.where((item) {
      switch (status) {
        case _MatchStatus.live:
          return item.isLive;
        case _MatchStatus.completed:
          return item.isEnded;
        case _MatchStatus.cancelled:
          return item.isCancelled;
        case _MatchStatus.upcoming:
          return item.isUpcoming;
      }
    }).toList();
  }

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    if (!app.isLoggedIn) {
      return Center(
        child: EmptyState(
          icon: Icons.lock_outline_rounded,
          title: 'Login to see your matches',
          message: 'আপনি যে tournament-এ join করেছেন সেগুলো এখানে থাকবে।',
          action: FilledButton.icon(
            onPressed: () async {
              await Navigator.push<bool>(
                context,
                MaterialPageRoute<bool>(builder: (_) => const LoginScreen()),
              );
              if (mounted) _reload();
            },
            icon: const Icon(Icons.login_rounded),
            label: const Text('LOGIN'),
          ),
        ),
      );
    }

    return FutureBuilder<MyMatchesPayload>(
      future: _future,
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const PageLoading(label: 'Your matches loading...');
        }
        if (snapshot.hasError) {
          return Padding(
            padding: const EdgeInsets.all(16),
            child: ErrorPanel(message: snapshot.error.toString(), onRetry: _reload),
          );
        }

        final payload = snapshot.data ??
            const MyMatchesPayload(
              items: <Tournament>[],
              summary: <String, int>{},
            );
        final matches = _visible(payload.items);

        return RefreshIndicator(
          color: AppColors.orange,
          onRefresh: _refresh,
          child: ListView(
            physics: const AlwaysScrollableScrollPhysics(),
            padding: const EdgeInsets.fromLTRB(16, 16, 16, 30),
            children: <Widget>[
              Row(
                children: <Widget>[
                  const Expanded(
                    child: Text(
                      'My Matches',
                      style: TextStyle(fontSize: 24, fontWeight: FontWeight.w900),
                    ),
                  ),
                  IconButton(
                    tooltip: 'Refresh',
                    onPressed: _reload,
                    icon: const Icon(Icons.refresh_rounded),
                  ),
                ],
              ),
              const SizedBox(height: 4),
              const Text(
                'Your joined tournaments, room access, and results.',
                style: TextStyle(color: AppColors.muted, height: 1.35),
              ),
              const SizedBox(height: 16),
              SingleChildScrollView(
                scrollDirection: Axis.horizontal,
                child: Row(
                  children: <Widget>[
                    _StatusTab(
                      label: 'Upcoming',
                      count: _count(payload, _MatchStatus.upcoming),
                      selected: _selected == _MatchStatus.upcoming,
                      color: AppColors.orange,
                      onTap: () => setState(() => _selected = _MatchStatus.upcoming),
                    ),
                    const SizedBox(width: 8),
                    _StatusTab(
                      label: 'Live',
                      count: _count(payload, _MatchStatus.live),
                      selected: _selected == _MatchStatus.live,
                      color: AppColors.red,
                      live: true,
                      onTap: () => setState(() => _selected = _MatchStatus.live),
                    ),
                    const SizedBox(width: 8),
                    _StatusTab(
                      label: 'Completed',
                      count: _count(payload, _MatchStatus.completed),
                      selected: _selected == _MatchStatus.completed,
                      color: AppColors.green,
                      onTap: () => setState(() => _selected = _MatchStatus.completed),
                    ),
                    const SizedBox(width: 8),
                    _StatusTab(
                      label: 'Cancelled',
                      count: _count(payload, _MatchStatus.cancelled),
                      selected: _selected == _MatchStatus.cancelled,
                      color: AppColors.muted,
                      onTap: () => setState(() => _selected = _MatchStatus.cancelled),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 20),
              if (matches.isEmpty)
                _EmptyMatches(status: _selected)
              else
                ...matches.map(
                  (tournament) => Padding(
                    padding: const EdgeInsets.only(bottom: 13),
                    child: CompactTournamentCard(
                      tournament: tournament,
                      onOpen: () => _openDetails(tournament),
                      primaryLabel: _actionLabel(tournament),
                      primaryIcon: _actionIcon(tournament),
                      primaryColor: _actionColor(tournament),
                      onPrimary: tournament.isLive &&
                              (tournament.liveVideo?.url.trim().isNotEmpty ?? false)
                          ? () => _watchLive(tournament)
                          : () => _openDetails(tournament),
                      showPlayerResult: true,
                      showRoomHint: true,
                    ),
                  ),
                ),
            ],
          ),
        );
      },
    );
  }

  String _actionLabel(Tournament tournament) {
    if (tournament.isLive &&
        (tournament.liveVideo?.url.trim().isNotEmpty ?? false)) {
      return 'WATCH LIVE';
    }
    if (tournament.isEnded && tournament.resultPublished) return 'VIEW RESULT';
    return 'VIEW MATCH';
  }

  IconData _actionIcon(Tournament tournament) {
    if (tournament.isLive &&
        (tournament.liveVideo?.url.trim().isNotEmpty ?? false)) {
      return Icons.play_arrow_rounded;
    }
    if (tournament.isEnded && tournament.resultPublished) {
      return Icons.emoji_events_outlined;
    }
    return Icons.arrow_forward_rounded;
  }

  Color _actionColor(Tournament tournament) {
    if (tournament.isLive) return AppColors.red;
    if (tournament.isEnded) return AppColors.green;
    return AppColors.cyan;
  }
}

class _StatusTab extends StatelessWidget {
  const _StatusTab({
    required this.label,
    required this.count,
    required this.selected,
    required this.color,
    required this.onTap,
    this.live = false,
  });

  final String label;
  final int count;
  final bool selected;
  final Color color;
  final VoidCallback onTap;
  final bool live;

  @override
  Widget build(BuildContext context) => Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(12),
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 160),
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 9),
            decoration: BoxDecoration(
              color: selected ? color.withValues(alpha: .16) : AppColors.surface,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(
                color: selected ? color : AppColors.border,
                width: selected ? 1.25 : 1,
              ),
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: <Widget>[
                if (live) ...<Widget>[
                  Container(
                    width: 7,
                    height: 7,
                    decoration: const BoxDecoration(
                      color: AppColors.red,
                      shape: BoxShape.circle,
                    ),
                  ),
                  const SizedBox(width: 5),
                ],
                Text(
                  label,
                  style: TextStyle(
                    color: selected ? AppColors.text : AppColors.muted,
                    fontSize: 12,
                    fontWeight: FontWeight.w800,
                    decoration: TextDecoration.none,
                  ),
                ),
                const SizedBox(width: 6),
                Text(
                  '$count',
                  style: TextStyle(
                    color: selected ? color : AppColors.muted,
                    fontSize: 11,
                    fontWeight: FontWeight.w900,
                    decoration: TextDecoration.none,
                  ),
                ),
              ],
            ),
          ),
        ),
      );
}

class _EmptyMatches extends StatelessWidget {
  const _EmptyMatches({required this.status});
  final _MatchStatus status;

  @override
  Widget build(BuildContext context) {
    final message = switch (status) {
      _MatchStatus.upcoming => 'আপনার কোনো upcoming tournament নেই।',
      _MatchStatus.live => 'এই মুহূর্তে আপনার কোনো live tournament নেই।',
      _MatchStatus.completed => 'এখনও কোনো completed match নেই।',
      _MatchStatus.cancelled => 'কোনো cancelled match নেই।',
    };
    return SurfaceBox(
      child: Row(
        children: <Widget>[
          const Icon(Icons.calendar_month_outlined, color: AppColors.muted),
          const SizedBox(width: 11),
          Expanded(
            child: Text(
              message,
              style: const TextStyle(color: AppColors.muted, height: 1.4),
            ),
          ),
        ],
      ),
    );
  }
}
