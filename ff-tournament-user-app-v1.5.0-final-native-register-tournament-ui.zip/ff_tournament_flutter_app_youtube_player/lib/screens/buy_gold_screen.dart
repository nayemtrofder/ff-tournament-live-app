import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:url_launcher/url_launcher.dart';

import '../core/api_client.dart';
import '../core/app_state.dart';
import '../core/app_theme.dart';
import '../models/buy_gold.dart';
import '../widgets/common.dart';

class BuyGoldScreen extends StatefulWidget {
  const BuyGoldScreen({super.key});

  @override
  State<BuyGoldScreen> createState() => _BuyGoldScreenState();
}

class _BuyGoldScreenState extends State<BuyGoldScreen> {
  final TextEditingController _accountController = TextEditingController();
  final TextEditingController _transactionController = TextEditingController();

  BuyGoldCatalog? _catalog;
  List<BuyGoldOrder> _orders = const <BuyGoldOrder>[];
  BuyGoldProduct? _selectedProduct;
  BuyGoldPaymentMethod? _selectedMethod;
  bool _loading = true;
  bool _submitting = false;
  String _error = '';

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void dispose() {
    _accountController.dispose();
    _transactionController.dispose();
    super.dispose();
  }

  Future<void> _load({bool silent = false}) async {
    if (!silent && mounted) {
      setState(() {
        _loading = true;
        _error = '';
      });
    }

    try {
      final app = context.read<AppState>();
      final catalog = await app.api.getBuyGoldCatalog();
      final orders = await app.api.getBuyGoldOrders();

      try {
        await app.refreshProfile();
      } catch (_) {
        // Catalog is still valid even if profile refresh has a temporary issue.
      }

      if (!mounted) return;
      setState(() {
        _catalog = catalog;
        _orders = orders;
        _error = '';
        _loading = false;
        _syncSelection(catalog);
      });
    } on ApiException catch (error) {
      if (!mounted) return;
      setState(() {
        _loading = false;
        _error = error.message;
      });
    }
  }

  void _syncSelection(BuyGoldCatalog catalog) {
    final oldProductId = _selectedProduct?.id;
    final oldMethodId = _selectedMethod?.id;

    _selectedProduct =
        _findProduct(catalog.products, oldProductId) ??
        (catalog.products.isNotEmpty ? catalog.products.first : null);

    _selectedMethod =
        _findMethod(catalog.paymentMethods, oldMethodId) ??
        (catalog.paymentMethods.isNotEmpty
            ? catalog.paymentMethods.first
            : null);
  }

  BuyGoldProduct? _findProduct(List<BuyGoldProduct> items, int? id) {
    if (id == null) return null;
    for (final item in items) {
      if (item.id == id) return item;
    }
    return null;
  }

  BuyGoldPaymentMethod? _findMethod(
    List<BuyGoldPaymentMethod> items,
    String? id,
  ) {
    if (id == null || id.isEmpty) return null;
    for (final item in items) {
      if (item.id == id) return item;
    }
    return null;
  }

  Future<void> _submitOrder() async {
    final product = _selectedProduct;
    final method = _selectedMethod;

    if (product == null || method == null) {
      showAppMessage(
        context,
        'আগে Gold package এবং payment method নির্বাচন করুন।',
        error: true,
      );
      return;
    }

    final account = _accountController.text.trim();
    final transaction = _transactionController.text.trim();

    if (!method.isWhatsApp) {
      if (method.requiresAccountNumber && account.isEmpty) {
        showAppMessage(context, 'আপনার Sender Number দিন।', error: true);
        return;
      }
      if (method.requiresTransactionId && transaction.isEmpty) {
        showAppMessage(context, 'Transaction ID দিন।', error: true);
        return;
      }
    }

    setState(() => _submitting = true);

    try {
      final data = await context.read<AppState>().api.createBuyGoldOrder(
        productId: product.id,
        paymentMethod: method.id,
        accountNumber: account,
        transactionId: transaction,
      );

      if (!mounted) return;

      if (method.isWhatsApp || _text(data['action']) == 'open_whatsapp') {
        final url = _text(data['whatsapp_url']);
        if (url.isEmpty ||
            !await launchUrl(
              Uri.parse(url),
              mode: LaunchMode.externalApplication,
            )) {
          throw const ApiException('WhatsApp খুলতে পারিনি।');
        }
        showAppMessage(
          context,
          _text(data['message']).isEmpty
              ? 'WhatsApp payment message খোলা হয়েছে।'
              : _text(data['message']),
        );
      } else {
        _accountController.clear();
        _transactionController.clear();
        showAppMessage(
          context,
          _text(data['message']).isEmpty
              ? 'Order জমা হয়েছে। Admin verify করলে Gold যোগ হবে।'
              : _text(data['message']),
        );
        await _load(silent: true);
      }
    } on ApiException catch (error) {
      if (mounted) showAppMessage(context, error.message, error: true);
    } finally {
      if (mounted) setState(() => _submitting = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final user = context.watch<AppState>().user;
    final catalog = _catalog;
    final currentGold = catalog?.currentGold ?? user?.gold ?? 0;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Buy Gold'),
        actions: <Widget>[
          IconButton(
            tooltip: 'Refresh',
            onPressed: _loading ? null : () => _load(silent: true),
            icon: const Icon(Icons.refresh_rounded),
          ),
        ],
      ),
      body: _loading && catalog == null
          ? const PageLoading(label: 'Gold packages load হচ্ছে...')
          : _error.isNotEmpty && catalog == null
          ? Center(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: ErrorPanel(message: _error, onRetry: _load),
              ),
            )
          : RefreshIndicator(
              color: AppColors.orange,
              onRefresh: () => _load(silent: true),
              child: ListView(
                physics: const AlwaysScrollableScrollPhysics(),
                padding: const EdgeInsets.fromLTRB(16, 8, 16, 28),
                children: <Widget>[
                  _GoldHero(gold: currentGold),
                  const SizedBox(height: 24),
                  const SectionHeading(title: 'Gold Package'),
                  const SizedBox(height: 10),
                  if (catalog == null || catalog.products.isEmpty)
                    const EmptyState(
                      icon: Icons.inventory_2_outlined,
                      title: 'কোনো Gold package নেই',
                      message:
                          'Website Admin থেকে Gold package চালু হলে এখানে দেখা যাবে।',
                    )
                  else
                    LayoutBuilder(
                      builder: (context, constraints) {
                        final columns = constraints.maxWidth >= 680 ? 3 : 2;
                        return GridView.builder(
                          shrinkWrap: true,
                          physics: const NeverScrollableScrollPhysics(),
                          itemCount: catalog.products.length,
                          gridDelegate:
                              SliverGridDelegateWithFixedCrossAxisCount(
                                crossAxisCount: columns,
                                crossAxisSpacing: 12,
                                mainAxisSpacing: 12,
                                childAspectRatio: .79,
                              ),
                          itemBuilder: (context, index) {
                            final product = catalog.products[index];
                            return _PackageCard(
                              product: product,
                              currencySymbol: catalog.currencySymbol,
                              selected: _selectedProduct?.id == product.id,
                              onTap: () =>
                                  setState(() => _selectedProduct = product),
                            );
                          },
                        );
                      },
                    ),
                  const SizedBox(height: 25),
                  if (catalog != null && _selectedProduct != null) ...[
                    const SectionHeading(title: 'Payment Method'),
                    const SizedBox(height: 10),
                    _PaymentPanel(
                      methods: catalog.paymentMethods,
                      selected: _selectedMethod,
                      instruction: catalog.instruction,
                      product: _selectedProduct!,
                      currencySymbol: catalog.currencySymbol,
                      accountController: _accountController,
                      transactionController: _transactionController,
                      submitting: _submitting,
                      onSelectMethod: (method) =>
                          setState(() => _selectedMethod = method),
                      onSubmit: _submitOrder,
                    ),
                  ],
                  const SizedBox(height: 26),
                  const SectionHeading(title: 'My Gold Orders'),
                  const SizedBox(height: 10),
                  if (_orders.isEmpty)
                    const SurfaceBox(
                      child: Row(
                        children: <Widget>[
                          Icon(
                            Icons.receipt_long_outlined,
                            color: AppColors.muted,
                          ),
                          SizedBox(width: 12),
                          Expanded(
                            child: Text(
                              'এখনো কোনো Buy Gold order নেই।',
                              style: TextStyle(color: AppColors.muted),
                            ),
                          ),
                        ],
                      ),
                    )
                  else
                    ..._orders.map(
                      (order) => Padding(
                        padding: const EdgeInsets.only(bottom: 10),
                        child: _OrderTile(
                          order: order,
                          currencySymbol: catalog?.currencySymbol ?? '৳',
                        ),
                      ),
                    ),
                  if (_error.isNotEmpty) ...[
                    const SizedBox(height: 16),
                    ErrorPanel(
                      message: _error,
                      onRetry: () => _load(silent: true),
                    ),
                  ],
                ],
              ),
            ),
    );
  }
}

class _GoldHero extends StatelessWidget {
  const _GoldHero({required this.gold});

  final double gold;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: AppColors.gold.withValues(alpha: .65)),
        gradient: LinearGradient(
          colors: <Color>[
            AppColors.gold.withValues(alpha: .22),
            AppColors.surfaceSoft,
          ],
        ),
      ),
      child: Row(
        children: <Widget>[
          Container(
            padding: const EdgeInsets.all(13),
            decoration: BoxDecoration(
              color: AppColors.gold.withValues(alpha: .15),
              borderRadius: BorderRadius.circular(16),
            ),
            child: const Icon(
              Icons.workspace_premium_rounded,
              color: AppColors.gold,
              size: 31,
            ),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                const Text(
                  'CURRENT GOLD',
                  style: TextStyle(
                    color: AppColors.muted,
                    fontWeight: FontWeight.w900,
                    letterSpacing: .7,
                  ),
                ),
                const SizedBox(height: 3),
                Text(
                  '${_goldText(gold)} Gold',
                  style: const TextStyle(
                    fontSize: 28,
                    fontWeight: FontWeight.w900,
                    color: AppColors.gold,
                  ),
                ),
                const SizedBox(height: 3),
                const Text(
                  'Live balance from your website wallet',
                  style: TextStyle(color: AppColors.muted),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _PackageCard extends StatelessWidget {
  const _PackageCard({
    required this.product,
    required this.currencySymbol,
    required this.selected,
    required this.onTap,
  });

  final BuyGoldProduct product;
  final String currencySymbol;
  final bool selected;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final badgeColor = _hexColor(product.badgeColor, AppColors.orange);

    return Material(
      color: Colors.transparent,
      child: InkWell(
        borderRadius: BorderRadius.circular(22),
        onTap: onTap,
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 180),
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            color: selected ? AppColors.surfaceSoft : AppColors.surface,
            borderRadius: BorderRadius.circular(22),
            border: Border.all(
              color: selected ? AppColors.gold : AppColors.border,
              width: selected ? 1.7 : 1,
            ),
            boxShadow: selected
                ? <BoxShadow>[
                    BoxShadow(
                      color: AppColors.orange.withValues(alpha: .28),
                      blurRadius: 18,
                      spreadRadius: 1,
                    ),
                  ]
                : null,
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              if (product.badgeLabel.isNotEmpty)
                Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 8,
                    vertical: 5,
                  ),
                  decoration: BoxDecoration(
                    color: badgeColor,
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Text(
                    product.badgeLabel.toUpperCase(),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(
                      fontSize: 10,
                      fontWeight: FontWeight.w900,
                      color: Colors.white,
                    ),
                  ),
                )
              else
                const SizedBox(height: 26),
              const Spacer(),
              Center(
                child: Column(
                  children: <Widget>[
                    const Icon(
                      Icons.monetization_on_rounded,
                      color: AppColors.gold,
                      size: 35,
                    ),
                    const SizedBox(height: 8),
                    Text(
                      _goldText(product.goldAmount),
                      style: const TextStyle(
                        color: AppColors.gold,
                        fontWeight: FontWeight.w900,
                        fontSize: 28,
                      ),
                    ),
                    const Text(
                      'GOLD',
                      style: TextStyle(
                        color: AppColors.muted,
                        fontWeight: FontWeight.w800,
                        letterSpacing: 1.4,
                      ),
                    ),
                  ],
                ),
              ),
              const Spacer(),
              Text(
                '$currencySymbol${_money(product.priceBdt)}',
                style: const TextStyle(
                  color: AppColors.orange,
                  fontSize: 19,
                  fontWeight: FontWeight.w900,
                ),
              ),
              const SizedBox(height: 3),
              Text(
                product.name,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(color: AppColors.muted, fontSize: 11),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _PaymentPanel extends StatelessWidget {
  const _PaymentPanel({
    required this.methods,
    required this.selected,
    required this.instruction,
    required this.product,
    required this.currencySymbol,
    required this.accountController,
    required this.transactionController,
    required this.submitting,
    required this.onSelectMethod,
    required this.onSubmit,
  });

  final List<BuyGoldPaymentMethod> methods;
  final BuyGoldPaymentMethod? selected;
  final String instruction;
  final BuyGoldProduct product;
  final String currencySymbol;
  final TextEditingController accountController;
  final TextEditingController transactionController;
  final bool submitting;
  final ValueChanged<BuyGoldPaymentMethod> onSelectMethod;
  final VoidCallback onSubmit;

  @override
  Widget build(BuildContext context) {
    if (methods.isEmpty) {
      return const SurfaceBox(
        child: Text(
          'Website Admin এখনো কোনো payment method চালু করেননি।',
          style: TextStyle(color: AppColors.muted),
        ),
      );
    }

    final method = selected;

    return SurfaceBox(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: methods.map((item) {
              final color = _hexColor(
                item.color,
                item.isWhatsApp ? AppColors.green : AppColors.orange,
              );
              return ChoiceChip(
                selected: method?.id == item.id,
                selectedColor: color.withValues(alpha: .24),
                label: Text(item.label),
                avatar: Icon(
                  item.isWhatsApp
                      ? Icons.chat_rounded
                      : Icons.account_balance_wallet_rounded,
                  size: 18,
                  color: color,
                ),
                onSelected: (_) => onSelectMethod(item),
              );
            }).toList(),
          ),
          const SizedBox(height: 18),
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(13),
            decoration: BoxDecoration(
              color: AppColors.bg.withValues(alpha: .6),
              borderRadius: BorderRadius.circular(15),
              border: Border.all(color: AppColors.border),
            ),
            child: Row(
              children: <Widget>[
                const Icon(Icons.shopping_bag_rounded, color: AppColors.gold),
                const SizedBox(width: 10),
                Expanded(
                  child: Text(
                    '${_goldText(product.goldAmount)} Gold · $currencySymbol${_money(product.priceBdt)}',
                    style: const TextStyle(fontWeight: FontWeight.w900),
                  ),
                ),
              ],
            ),
          ),
          if (method != null && method.number.isNotEmpty) ...[
            const SizedBox(height: 14),
            const Text(
              'Payment Number',
              style: TextStyle(
                color: AppColors.muted,
                fontWeight: FontWeight.w800,
              ),
            ),
            const SizedBox(height: 5),
            SelectableText(
              method.number,
              style: const TextStyle(
                color: AppColors.gold,
                fontSize: 19,
                fontWeight: FontWeight.w900,
              ),
            ),
            if (method.accountType.isNotEmpty)
              Text(
                method.accountType.toUpperCase(),
                style: const TextStyle(color: AppColors.muted, fontSize: 12),
              ),
          ],
          if (instruction.trim().isNotEmpty) ...[
            const SizedBox(height: 14),
            Text(
              instruction,
              style: const TextStyle(color: AppColors.muted, height: 1.45),
            ),
          ],
          if (method != null && !method.isWhatsApp) ...[
            if (method.requiresAccountNumber) ...[
              const SizedBox(height: 16),
              TextField(
                controller: accountController,
                keyboardType: TextInputType.phone,
                decoration: const InputDecoration(
                  labelText: 'Sender Number',
                  hintText: '01XXXXXXXXX',
                  prefixIcon: Icon(Icons.phone_android_rounded),
                ),
              ),
            ],
            if (method.requiresTransactionId) ...[
              const SizedBox(height: 12),
              TextField(
                controller: transactionController,
                textCapitalization: TextCapitalization.characters,
                decoration: const InputDecoration(
                  labelText: 'Transaction ID',
                  hintText: 'ABC123XYZ',
                  prefixIcon: Icon(Icons.confirmation_number_outlined),
                ),
              ),
            ],
          ],
          const SizedBox(height: 18),
          SizedBox(
            width: double.infinity,
            child: FilledButton.icon(
              onPressed: method == null || submitting ? null : onSubmit,
              icon: submitting
                  ? const SizedBox.square(
                      dimension: 19,
                      child: CircularProgressIndicator(
                        strokeWidth: 2,
                        color: Colors.black,
                      ),
                    )
                  : Icon(
                      method?.isWhatsApp == true
                          ? Icons.chat_rounded
                          : Icons.send_rounded,
                    ),
              label: Text(
                method?.isWhatsApp == true
                    ? 'OPEN WHATSAPP'
                    : 'SUBMIT PAYMENT REQUEST',
              ),
            ),
          ),
          const SizedBox(height: 9),
          const Text(
            'Gold শুধু Website Admin payment verify করার পর wallet-এ যোগ হবে।',
            textAlign: TextAlign.center,
            style: TextStyle(
              color: AppColors.muted,
              fontSize: 12,
              height: 1.35,
            ),
          ),
        ],
      ),
    );
  }
}

class _OrderTile extends StatelessWidget {
  const _OrderTile({required this.order, required this.currencySymbol});

  final BuyGoldOrder order;
  final String currencySymbol;

  @override
  Widget build(BuildContext context) {
    final color = _statusColor(order.status);

    return SurfaceBox(
      padding: const EdgeInsets.all(14),
      borderColor: color.withValues(alpha: .5),
      child: Row(
        children: <Widget>[
          Container(
            padding: const EdgeInsets.all(11),
            decoration: BoxDecoration(
              color: color.withValues(alpha: .13),
              borderRadius: BorderRadius.circular(14),
            ),
            child: Icon(_statusIcon(order.status), color: color),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Text(
                  order.productName.isEmpty
                      ? '${_goldText(order.goldAmount)} Gold'
                      : order.productName,
                  style: const TextStyle(fontWeight: FontWeight.w900),
                ),
                const SizedBox(height: 3),
                Text(
                  '${_goldText(order.goldAmount)} Gold · $currencySymbol${_money(order.priceBdt)}',
                  style: const TextStyle(color: AppColors.muted),
                ),
                if (order.transactionId.isNotEmpty)
                  Text(
                    'Trx: ${order.transactionId}',
                    style: const TextStyle(
                      color: AppColors.muted,
                      fontSize: 12,
                    ),
                  ),
                if (order.createdAt.isNotEmpty)
                  Text(
                    _dateText(order.createdAt),
                    style: const TextStyle(
                      color: AppColors.muted,
                      fontSize: 12,
                    ),
                  ),
                if (order.adminNote.isNotEmpty)
                  Padding(
                    padding: const EdgeInsets.only(top: 4),
                    child: Text(
                      order.adminNote,
                      style: const TextStyle(
                        color: AppColors.muted,
                        fontSize: 12,
                      ),
                    ),
                  ),
              ],
            ),
          ),
          const SizedBox(width: 8),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 6),
            decoration: BoxDecoration(
              color: color.withValues(alpha: .15),
              borderRadius: BorderRadius.circular(20),
            ),
            child: Text(
              (order.statusLabel.isEmpty ? order.status : order.statusLabel)
                  .toUpperCase(),
              style: TextStyle(
                color: color,
                fontWeight: FontWeight.w900,
                fontSize: 10,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

String _text(dynamic value) => value?.toString() ?? '';

String _goldText(double value) {
  return value == value.roundToDouble()
      ? value.toStringAsFixed(0)
      : value.toStringAsFixed(1);
}

String _money(double value) {
  return value == value.roundToDouble()
      ? value.toStringAsFixed(0)
      : value.toStringAsFixed(2);
}

String _dateText(String value) {
  final date = DateTime.tryParse(value);
  if (date == null) return value;
  final local = date.toLocal();
  String two(int number) => number.toString().padLeft(2, '0');
  return '${two(local.day)}/${two(local.month)}/${local.year} · ${two(local.hour)}:${two(local.minute)}';
}

Color _hexColor(String value, Color fallback) {
  final clean = value.replaceAll('#', '').trim();
  if (clean.length != 6) return fallback;
  final parsed = int.tryParse(clean, radix: 16);
  return parsed == null ? fallback : Color(0xFF000000 | parsed);
}

Color _statusColor(String value) {
  switch (value.toLowerCase()) {
    case 'verified':
      return AppColors.green;
    case 'rejected':
    case 'fake':
      return AppColors.red;
    default:
      return AppColors.orange;
  }
}

IconData _statusIcon(String value) {
  switch (value.toLowerCase()) {
    case 'verified':
      return Icons.verified_rounded;
    case 'rejected':
    case 'fake':
      return Icons.cancel_rounded;
    default:
      return Icons.hourglass_top_rounded;
  }
}
