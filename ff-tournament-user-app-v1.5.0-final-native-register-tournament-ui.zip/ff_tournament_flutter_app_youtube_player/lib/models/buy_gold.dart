class BuyGoldCatalog {
  const BuyGoldCatalog({
    required this.products,
    required this.paymentMethods,
    required this.instruction,
    required this.currency,
    required this.currencySymbol,
    required this.currentGold,
  });

  final List<BuyGoldProduct> products;
  final List<BuyGoldPaymentMethod> paymentMethods;
  final String instruction;
  final String currency;
  final String currencySymbol;
  final double currentGold;

  factory BuyGoldCatalog.fromJson(Map<String, dynamic> json) {
    return BuyGoldCatalog(
      products: _maps(json['products']).map(BuyGoldProduct.fromJson).toList(),
      paymentMethods: _maps(
        json['payment_methods'],
      ).map(BuyGoldPaymentMethod.fromJson).toList(),
      instruction: _text(json['instruction']),
      currency: _text(json['currency']).isEmpty
          ? 'BDT'
          : _text(json['currency']),
      currencySymbol: _text(json['currency_symbol']).isEmpty
          ? '৳'
          : _text(json['currency_symbol']),
      currentGold: _number(json['current_gold']),
    );
  }
}

class BuyGoldProduct {
  const BuyGoldProduct({
    required this.id,
    required this.name,
    required this.goldAmount,
    required this.priceBdt,
    required this.badgeLabel,
    required this.badgeColor,
  });

  final int id;
  final String name;
  final double goldAmount;
  final double priceBdt;
  final String badgeLabel;
  final String badgeColor;

  factory BuyGoldProduct.fromJson(Map<String, dynamic> json) {
    return BuyGoldProduct(
      id: _integer(json['id']),
      name: _text(json['name']),
      goldAmount: _number(json['gold_amount']),
      priceBdt: _number(json['price_bdt']),
      badgeLabel: _text(json['badge_label']),
      badgeColor: _text(json['badge_color']),
    );
  }
}

class BuyGoldPaymentMethod {
  const BuyGoldPaymentMethod({
    required this.id,
    required this.label,
    required this.number,
    required this.accountType,
    required this.color,
    required this.flow,
    required this.requiresAccountNumber,
    required this.requiresTransactionId,
  });

  final String id;
  final String label;
  final String number;
  final String accountType;
  final String color;
  final String flow;
  final bool requiresAccountNumber;
  final bool requiresTransactionId;

  bool get isWhatsApp =>
      flow.toLowerCase() == 'whatsapp' || id.toLowerCase() == 'whatsapp';

  factory BuyGoldPaymentMethod.fromJson(Map<String, dynamic> json) {
    return BuyGoldPaymentMethod(
      id: _text(json['id']),
      label: _text(json['label']),
      number: _text(json['number']),
      accountType: _text(json['account_type']),
      color: _text(json['color']),
      flow: _text(json['flow']),
      requiresAccountNumber: json['requires_account_number'] == true,
      requiresTransactionId: json['requires_transaction_id'] == true,
    );
  }
}

class BuyGoldOrder {
  const BuyGoldOrder({
    required this.id,
    required this.productName,
    required this.goldAmount,
    required this.priceBdt,
    required this.paymentMethod,
    required this.accountNumberMasked,
    required this.transactionId,
    required this.status,
    required this.statusLabel,
    required this.adminNote,
    required this.createdAt,
  });

  final int id;
  final String productName;
  final double goldAmount;
  final double priceBdt;
  final String paymentMethod;
  final String accountNumberMasked;
  final String transactionId;
  final String status;
  final String statusLabel;
  final String adminNote;
  final String createdAt;

  factory BuyGoldOrder.fromJson(Map<String, dynamic> json) {
    return BuyGoldOrder(
      id: _integer(json['id']),
      productName: _text(json['product_name']),
      goldAmount: _number(json['gold_amount']),
      priceBdt: _number(json['price_bdt']),
      paymentMethod: _text(json['payment_method']),
      accountNumberMasked: _text(json['account_number_masked']),
      transactionId: _text(json['transaction_id']),
      status: _text(json['status']),
      statusLabel: _text(json['status_label']),
      adminNote: _text(json['admin_note']),
      createdAt: _text(json['created_at']),
    );
  }
}

List<Map<String, dynamic>> _maps(dynamic value) {
  return (value as List? ?? const [])
      .whereType<Map>()
      .map((item) => item.cast<String, dynamic>())
      .toList();
}

String _text(dynamic value) => value?.toString() ?? '';
int _integer(dynamic value) =>
    value is num ? value.toInt() : int.tryParse('$value') ?? 0;
double _number(dynamic value) =>
    value is num ? value.toDouble() : double.tryParse('$value') ?? 0;
