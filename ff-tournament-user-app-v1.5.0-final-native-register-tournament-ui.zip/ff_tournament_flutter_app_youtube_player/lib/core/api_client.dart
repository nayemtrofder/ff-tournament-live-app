import 'dart:convert';

import 'package:http/http.dart' as http;

import '../models/app_update_info.dart';
import '../models/buy_gold.dart';
import '../models/live_session.dart';
import '../models/video_item.dart';
import '../models/notification_item.dart';
import '../models/tournament.dart';
import '../models/tournament_interaction.dart';
import '../models/user_profile.dart';
import '../models/wallet_transaction.dart';

class ApiException implements Exception {
  const ApiException(this.message, {this.statusCode});
  final String message;
  final int? statusCode;

  @override
  String toString() => message;
}

class HomePayload {
  const HomePayload({
    required this.live,
    required this.leaderboardPreview,
    required this.upcoming,
    required this.videos,
    required this.viewer,
    required this.unreadNotifications,
    required this.refreshAfterSeconds,
  });

  final LiveSession? live;
  final List<LeaderboardEntry> leaderboardPreview;
  final List<Tournament> upcoming;
  final List<VideoItem> videos;
  final UserProfile? viewer;
  final int unreadNotifications;
  final int refreshAfterSeconds;

  factory HomePayload.fromJson(Map<String, dynamic> json) {
    List<T> listOf<T>(
      dynamic source,
      T Function(Map<String, dynamic>) parser,
    ) => (source as List? ?? const [])
        .whereType<Map>()
        .map((item) => parser(item.cast<String, dynamic>()))
        .toList();
    final liveData = json['live'];
    final viewerData = json['viewer'];
    final notifications =
        (json['notifications'] as Map?)?.cast<String, dynamic>() ??
        const <String, dynamic>{};
    final rawRefresh = _integer(json['refresh_after_seconds']);
    return HomePayload(
      live: liveData is Map
          ? LiveSession.fromJson(liveData.cast<String, dynamic>())
          : null,
      leaderboardPreview: listOf(
        json['leaderboard_preview'],
        LeaderboardEntry.fromJson,
      ),
      upcoming: listOf(json['upcoming'], Tournament.fromJson),
      videos: listOf(json['videos'], VideoItem.fromJson),
      viewer: viewerData is Map
          ? UserProfile.fromJson(viewerData.cast<String, dynamic>())
          : null,
      unreadNotifications: _integer(notifications['unread_count']),
      refreshAfterSeconds: rawRefresh.clamp(10, 120).toInt(),
    );
  }
}

class WalletPayload {
  const WalletPayload({
    required this.gold,
    required this.heldGold,
    required this.winningBalance,
  });
  final double gold;
  final double heldGold;
  final double winningBalance;

  factory WalletPayload.fromJson(Map<String, dynamic> json) => WalletPayload(
    gold: _number(json['gold_balance'] ?? json['gold']),
    heldGold: _number(json['held_gold']),
    winningBalance: _number(json['winning_balance']),
  );
}

class HostSession {
  const HostSession({
    required this.sessionId,
    required this.liveId,
    required this.status,
    required this.matchTitle,
    required this.playbackUrl,
    required this.appEnabled,
  });

  final int sessionId;
  final String liveId;
  final String status;
  final String matchTitle;
  final String playbackUrl;
  final bool appEnabled;

  factory HostSession.fromJson(Map<String, dynamic> json) {
    final session = (json['session'] as Map?)?.cast<String, dynamic>() ?? json;
    final match =
        (json['match'] as Map?)?.cast<String, dynamic>() ??
        const <String, dynamic>{};
    return HostSession(
      sessionId: _integer(session['session_id'] ?? session['id']),
      liveId: _string(session['live_id']),
      status: _string(session['status']),
      matchTitle: _string(match['title']).isNotEmpty
          ? _string(match['title'])
          : _string(json['match_title'] ?? json['title']),
      playbackUrl: _string(session['playback_url']),
      appEnabled: session['app_enabled'] == true,
    );
  }
}

class ApiClient {
  ApiClient({required this.baseUrl, this.token, this.deviceId = ''});

  final String baseUrl;
  final String? token;
  final String deviceId;

  bool get configured => baseUrl.trim().isNotEmpty;

  Uri _uri(String path, [Map<String, String>? query]) {
    final cleanBase = baseUrl.replaceAll(RegExp(r'/+$'), '');
    final cleanPath = path.replaceFirst(RegExp(r'^/+'), '');
    return Uri.parse('$cleanBase/$cleanPath').replace(queryParameters: query);
  }

  Map<String, String> get _headers => <String, String>{
    'Accept': 'application/json',
    'Content-Type': 'application/json; charset=UTF-8',
    'Cache-Control': 'no-cache, no-store, max-age=0',
    'Pragma': 'no-cache',
    if (token?.isNotEmpty == true) 'Authorization': 'Bearer $token',
    if (deviceId.isNotEmpty) 'X-FFTS-Device-ID': deviceId,
  };

  Future<Map<String, dynamic>> _request(
    String method,
    String path, {
    Map<String, String>? query,
    Map<String, dynamic>? body,
  }) async {
    if (!configured) {
      throw const ApiException('এই build-এ Website API Base URL set করা হয়নি।');
    }
    try {
      final requestQuery = <String, String>{
        ...?query,
        // Prevent stale profile, Gold, comment and live responses when a CDN
        // or WordPress cache keeps a GET result longer than the app expects.
        '_ts': '${DateTime.now().millisecondsSinceEpoch}',
      };
      final uri = _uri(path, requestQuery);
      final http.Response response;
      switch (method) {
        case 'POST':
          response = await http
              .post(
                uri,
                headers: _headers,
                body: jsonEncode(body ?? const <String, dynamic>{}),
              )
              .timeout(const Duration(seconds: 20));
          break;
        default:
          response = await http
              .get(uri, headers: _headers)
              .timeout(const Duration(seconds: 20));
      }
      Map<String, dynamic> parsed = <String, dynamic>{};
      try {
        final decoded = jsonDecode(response.body);
        if (decoded is Map) parsed = decoded.cast<String, dynamic>();
      } catch (_) {
        throw const ApiException('Server JSON response দেয়নি।');
      }
      if (response.statusCode < 200 ||
          response.statusCode >= 300 ||
          parsed['success'] != true) {
        final message = _string(parsed['message']).isNotEmpty
            ? _string(parsed['message'])
            : _string(parsed['code']).isNotEmpty
            ? _string(parsed['code'])
            : 'Request complete হয়নি।';
        throw ApiException(message, statusCode: response.statusCode);
      }
      final data = parsed['data'];
      return data is Map ? data.cast<String, dynamic>() : <String, dynamic>{};
    } on ApiException {
      rethrow;
    } catch (_) {
      throw const ApiException(
        'Website-এর সাথে connect করা যায়নি। Internet, SSL এবং API configuration check করুন।',
      );
    }
  }

  Future<HomePayload> getHome() async =>
      HomePayload.fromJson(await _request('GET', 'home'));

  Future<LiveSession> getCurrentLive() async =>
      LiveSession.fromJson(await _request('GET', 'live/current'));

  Future<List<Tournament>> getTournaments({String status = 'upcoming'}) async {
    final data = await _request(
      'GET',
      'tournaments',
      query: <String, String>{'status': status, 'per_page': '100'},
    );
    final items = data['items'] ?? data['tournaments'] ?? const [];
    return (items as List? ?? const [])
        .whereType<Map>()
        .map((row) => Tournament.fromJson(row.cast<String, dynamic>()))
        .toList();
  }

  Future<Tournament> getTournament(
    int matchId, {
    bool trackView = true,
  }) async => Tournament.fromJson(
    await _request(
      'GET',
      'tournaments/$matchId',
      query: trackView ? const <String, String>{'track_view': '1'} : null,
    ),
  );

  Future<TournamentInteractions> getTournamentInteractions(int matchId) async {
    final data = await _request('GET', 'tournaments/$matchId/interactions');
    final interactions =
        (data['interactions'] as Map?)?.cast<String, dynamic>() ?? data;
    return TournamentInteractions.fromJson(interactions);
  }

  Future<TournamentInteractions> toggleTournamentLike(int matchId) async {
    final data = await _request('POST', 'tournaments/$matchId/like');
    final interactions =
        (data['interactions'] as Map?)?.cast<String, dynamic>() ?? data;
    return TournamentInteractions.fromJson(interactions);
  }

  Future<List<TournamentComment>> getTournamentComments(int matchId) async {
    final data = await _request('GET', 'tournaments/$matchId/comments');
    final items = data['items'] ?? data['comments'] ?? const [];
    return (items as List? ?? const [])
        .whereType<Map>()
        .map((row) => TournamentComment.fromJson(row.cast<String, dynamic>()))
        .toList();
  }

  Future<void> addTournamentComment(int matchId, String comment) async {
    await _request(
      'POST',
      'tournaments/$matchId/comments',
      body: <String, dynamic>{'comment': comment},
    );
  }

  Future<TournamentInteractions> trackTournamentView(int matchId) async {
    final data = await _request('POST', 'tournaments/$matchId/view');
    final interactions =
        (data['interactions'] as Map?)?.cast<String, dynamic>() ?? data;
    return TournamentInteractions.fromJson(interactions);
  }

  Future<LeaderboardData> getLeaderboard({
    String scope = 'live',
    String mode = '',
  }) async {
    final data = await _request(
      'GET',
      'leaderboards',
      query: <String, String>{
        'scope': scope,
        if (mode.isNotEmpty) 'mode': mode,
      },
    );
    return LeaderboardData.fromJson(data);
  }

  Future<List<VideoItem>> getVideos({
    String scope = 'today',
    int? matchId,
    String type = '',
  }) async {
    final data = await _request(
      'GET',
      'videos',
      query: <String, String>{
        'scope': scope,
        if (matchId != null && matchId > 0) 'match_id': '$matchId',
        if (type.isNotEmpty) 'type': type,
      },
    );
    final items = data['items'] ?? data['videos'] ?? const [];
    return (items as List? ?? const [])
        .whereType<Map>()
        .map((row) => VideoItem.fromJson(row.cast<String, dynamic>()))
        .toList();
  }

  Future<AppUpdateInfo> getAppUpdate(int versionCode) async =>
      AppUpdateInfo.fromJson(
        await _request(
          'GET',
          'app-update',
          query: <String, String>{'version_code': '$versionCode'},
        ),
      );

  Future<Map<String, dynamic>> login({
    required String username,
    required String password,
  }) => _request(
    'POST',
    'auth/login',
    body: <String, dynamic>{
      'username': username,
      'password': password,
      'device_label': 'FF Tournament Android',
    },
  );

  Future<Map<String, dynamic>> register({
    required String username,
    required String contact,
    required String password,
  }) => _request(
    'POST',
    'auth/register',
    body: <String, dynamic>{
      'username': username,
      'contact': contact,
      'password': password,
      'device_label': 'FF Tournament Android',
    },
  );

  Future<UserProfile> getProfile() async =>
      UserProfile.fromJson(await _request('GET', 'profile'));

  Future<UserProfile> updateProfile({
    required String ign,
    required String ffUid,
    String guild = '',
    String server = '',
    String gameMode = '',
  }) async {
    final data = await _request(
      'POST',
      'profile',
      body: <String, dynamic>{
        'ign': ign,
        'ff_uid': ffUid,
        'guild': guild,
        'server': server,
        'game_mode': gameMode,
      },
    );
    final user = data['user'];
    return UserProfile.fromJson(
      user is Map ? user.cast<String, dynamic>() : data,
    );
  }

  Future<void> logout() async {
    await _request('POST', 'auth/logout');
  }

  Future<WalletPayload> getWallet() async =>
      WalletPayload.fromJson(await _request('GET', 'wallet'));

  Future<WalletHistoryPayload> getWalletHistory() async =>
      WalletHistoryPayload.fromJson(
        await _request(
          'GET',
          'wallet/history',
          query: <String, String>{'per_page': '50'},
        ),
      );

  Future<MyMatchesPayload> getMyMatches({String status = 'all'}) async =>
      MyMatchesPayload.fromJson(
        await _request(
          'GET',
          'my-matches',
          query: <String, String>{'status': status},
        ),
      );

  Future<NotificationsPayload> getNotifications() async =>
      NotificationsPayload.fromJson(
        await _request(
          'GET',
          'notifications',
          query: <String, String>{'per_page': '50'},
        ),
      );

  Future<int> markNotificationRead(int notificationId) async {
    final data = await _request('POST', 'notifications/$notificationId/read');
    return _integer(data['unread_count']);
  }

  Future<int> markAllNotificationsRead() async {
    final data = await _request('POST', 'notifications/read-all');
    return _integer(data['unread_count']);
  }

  Future<Map<String, dynamic>> joinTournament(int matchId) =>
      _request('POST', 'tournaments/$matchId/join');

  Future<BuyGoldCatalog> getBuyGoldCatalog() async {
    return BuyGoldCatalog.fromJson(await _request('GET', 'buy-gold/catalog'));
  }

  Future<List<BuyGoldOrder>> getBuyGoldOrders({
    int page = 1,
    int perPage = 20,
    String status = 'all',
  }) async {
    final data = await _request(
      'GET',
      'buy-gold/orders',
      query: <String, String>{
        'page': '$page',
        'per_page': '$perPage',
        'status': status,
      },
    );
    final rows = data['items'] ?? data['orders'] ?? const [];
    return (rows as List? ?? const [])
        .whereType<Map>()
        .map((item) => BuyGoldOrder.fromJson(item.cast<String, dynamic>()))
        .toList();
  }

  Future<Map<String, dynamic>> createBuyGoldOrder({
    required int productId,
    required String paymentMethod,
    String accountNumber = '',
    String transactionId = '',
  }) {
    return _request(
      'POST',
      'buy-gold/order',
      body: <String, dynamic>{
        'product_id': productId,
        'payment_method': paymentMethod,
        if (accountNumber.trim().isNotEmpty)
          'account_number': accountNumber.trim(),
        if (transactionId.trim().isNotEmpty)
          'transaction_id': transactionId.trim(),
      },
    );
  }

  Future<String> getBuyGoldUrl() async {
    final data = await _request('GET', 'buy-gold-url');
    return _string(data['buy_gold_url']).isNotEmpty
        ? _string(data['buy_gold_url'])
        : _string(data['url']);
  }

  Future<HostSession> verifyLive(String liveId) async => HostSession.fromJson(
    await _request(
      'POST',
      'live/verify',
      body: <String, dynamic>{'live_id': liveId},
    ),
  );

  Future<HostSession> startLive({int? sessionId, String? liveId}) async =>
      HostSession.fromJson(
        await _request(
          'POST',
          'live/start',
          body: <String, dynamic>{
            if (sessionId != null) 'session_id': sessionId,
            if (liveId?.isNotEmpty == true) 'live_id': liveId,
          },
        ),
      );

  Future<HostSession> endLive({int? sessionId, String? liveId}) async =>
      HostSession.fromJson(
        await _request(
          'POST',
          'live/end',
          body: <String, dynamic>{
            if (sessionId != null) 'session_id': sessionId,
            if (liveId?.isNotEmpty == true) 'live_id': liveId,
          },
        ),
      );
}

String _string(dynamic value) => value?.toString() ?? '';
int _integer(dynamic value) =>
    value is num ? value.toInt() : int.tryParse('$value') ?? 0;
double _number(dynamic value) =>
    value is num ? value.toDouble() : double.tryParse('$value') ?? 0;
