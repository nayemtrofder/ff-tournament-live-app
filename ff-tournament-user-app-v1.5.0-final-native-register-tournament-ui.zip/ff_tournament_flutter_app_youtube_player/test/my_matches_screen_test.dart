import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';

import 'package:ff_tournament_app/models/tournament.dart';
import 'package:ff_tournament_app/models/tournament_interaction.dart';
import 'package:ff_tournament_app/widgets/compact_tournament_card.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  testWidgets('compact tournament card keeps a long title to two lines on a narrow screen', (WidgetTester tester) async {
    final tournament = Tournament(
      id: 1,
      title: 'A very long tournament title that should stay readable and not overlap on small Android phones',
      mode: 'Solo',
      prize: '৳1,000',
      entryGold: 100,
      slots: 100,
      joined: 40,
      slotsLeft: 60,
      startAt: '2026-07-08T20:00:00Z',
      matchDate: '08 Jul',
      matchTime: '20:00',
      status: 'upcoming',
      description: '',
      rules: '',
      thumbnailUrl: '',
      bannerUrl: '',
      resultPublished: false,
      isJoined: true,
      canJoin: false,
      roomId: '',
      roomPassword: '',
      leaderboard: const [],
      myKills: 0,
      myPlacement: 0,
      myPoints: 0,
      prizeCredited: 0,
      interactions: const TournamentInteractions(
        bannerAttachmentId: 0,
        bannerUrl: '',
        likeCount: 0,
        userHasLiked: false,
        likesEnabled: false,
        commentsEnabled: false,
        commentsLocked: true,
        canComment: false,
        commentCount: 0,
        viewCount: 0,
        showViewCount: false,
      ),
      videos: const [],
      comments: const [],
      liveVideo: null,
    );

    await tester.binding.setSurfaceSize(const Size(360, 800));
    addTearDown(() => tester.binding.setSurfaceSize(null));

    await tester.pumpWidget(
      MaterialApp(
        home: Scaffold(
          body: Center(
            child: SizedBox(
              width: 328,
              child: CompactTournamentCard(
                tournament: tournament,
                onOpen: () {},
                primaryLabel: 'VIEW MATCH',
                primaryIcon: Icons.arrow_forward_rounded,
                primaryColor: Colors.cyan,
              ),
            ),
          ),
        ),
      ),
    );

    final title = tester.widget<Text>(find.text(tournament.title));
    expect(title.maxLines, 2);
    expect(title.overflow, TextOverflow.ellipsis);
  });
}
