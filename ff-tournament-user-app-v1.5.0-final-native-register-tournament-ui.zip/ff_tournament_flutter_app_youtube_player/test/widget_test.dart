import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';

import 'package:ff_tournament_app/models/live_session.dart';
import 'package:ff_tournament_app/widgets/hero_carousel.dart';

void main() {
  testWidgets('live hero slide renders animated effects', (WidgetTester tester) async {
    final live = LiveSession(
      isLive: true,
      status: 'live',
      title: 'Live Tournament',
      matchId: 1,
      match: null,
      startedAt: '',
      endsAt: '',
      playbackUrl: '',
      youtubeUrl: '',
      facebookUrl: '',
      appEnabled: true,
      linkedVideo: null,
    );

    await tester.pumpWidget(MaterialApp(
      home: Scaffold(
        body: HeroCarousel(items: [HeroSlideData.live(live, () {})]),
      ),
    ));

    expect(find.text('WATCH LIVE'), findsOneWidget);
    expect(find.byType(AnimatedBuilder), findsWidgets);
  });
}
