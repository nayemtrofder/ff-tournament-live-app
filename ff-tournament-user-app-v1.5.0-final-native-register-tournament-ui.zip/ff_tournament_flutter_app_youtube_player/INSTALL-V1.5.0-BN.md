# v1.5.0 Source Install — Codespaces

Bridge v1.8.0 Website-এ active থাকলে শুধু এই Flutter source update করবেন।

## Replace করার আগে

বর্তমান project backup নিন:

```bash
cd /workspaces/ff-tournament-live-app/flutter_app
cp -r ff_tournament_flutter_app_youtube_player ff_tournament_flutter_app_youtube_player-backup-v1.4
```

## New source বসানো

ZIP upload করার পর project parent folder-এ:

```bash
cd /workspaces/ff-tournament-live-app/flutter_app
rm -rf ff_tournament_flutter_app_youtube_player
unzip /workspaces/UPLOAD_ZIP_NAME.zip
cd ff_tournament_flutter_app_youtube_player
flutter pub get
flutter analyze
flutter test
```

যদি analyze/test-এ error না থাকে:

```bash
flutter build apk --release --dart-define=FFTS_API_BASE_URL=https://fftrustbd.com/wp-json/ffts-app/v1
```

APK path:

```text
build/app/outputs/flutter-apk/app-release.apk
```

## Test checklist

1. Login screen-এ `CREATE NEW ACCOUNT` আছে।
2. Register করলে auto login হয়ে Game Profile screen খুলে।
3. Tournament tab-এ search ও filters কাজ করে।
4. My Matches-এ bottom navigation থাকে এবং text overlap হয় না।
5. Buy Gold আগের native page-ই থাকে।
6. Wallet-এ Winning Balance `৳ BDT` format-এ থাকে।
