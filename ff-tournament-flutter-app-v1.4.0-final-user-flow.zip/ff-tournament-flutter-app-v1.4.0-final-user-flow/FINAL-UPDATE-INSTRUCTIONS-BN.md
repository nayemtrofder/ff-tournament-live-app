# Final Update Build নির্দেশনা — FF Tournament App v1.4.0

## এই update-এ কী replace হবে
এই ZIP থেকে শুধু নিচের ৩টি জিনিস আপনার Codespaces Flutter project-এ replace করবেন:

```text
lib/
assets/
pubspec.yaml
```

`android/` folder delete বা replace করবেন না।

## ১. Codespaces-এ ZIP upload ও pull
GitHub repository-তে ZIP upload করার পর Codespaces Terminal-এ:

```bash
git pull
```

## ২. ZIP extract ও files replace
Project repository root-এ নিচের command দিন। ZIP-এর filename আপনার upload করা নাম অনুযায়ী হবে:

```bash
rm -rf /tmp/ff_app_final && mkdir -p /tmp/ff_app_final && unzip -q ff-tournament-flutter-app-v1.4.0-final-user-flow.zip -d /tmp/ff_app_final
UPDATE_DIR="$(dirname "$(find /tmp/ff_app_final -name pubspec.yaml -print -quit)")"
APP_DIR="$PWD/flutter_app/ff_tournament_flutter_app_youtube_player"
test -d "$UPDATE_DIR/lib" && test -d "$UPDATE_DIR/assets" && test -f "$UPDATE_DIR/pubspec.yaml" && test -d "$APP_DIR" && rm -rf "$APP_DIR/lib" "$APP_DIR/assets" && cp -R "$UPDATE_DIR/lib" "$APP_DIR/lib" && cp -R "$UPDATE_DIR/assets" "$APP_DIR/assets" && cp "$UPDATE_DIR/pubspec.yaml" "$APP_DIR/pubspec.yaml"
cd "$APP_DIR"
```

## ৩. Icon generate ও APK build

```bash
flutter pub get
dart run flutter_launcher_icons
flutter build apk --release --dart-define=FFTS_API_BASE_URL=https://fftrustbd.com/wp-json/ffts-app/v1
```

Build শেষ হলে APK path:

```text
build/app/outputs/flutter-apk/app-release.apk
```

## ৪. GitHub Release upload
নতুন release tag create করুন:

```bash
gh release create v1.4.0 build/app/outputs/flutter-apk/app-release.apk --title "FF Tournament App v1.4.0" --notes "Profile Edit, In-App Buy Gold, Header Gold, instant Like/Comment refresh and new icon"
```

Release আগে থেকেই থাকলে:

```bash
gh release upload v1.4.0 build/app/outputs/flutter-apk/app-release.apk --clobber
```

## ৫. WordPress App Update Center
WordPress → **FF Tournament → Live & App API → App Update Center**:

```text
Latest Version: 1.4.0
Version Code: 6
APK Download Link: GitHub Release-এর app-release.apk direct link
Update Type: Optional
Minimum Supported Version Code: 0
```

## Build-এর আগে জরুরি
আগে **FF Tournament Live Bridge v1.6.0** update করা থাকতে হবে।
