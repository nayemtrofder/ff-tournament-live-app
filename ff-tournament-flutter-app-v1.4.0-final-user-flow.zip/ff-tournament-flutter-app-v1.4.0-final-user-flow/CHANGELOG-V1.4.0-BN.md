# FF Tournament App v1.4.0 — Final User Flow Update

## ১. Like এখন কাজ করবে
- Tournament card-এর heart count এখন tappable।
- Like/Unlike করলে heart ও count সঙ্গে সঙ্গে update হবে।
- Login না থাকলে Login message দেখাবে।
- Tournament Details-এও Like/Unlike success message দেখাবে।

## ২. Comment দ্রুত দেখা যাবে
- Comment successfully post হলে `Comment posted` message দেখাবে।
- Comment list ও count নতুন API response দিয়ে reload হবে।
- API timestamp + server no-cache header ব্যবহার করবে, তাই old comment cache হওয়ার সম্ভাবনা কম।

## ৩. Profile / Gold / Live দ্রুত refresh
- App API request-এ cache-busting timestamp যোগ হয়েছে।
- Profile tab খুললে এবং App foreground-এ ফিরলে fresh profile reload হয়।
- Home response-এর viewer data AppState-এ বসে Header Gold chip-ও update হয়।
- Home-এর Live priority check আগের মতো 5 সেকেন্ডে চলবে।

## ৪. App থেকে Profile Edit
- IGN, FF UID, Guild, Server, Preferred mode App থেকেই edit করা যাবে।
- FF UID + IGN ছাড়া Join করতে না পারলে Profile Edit দিয়ে পূরণ করা যাবে।
- Profile photo/WhatsApp/Telegram-এর জন্য Website editor fallback আছে।

## ৫. In-App Buy Gold
- Header Gold chip-এর `+`, Profile এবং Wallet থেকে Buy Gold open হবে।
- Payment page App-এর ভিতরের WebView-তে খুলবে।
- সমস্যা হলে `OPEN IN WEBSITE` fallback আছে।
- Payment শেষে `REFRESH GOLD` দিয়ে নতুন balance দেখা যাবে।

## ৬. Header Gold Chip
- Home header-এ বর্তমান Gold এবং `+` button দেখা যাবে।
- Tap করলে Buy Gold page খোলে।

## ৭. New Launcher Icon
- নতুন trophy icon Android launcher icon হিসেবে generate হবে।
- App header-এও একই icon ব্যবহার করা হয়েছে।

## Version
- App Version: **1.4.0**
- Version Code: **6**
