import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:webview_flutter/webview_flutter.dart';

import '../core/api_client.dart';
import '../core/app_state.dart';
import '../core/app_theme.dart';
import '../widgets/common.dart';

/// Opens the existing website Buy Gold/payment flow inside the app. The Bridge
/// issues a short-lived one-time website login link, so the user does not need
/// to log in again inside WebView. A browser fallback remains available.
class BuyGoldScreen extends StatefulWidget {
  const BuyGoldScreen({super.key});

  @override
  State<BuyGoldScreen> createState() => _BuyGoldScreenState();
}

class _BuyGoldScreenState extends State<BuyGoldScreen> with WidgetsBindingObserver {
  WebViewController? _controller;
  String _url = '';
  String _error = '';
  bool _loading = true;
  bool _paymentSignal = false;
  bool _refreshingGold = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _openPayment();
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) {
      _refreshGold(silent: true);
    }
  }

  bool _isPaymentResultUrl(String url) {
    final normalized = url.toLowerCase();
    return normalized.contains('payment-success') ||
        normalized.contains('ffts_ssl=success') ||
        normalized.contains('payment-failed') ||
        normalized.contains('ffts_ssl=fail');
  }

  Future<void> _openPayment() async {
    setState(() {
      _loading = true;
      _error = '';
    });
    try {
      final url = await context.read<AppState>().api.getBuyGoldUrl();
      if (url.trim().isEmpty) throw const ApiException('Buy Gold link পাওয়া যায়নি।');
      final controller = WebViewController()
        ..setJavaScriptMode(JavaScriptMode.unrestricted)
        ..setNavigationDelegate(
          NavigationDelegate(
            onPageStarted: (_) {
              if (mounted) setState(() => _loading = true);
            },
            onPageFinished: (url) async {
              if (!mounted) return;
              setState(() => _loading = false);
              if (_isPaymentResultUrl(url)) {
                _paymentSignal = true;
                await _refreshGold(silent: true);
              }
            },
            onWebResourceError: (error) {
              if (!mounted) return;
              setState(() {
                _loading = false;
                _error = 'Payment page load করা যায়নি। আবার চেষ্টা করুন অথবা Website-এ খুলুন।';
              });
            },
            onNavigationRequest: (request) async {
              final uri = Uri.tryParse(request.url);
              if (uri == null) return NavigationDecision.prevent;
              if (uri.scheme != 'http' && uri.scheme != 'https') {
                await launchUrl(uri, mode: LaunchMode.externalApplication);
                return NavigationDecision.prevent;
              }
              return NavigationDecision.navigate;
            },
          ),
        )
        ..loadRequest(Uri.parse(url));
      if (mounted) {
        setState(() {
          _url = url;
          _controller = controller;
        });
      }
    } on ApiException catch (error) {
      if (mounted) {
        setState(() {
          _loading = false;
          _error = error.message;
        });
      }
    }
  }

  Future<void> _refreshGold({bool silent = false}) async {
    if (_refreshingGold) return;
    setState(() => _refreshingGold = true);
    try {
      await context.read<AppState>().refreshProfile();
      if (mounted && !silent) showAppMessage(context, 'Gold balance refresh হয়েছে।');
    } on ApiException catch (error) {
      if (mounted && !silent) showAppMessage(context, error.message, error: true);
    } finally {
      if (mounted) setState(() => _refreshingGold = false);
    }
  }

  Future<void> _openInBrowser() async {
    try {
      // Request a fresh token because the previous one may already have been
      // consumed inside WebView during the first attempt.
      final url = await context.read<AppState>().api.getBuyGoldUrl();
      if (!await launchUrl(Uri.parse(url), mode: LaunchMode.externalApplication)) {
        throw const ApiException('Website link open করা যায়নি।');
      }
    } on ApiException catch (error) {
      if (mounted) showAppMessage(context, error.message, error: true);
    }
  }

  Future<bool> _onBack() async {
    if (mounted) Navigator.pop(context, _paymentSignal);
    return false;
  }

  @override
  Widget build(BuildContext context) {
    final user = context.watch<AppState>().user;
    return WillPopScope(
      onWillPop: _onBack,
      child: Scaffold(
        appBar: AppBar(
          title: const Text('Buy Gold'),
          leading: IconButton(onPressed: _onBack, icon: const Icon(Icons.arrow_back_rounded)),
          actions: <Widget>[
            IconButton(
              tooltip: 'Refresh Gold',
              onPressed: _refreshingGold ? null : () => _refreshGold(),
              icon: _refreshingGold
                  ? const SizedBox.square(dimension: 19, child: CircularProgressIndicator(strokeWidth: 2, color: AppColors.gold))
                  : const Icon(Icons.refresh_rounded),
            ),
            IconButton(
              tooltip: 'Open in Website',
              onPressed: _openInBrowser,
              icon: const Icon(Icons.open_in_browser_rounded),
            ),
          ],
        ),
        body: Column(
          children: <Widget>[
            Container(
              width: double.infinity,
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
              decoration: BoxDecoration(color: AppColors.gold.withValues(alpha: .08), border: const Border(bottom: BorderSide(color: AppColors.border))),
              child: Row(
                children: <Widget>[
                  const Icon(Icons.workspace_premium_rounded, color: AppColors.gold, size: 18),
                  const SizedBox(width: 7),
                  Expanded(child: Text('Current Gold: ${user?.gold.toStringAsFixed(0) ?? '—'}', style: const TextStyle(fontWeight: FontWeight.w900, color: AppColors.gold))),
                  TextButton(onPressed: _refreshingGold ? null : () => _refreshGold(), child: const Text('REFRESH')),
                ],
              ),
            ),
            Expanded(
              child: _error.isNotEmpty
                  ? Center(
                      child: Padding(
                        padding: const EdgeInsets.all(16),
                        child: ErrorPanel(
                          message: _error,
                          onRetry: _openPayment,
                        ),
                      ),
                    )
                  : Stack(
                      children: <Widget>[
                        if (_controller != null) WebViewWidget(controller: _controller!),
                        if (_loading) const Center(child: CircularProgressIndicator(color: AppColors.orange)),
                      ],
                    ),
            ),
            Container(
              width: double.infinity,
              padding: const EdgeInsets.fromLTRB(16, 10, 16, 14),
              decoration: const BoxDecoration(color: AppColors.surface, border: Border(top: BorderSide(color: AppColors.border))),
              child: Row(
                children: <Widget>[
                  Expanded(
                    child: OutlinedButton.icon(
                      onPressed: _openInBrowser,
                      icon: const Icon(Icons.open_in_browser_rounded),
                      label: const Text('OPEN IN WEBSITE'),
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: FilledButton.icon(
                      onPressed: _refreshingGold ? null : () => _refreshGold(),
                      icon: const Icon(Icons.account_balance_wallet_rounded),
                      label: const Text('REFRESH GOLD'),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
