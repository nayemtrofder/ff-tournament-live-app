import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../core/app_state.dart';
import '../core/app_theme.dart';
import '../models/user_profile.dart';
import '../widgets/common.dart';
import '../widgets/app_update_prompt.dart';
import 'host_live_screen.dart';
import 'login_screen.dart';
import 'notifications_screen.dart';
import 'wallet_screen.dart';
import 'profile_edit_screen.dart';
import 'buy_gold_screen.dart';

class ProfileScreen extends StatefulWidget {
  const ProfileScreen({super.key});

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> with WidgetsBindingObserver {
  Future<UserProfile>? _future;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    WidgetsBinding.instance.addPostFrameCallback((_) => _load());
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed && context.read<AppState>().isLoggedIn) {
      _load();
    }
  }

  Future<UserProfile> _fetchProfile() async {
    final state = context.read<AppState>();
    final user = await state.api.getProfile();
    state.updateUser(user);
    return user;
  }

  void _load() {
    final state = context.read<AppState>();
    if (state.isLoggedIn) setState(() => _future = _fetchProfile());
  }

  Future<void> _refresh() async {
    _load();
    final future = _future;
    if (future != null) await future;
  }

  Future<void> _openProfileEdit(UserProfile user) async {
    final saved = await Navigator.push<bool>(context, MaterialPageRoute<bool>(builder: (_) => ProfileEditScreen(user: user)));
    if (saved == true && mounted) await _refresh();
  }

  Future<void> _openBuyGold() async {
    await Navigator.push<bool>(context, MaterialPageRoute<bool>(builder: (_) => const BuyGoldScreen()));
    if (mounted) await _refresh();
  }

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();
    if (!state.isLoggedIn) {
      return Center(
        child: EmptyState(
          icon: Icons.person_outline_rounded,
          title: 'Player profile locked',
          message: 'Login করলে আপনার profile photo, FF UID, stats ও Gold balance দেখা যাবে।',
          action: FilledButton.icon(
            onPressed: () async {
              await Navigator.push(context, MaterialPageRoute<bool>(builder: (_) => const LoginScreen()));
              if (mounted) _load();
            },
            icon: const Icon(Icons.login_rounded),
            label: const Text('LOGIN'),
          ),
        ),
      );
    }
    return FutureBuilder<UserProfile>(
      future: _future,
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) return const PageLoading(label: 'Profile loading...');
        if (snapshot.hasError) {
          return Padding(
            padding: const EdgeInsets.all(16),
            child: ErrorPanel(message: snapshot.error.toString(), onRetry: _load),
          );
        }
        final user = state.user ?? snapshot.data;
        if (user == null) {
          return Padding(
            padding: const EdgeInsets.all(16),
            child: ErrorPanel(message: 'Profile data পাওয়া যায়নি।', onRetry: _load),
          );
        }
        return RefreshIndicator(
          color: AppColors.orange,
          onRefresh: _refresh,
          child: ListView(
            padding: const EdgeInsets.fromLTRB(16, 16, 16, 30),
            physics: const AlwaysScrollableScrollPhysics(),
            children: <Widget>[
              Row(
                children: <Widget>[
                  const Expanded(child: Text('Profile', style: TextStyle(fontSize: 24, fontWeight: FontWeight.w900))),
                  IconButton(onPressed: _load, icon: const Icon(Icons.refresh_rounded)),
                ],
              ),
              const SizedBox(height: 11),
              _ProfileHero(user: user, onEdit: () => _openProfileEdit(user)),
              const SizedBox(height: 15),
              _WalletQuickCard(user: user),
              const SizedBox(height: 22),
              const SectionHeading(title: 'Player Stats'),
              const SizedBox(height: 9),
              _StatsGrid(user: user),
              const SizedBox(height: 22),
              const SectionHeading(title: 'Account'),
              const SizedBox(height: 9),
              SurfaceBox(
                padding: EdgeInsets.zero,
                child: Column(
                  children: <Widget>[
                    _ProfileRow(icon: Icons.badge_outlined, label: 'FF UID', value: user.ffUid.isEmpty ? 'Not added' : user.ffUid),
                    const Divider(height: 1),
                    _ProfileRow(icon: Icons.groups_outlined, label: 'Guild', value: user.guild.isEmpty ? 'Not added' : user.guild),
                    const Divider(height: 1),
                    _ProfileRow(icon: Icons.public_rounded, label: 'Server', value: user.server.isEmpty ? 'Not added' : user.server),
                    const Divider(height: 1),
                    _ProfileRow(icon: Icons.sports_esports_rounded, label: 'Preferred mode', value: user.gameMode.isEmpty ? 'Not added' : user.gameMode),
                  ],
                ),
              ),
              const SizedBox(height: 22),
              const SectionHeading(title: 'Account Actions'),
              const SizedBox(height: 9),
              SurfaceBox(
                padding: EdgeInsets.zero,
                child: Column(
                  children: <Widget>[
                    ListTile(
                      leading: const Icon(Icons.edit_outlined, color: AppColors.cyan),
                      title: const Text('Edit Profile', style: TextStyle(fontWeight: FontWeight.w800)),
                      subtitle: const Text('FF UID, IGN, Guild, Server, Mode', style: TextStyle(color: AppColors.muted, fontSize: 11)),
                      trailing: const Icon(Icons.chevron_right_rounded),
                      onTap: () => _openProfileEdit(user),
                    ),
                    const Divider(height: 1),
                    ListTile(
                      leading: const Icon(Icons.add_circle_outline_rounded, color: AppColors.gold),
                      title: const Text('Buy Gold', style: TextStyle(fontWeight: FontWeight.w800)),
                      subtitle: const Text('Pay securely inside the app', style: TextStyle(color: AppColors.muted, fontSize: 11)),
                      trailing: const Icon(Icons.chevron_right_rounded),
                      onTap: _openBuyGold,
                    ),
                    const Divider(height: 1),
                    ListTile(
                      leading: const Icon(Icons.notifications_outlined, color: AppColors.orange),
                      title: const Text('Notifications', style: TextStyle(fontWeight: FontWeight.w800)),
                      trailing: const Icon(Icons.chevron_right_rounded),
                      onTap: () => Navigator.push(context, MaterialPageRoute<void>(builder: (_) => const NotificationsScreen())),
                    ),
                    const Divider(height: 1),
                    ListTile(
                      leading: const Icon(Icons.system_update_rounded, color: AppColors.green),
                      title: const Text('App Update', style: TextStyle(fontWeight: FontWeight.w800)),
                      subtitle: const Text('Check the latest app version', style: TextStyle(color: AppColors.muted, fontSize: 11)),
                      trailing: const Icon(Icons.chevron_right_rounded),
                      onTap: () => checkForAppUpdate(context, showNoUpdateMessage: true),
                    ),
                    if (user.canStream) ...<Widget>[
                      const Divider(height: 1),
                      ListTile(
                        leading: const Icon(Icons.sensors_rounded, color: AppColors.red),
                        title: const Text('Host Live Control', style: TextStyle(fontWeight: FontWeight.w800)),
                        subtitle: const Text('Only Stream Host / Admin', style: TextStyle(color: AppColors.muted, fontSize: 11)),
                        trailing: const Icon(Icons.chevron_right_rounded),
                        onTap: () => Navigator.push(context, MaterialPageRoute<void>(builder: (_) => const HostLiveScreen())),
                      ),
                    ],
                    const Divider(height: 1),
                    ListTile(
                      leading: const Icon(Icons.logout_rounded, color: AppColors.red),
                      title: const Text('Logout', style: TextStyle(color: AppColors.red, fontWeight: FontWeight.w800)),
                      onTap: () async {
                        await state.logout();
                        if (mounted) showAppMessage(context, 'Logged out.');
                      },
                    ),
                  ],
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}

class _ProfileHero extends StatelessWidget {
  const _ProfileHero({required this.user, this.onEdit});
  final UserProfile user;
  final VoidCallback? onEdit;

  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.all(18),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(24),
          gradient: const LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: <Color>[Color(0xFF203C63), Color(0xFF101827)]),
          border: Border.all(color: AppColors.cyan.withValues(alpha: .42)),
        ),
        child: Row(
          children: <Widget>[
            NetworkAvatar(url: user.avatarUrl, name: user.displayName, radius: 42),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Text(user.displayName, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 21, fontWeight: FontWeight.w900)),
                  const SizedBox(height: 5),
                  Text(user.username, style: const TextStyle(color: AppColors.muted)),
                  const SizedBox(height: 10),
                  Wrap(
                    spacing: 7,
                    runSpacing: 6,
                    children: <Widget>[
                      if (user.profileComplete) const StatusBadge(status: 'PROFILE READY') else const StatusBadge(status: 'PROFILE INCOMPLETE'),
                      if (user.gameMode.isNotEmpty) GoldPill(value: user.gameMode, compact: true),
                    ],
                  ),
                ],
              ),
            ),
            if (onEdit != null)
              IconButton(
                tooltip: 'Edit Profile',
                onPressed: onEdit,
                icon: const Icon(Icons.edit_outlined, color: AppColors.cyan),
              ),
          ],
        ),
      );
}

class _WalletQuickCard extends StatelessWidget {
  const _WalletQuickCard({required this.user});
  final UserProfile user;

  @override
  Widget build(BuildContext context) => InkWell(
        onTap: () => Navigator.push(context, MaterialPageRoute<void>(builder: (_) => const WalletScreen())),
        borderRadius: BorderRadius.circular(20),
        child: SurfaceBox(
          color: AppColors.gold.withValues(alpha: .09),
          borderColor: AppColors.gold.withValues(alpha: .42),
          child: Row(
            children: <Widget>[
              Container(
                padding: const EdgeInsets.all(11),
                decoration: BoxDecoration(color: AppColors.gold.withValues(alpha: .16), borderRadius: BorderRadius.circular(14)),
                child: const Icon(Icons.account_balance_wallet_rounded, color: AppColors.gold),
              ),
              const SizedBox(width: 11),
              const Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Text('Gold Wallet', style: TextStyle(fontWeight: FontWeight.w900)),
                    SizedBox(height: 3),
                    Text('Available balance', style: TextStyle(color: AppColors.muted, fontSize: 12)),
                  ],
                ),
              ),
              Text(user.gold.toStringAsFixed(0), style: const TextStyle(fontSize: 23, fontWeight: FontWeight.w900, color: AppColors.gold)),
              const SizedBox(width: 4),
              const Icon(Icons.chevron_right_rounded, color: AppColors.gold),
            ],
          ),
        ),
      );
}

class _StatsGrid extends StatelessWidget {
  const _StatsGrid({required this.user});
  final UserProfile user;

  @override
  Widget build(BuildContext context) => GridView.count(
        crossAxisCount: 2,
        shrinkWrap: true,
        physics: const NeverScrollableScrollPhysics(),
        mainAxisSpacing: 9,
        crossAxisSpacing: 9,
        childAspectRatio: 2.0,
        children: <Widget>[
          _PlayerStat(label: 'GLOBAL RANK', value: user.rank > 0 ? '#${user.rank}' : '—', color: AppColors.cyan),
          _PlayerStat(label: 'MATCHES', value: '${user.totalMatches}', color: AppColors.cyan),
          _PlayerStat(label: 'WINS', value: '${user.totalWins}', color: AppColors.gold),
          _PlayerStat(label: 'KILLS', value: '${user.totalKills}', color: AppColors.orange),
        ],
      );
}

class _PlayerStat extends StatelessWidget {
  const _PlayerStat({required this.label, required this.value, required this.color});
  final String label;
  final String value;
  final Color color;

  @override
  Widget build(BuildContext context) => SurfaceBox(
        padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 8),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Text(value, style: TextStyle(fontSize: 20, color: color, fontWeight: FontWeight.w900)),
            const SizedBox(height: 3),
            Text(label, style: const TextStyle(color: AppColors.muted, fontWeight: FontWeight.w900, fontSize: 9)),
          ],
        ),
      );
}

class _ProfileRow extends StatelessWidget {
  const _ProfileRow({required this.icon, required this.label, required this.value});
  final IconData icon;
  final String label;
  final String value;

  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 13),
        child: Row(
          children: <Widget>[
            Icon(icon, size: 20, color: AppColors.muted),
            const SizedBox(width: 11),
            Expanded(child: Text(label, style: const TextStyle(fontWeight: FontWeight.w800))),
            Flexible(
              child: Text(
                value,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(color: AppColors.cyan, fontWeight: FontWeight.w800),
              ),
            ),
          ],
        ),
      );
}
