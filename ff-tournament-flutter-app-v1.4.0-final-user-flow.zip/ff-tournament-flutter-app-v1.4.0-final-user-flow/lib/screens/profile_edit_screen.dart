import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:url_launcher/url_launcher.dart';

import '../core/api_client.dart';
import '../core/app_state.dart';
import '../core/app_theme.dart';
import '../models/user_profile.dart';
import '../widgets/common.dart';

class ProfileEditScreen extends StatefulWidget {
  const ProfileEditScreen({super.key, required this.user});
  final UserProfile user;

  @override
  State<ProfileEditScreen> createState() => _ProfileEditScreenState();
}

class _ProfileEditScreenState extends State<ProfileEditScreen> {
  final _formKey = GlobalKey<FormState>();
  late final TextEditingController _ignController;
  late final TextEditingController _uidController;
  late final TextEditingController _guildController;
  late String _server;
  late String _mode;
  bool _saving = false;

  static const _baseServers = <String>[
    'Bangladesh',
    'India',
    'Singapore',
    'Middle East',
    'Brazil',
    'Europe',
    'US',
    'Other',
  ];
  static const _baseModes = <String>['Any', 'Solo', 'Duo', 'Squad'];

  @override
  void initState() {
    super.initState();
    _ignController = TextEditingController(text: widget.user.ign);
    _uidController = TextEditingController(text: widget.user.ffUid);
    _guildController = TextEditingController(text: widget.user.guild);
    _server = widget.user.server.isEmpty ? 'Bangladesh' : widget.user.server;
    _mode = widget.user.gameMode.isEmpty ? 'Any' : widget.user.gameMode;
  }

  @override
  void dispose() {
    _ignController.dispose();
    _uidController.dispose();
    _guildController.dispose();
    super.dispose();
  }

  List<String> _choices(List<String> values, String current) {
    if (current.trim().isEmpty || values.contains(current)) return values;
    return <String>[current, ...values];
  }

  Future<void> _openWebsiteEditor() async {
    final url = widget.user.profileEditUrl;
    if (url.isEmpty || !await launchUrl(Uri.parse(url), mode: LaunchMode.externalApplication)) {
      if (mounted) showAppMessage(context, 'Website profile page open করা যায়নি।', error: true);
    }
  }

  Future<void> _save() async {
    if (_saving || !(_formKey.currentState?.validate() ?? false)) return;
    setState(() => _saving = true);
    try {
      final state = context.read<AppState>();
      final updated = await state.api.updateProfile(
        ign: _ignController.text.trim(),
        ffUid: _uidController.text.trim(),
        guild: _guildController.text.trim(),
        server: _server,
        gameMode: _mode,
      );
      state.updateUser(updated);
      if (!mounted) return;
      showAppMessage(context, 'Profile update হয়েছে। এখন tournament join করা যাবে।');
      Navigator.pop(context, true);
    } on ApiException catch (error) {
      if (mounted) showAppMessage(context, error.message, error: true);
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final servers = _choices(_baseServers, _server);
    final modes = _choices(_baseModes, _mode);
    return Scaffold(
      appBar: AppBar(
        title: const Text('Edit Profile'),
        actions: <Widget>[
          if (widget.user.profileEditUrl.isNotEmpty)
            IconButton(
              tooltip: 'Edit on Website',
              onPressed: _openWebsiteEditor,
              icon: const Icon(Icons.open_in_browser_rounded),
            ),
        ],
      ),
      body: Form(
        key: _formKey,
        child: ListView(
          padding: const EdgeInsets.fromLTRB(16, 12, 16, 28),
          children: <Widget>[
            SurfaceBox(
              color: AppColors.cyan.withValues(alpha: .08),
              borderColor: AppColors.cyan.withValues(alpha: .36),
              child: const Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Icon(Icons.info_outline_rounded, color: AppColors.cyan),
                  SizedBox(width: 10),
                  Expanded(
                    child: Text(
                      'Tournament join করতে FF UID এবং IGN অবশ্যই দিতে হবে।',
                      style: TextStyle(color: AppColors.muted, height: 1.45),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 18),
            const SectionHeading(title: 'Game Profile'),
            const SizedBox(height: 10),
            TextFormField(
              controller: _ignController,
              maxLength: 80,
              textCapitalization: TextCapitalization.words,
              decoration: const InputDecoration(
                labelText: 'IGN / In-game name',
                hintText: 'আপনার Free Fire নাম',
                prefixIcon: Icon(Icons.person_outline_rounded),
              ),
              validator: (value) {
                if ((value ?? '').trim().length < 2) return 'সঠিক IGN দিন।';
                return null;
              },
            ),
            const SizedBox(height: 12),
            TextFormField(
              controller: _uidController,
              maxLength: 25,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(
                labelText: 'FF UID',
                hintText: 'শুধু সংখ্যা',
                prefixIcon: Icon(Icons.badge_outlined),
              ),
              validator: (value) {
                final uid = (value ?? '').trim();
                if (!RegExp(r'^\d{5,25}$').hasMatch(uid)) return 'সঠিক FF UID দিন (শুধু সংখ্যা)।';
                return null;
              },
            ),
            const SizedBox(height: 12),
            TextFormField(
              controller: _guildController,
              maxLength: 100,
              decoration: const InputDecoration(
                labelText: 'Guild (optional)',
                hintText: 'আপনার Guild নাম',
                prefixIcon: Icon(Icons.groups_outlined),
              ),
            ),
            const SizedBox(height: 12),
            DropdownButtonFormField<String>(
              initialValue: _server,
              decoration: const InputDecoration(
                labelText: 'Server',
                prefixIcon: Icon(Icons.public_rounded),
              ),
              items: servers.map((server) => DropdownMenuItem<String>(value: server, child: Text(server))).toList(),
              onChanged: (value) => setState(() => _server = value ?? _server),
            ),
            const SizedBox(height: 12),
            DropdownButtonFormField<String>(
              initialValue: _mode,
              decoration: const InputDecoration(
                labelText: 'Preferred mode',
                prefixIcon: Icon(Icons.sports_esports_rounded),
              ),
              items: modes.map((mode) => DropdownMenuItem<String>(value: mode, child: Text(mode))).toList(),
              onChanged: (value) => setState(() => _mode = value ?? _mode),
            ),
            const SizedBox(height: 22),
            SizedBox(
              width: double.infinity,
              child: FilledButton.icon(
                onPressed: _saving ? null : _save,
                icon: _saving
                    ? const SizedBox.square(dimension: 18, child: CircularProgressIndicator(color: Colors.black, strokeWidth: 2))
                    : const Icon(Icons.save_rounded),
                label: Text(_saving ? 'SAVING...' : 'SAVE PROFILE'),
              ),
            ),
            if (widget.user.profileEditUrl.isNotEmpty) ...<Widget>[
              const SizedBox(height: 10),
              SizedBox(
                width: double.infinity,
                child: OutlinedButton.icon(
                  onPressed: _openWebsiteEditor,
                  icon: const Icon(Icons.open_in_browser_rounded),
                  label: const Text('EDIT MORE ON WEBSITE'),
                ),
              ),
            ],
            const SizedBox(height: 14),
            const Text(
              'Profile photo, WhatsApp ও Telegram পরিবর্তন দরকার হলে Website editor ব্যবহার করুন।',
              textAlign: TextAlign.center,
              style: TextStyle(color: AppColors.muted, fontSize: 11, height: 1.4),
            ),
          ],
        ),
      ),
    );
  }
}
