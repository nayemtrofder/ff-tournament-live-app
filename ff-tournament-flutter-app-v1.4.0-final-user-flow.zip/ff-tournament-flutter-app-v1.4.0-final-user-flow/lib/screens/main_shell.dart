import 'package:flutter/material.dart';

import '../core/app_theme.dart';
import '../widgets/app_update_prompt.dart';
import 'home_screen.dart';
import 'leaderboard_screen.dart';
import 'my_matches_screen.dart';
import 'profile_screen.dart';
import 'tournaments_screen.dart';

class MainShell extends StatefulWidget {
  const MainShell({super.key, this.initialIndex = 0});
  final int initialIndex;

  @override
  State<MainShell> createState() => _MainShellState();
}

class _MainShellState extends State<MainShell> {
  late int _index;
  bool _checkedForUpdate = false;

  @override
  void initState() {
    super.initState();
    _index = widget.initialIndex;
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted || _checkedForUpdate) return;
      _checkedForUpdate = true;
      checkForAppUpdate(context);
    });
  }

  @override
  Widget build(BuildContext context) {
    const labels = ['Home', 'Tournaments', 'Leaderboard', 'My Matches', 'Profile'];
    const icons = [Icons.home_rounded, Icons.emoji_events_rounded, Icons.leaderboard_rounded, Icons.calendar_month_rounded, Icons.person_rounded];
    return Scaffold(
      body: SafeArea(
        child: IndexedStack(
          index: _index,
          children: <Widget>[
            HomeScreen(isActive: _index == 0),
            const TournamentsScreen(),
            const LeaderboardScreen(),
            const MyMatchesScreen(),
            const ProfileScreen(),
          ],
        ),
      ),
      bottomNavigationBar: Container(
        decoration: const BoxDecoration(border: Border(top: BorderSide(color: AppColors.border))),
        child: NavigationBar(
          height: 72,
          backgroundColor: AppColors.surface,
          indicatorColor: AppColors.orange.withValues(alpha: .17),
          selectedIndex: _index,
          onDestinationSelected: (value) => setState(() => _index = value),
          destinations: List.generate(labels.length, (index) => NavigationDestination(
            icon: Icon(icons[index], size: 23),
            selectedIcon: Icon(icons[index], color: AppColors.orange, size: 24),
            label: labels[index],
          )),
        ),
      ),
    );
  }
}
