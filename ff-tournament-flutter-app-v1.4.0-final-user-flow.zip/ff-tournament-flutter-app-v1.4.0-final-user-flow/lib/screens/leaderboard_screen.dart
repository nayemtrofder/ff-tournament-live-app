import 'dart:async';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../core/app_state.dart';
import '../core/app_theme.dart';
import '../models/tournament.dart';
import '../widgets/common.dart';
import '../widgets/leaderboard_widgets.dart';
import 'tournament_detail_screen.dart';

class LeaderboardScreen extends StatefulWidget {
  const LeaderboardScreen({super.key});

  @override
  State<LeaderboardScreen> createState() => _LeaderboardScreenState();
}

class _LeaderboardScreenState extends State<LeaderboardScreen> with AutomaticKeepAliveClientMixin {
  String _scope = 'live';
  late Future<LeaderboardData> _future;
  Timer? _timer;

  @override
  bool get wantKeepAlive => true;

  @override
  void initState() {
    super.initState();
    _future = _loadData();
    _timer = Timer.periodic(const Duration(seconds: 25), (_) {
      if (mounted && _scope == 'live') _reload();
    });
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  Future<LeaderboardData> _loadData() => context.read<AppState>().api.getLeaderboard(scope: _scope);

  void _reload() => setState(() => _future = _loadData());

  @override
  Widget build(BuildContext context) {
    super.build(context);
    return FutureBuilder<LeaderboardData>(
      future: _future,
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) return const PageLoading(label: 'Leaderboard loading...');
        if (snapshot.hasError) return Padding(padding: const EdgeInsets.all(16), child: ErrorPanel(message: snapshot.error.toString(), onRetry: _reload));
        final data = snapshot.data;
        if (data == null) return Padding(padding: const EdgeInsets.all(16), child: ErrorPanel(message: 'Leaderboard data পাওয়া যায়নি।', onRetry: _reload));
        final entries = _scope == 'live' && data.currentMatchEntries.isNotEmpty ? data.currentMatchEntries : data.entries;
        return RefreshIndicator(
          color: AppColors.orange,
          onRefresh: () async => _reload(),
          child: ListView(
            padding: const EdgeInsets.fromLTRB(16, 16, 16, 28),
            physics: const AlwaysScrollableScrollPhysics(),
            children: <Widget>[
              Row(
                children: <Widget>[
                  const Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: <Widget>[Text('Leaderboard', style: TextStyle(fontSize: 24, fontWeight: FontWeight.w900)), SizedBox(height: 3), Text('Rankings from your tournament website', style: TextStyle(color: AppColors.muted))])),
                  IconButton(onPressed: _reload, icon: const Icon(Icons.refresh_rounded)),
                ],
              ),
              const SizedBox(height: 15),
              Wrap(
                spacing: 8,
                runSpacing: 8,
                children: <Widget>[
                  for (final option in const <MapEntry<String, String>>[
                    MapEntry<String, String>('live', 'LIVE'),
                    MapEntry<String, String>('weekly', 'WEEKLY'),
                    MapEntry<String, String>('all_time', 'ALL TIME'),
                  ])
                    ChoiceChip(
                      label: Text(option.value),
                      selected: _scope == option.key,
                      onSelected: (_) {
                        setState(() => _scope = option.key);
                        _reload();
                      },
                    ),
                ],
              ),
              const SizedBox(height: 18),
              if (data.currentMatch != null && _scope == 'live')
                InkWell(
                  onTap: () => Navigator.push(context, MaterialPageRoute<void>(builder: (_) => TournamentDetailScreen(matchId: data.currentMatch!.id))),
                  borderRadius: BorderRadius.circular(19),
                  child: SurfaceBox(
                    color: AppColors.red.withValues(alpha: .08),
                    borderColor: AppColors.red.withValues(alpha: .40),
                    child: Row(children: <Widget>[const StatusBadge(status: 'LIVE NOW'), const SizedBox(width: 10), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: <Widget>[Text(data.currentMatch!.title, style: const TextStyle(fontWeight: FontWeight.w900)), const SizedBox(height: 3), Text('${data.currentMatch!.mode.toUpperCase()} • tap for match details', style: const TextStyle(color: AppColors.muted, fontSize: 12))])), const Icon(Icons.chevron_right_rounded, color: AppColors.red)]),
                  ),
                ),
              if (data.currentMatch != null && _scope == 'live') const SizedBox(height: 18),
              if (data.myRank != null) ...<Widget>[
                _MyRankCard(entry: data.myRank!),
                const SizedBox(height: 18),
              ],
              if (entries.isEmpty)
                const EmptyState(icon: Icons.leaderboard_outlined, title: 'No ranking data yet', message: 'Admin result/points publish করলে real leaderboard এখানে দেখা যাবে।')
              else ...<Widget>[
                if (entries.length >= 3) LeaderboardPodium(entries: entries.take(3).toList()),
                const SizedBox(height: 18),
                const SectionHeading(title: 'Rankings'),
                const SizedBox(height: 9),
                LeaderboardList(entries: entries),
              ],
              const SizedBox(height: 14),
              Text(_scope == 'live' ? 'Live page প্রতি 25 সেকেন্ডে real data refresh করে।' : 'Pull down to refresh the current ranking.', textAlign: TextAlign.center, style: const TextStyle(color: AppColors.muted, fontSize: 11)),
            ],
          ),
        );
      },
    );
  }
}

class _MyRankCard extends StatelessWidget {
  const _MyRankCard({required this.entry});
  final LeaderboardEntry entry;

  @override
  Widget build(BuildContext context) => SurfaceBox(
        color: AppColors.cyan.withValues(alpha: .09),
        borderColor: AppColors.cyan.withValues(alpha: .42),
        child: Row(children: <Widget>[Container(width: 44, height: 44, alignment: Alignment.center, decoration: BoxDecoration(shape: BoxShape.circle, color: AppColors.cyan.withValues(alpha: .16)), child: Text('#${entry.rank}', style: const TextStyle(color: AppColors.cyan, fontWeight: FontWeight.w900, fontSize: 16))), const SizedBox(width: 12), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: <Widget>[const Text('YOUR RANK', style: TextStyle(color: AppColors.cyan, fontSize: 10, fontWeight: FontWeight.w900, letterSpacing: .8)), const SizedBox(height: 3), Text('${entry.kills} kills • ${entry.points.toStringAsFixed(0)} points', style: const TextStyle(fontWeight: FontWeight.w900))]))]),
      );
}
