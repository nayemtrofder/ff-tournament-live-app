import 'dart:math';

import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../models/user_profile.dart';
import 'api_client.dart';
import 'app_config.dart';

class AppState extends ChangeNotifier {
  static const _tokenKey = 'ffts_api_token';
  static const _deviceIdKey = 'ffts_device_id';

  bool _ready = false;
  String _token = '';
  String _deviceId = '';
  UserProfile? _user;
  int _unreadNotifications = 0;

  bool get ready => _ready;
  String get baseUrl => AppConfig.apiBaseUrl.trim().replaceAll(RegExp(r'/+$'), '');
  String get token => _token;
  String get deviceId => _deviceId;
  UserProfile? get user => _user;
  int get unreadNotifications => _unreadNotifications;
  bool get isLoggedIn => _token.isNotEmpty && _user != null;
  bool get isConfigured => AppConfig.hasApiBaseUrl;
  ApiClient get api => ApiClient(baseUrl: baseUrl, token: _token, deviceId: _deviceId);

  Future<void> initialize() async {
    final prefs = await SharedPreferences.getInstance();
    _token = prefs.getString(_tokenKey) ?? '';
    _deviceId = prefs.getString(_deviceIdKey) ?? '';
    if (_deviceId.isEmpty) {
      _deviceId = _newDeviceId();
      await prefs.setString(_deviceIdKey, _deviceId);
    }
    if (_token.isNotEmpty && isConfigured) {
      try {
        _user = await api.getProfile();
      } catch (_) {
        _token = '';
        await prefs.remove(_tokenKey);
      }
    }
    _ready = true;
    notifyListeners();
  }

  String _newDeviceId() {
    final random = Random.secure();
    final suffix = List<String>.generate(16, (_) => random.nextInt(36).toRadixString(36)).join();
    return 'android-${DateTime.now().microsecondsSinceEpoch.toRadixString(36)}-$suffix';
  }

  Future<void> login({required String username, required String password}) async {
    final data = await api.login(username: username, password: password);
    final newToken = data['token']?.toString() ?? '';
    final userData = data['user'];
    if (newToken.isEmpty || userData is! Map) throw const ApiException('Login response অসম্পূর্ণ।');
    _token = newToken;
    _user = UserProfile.fromJson(userData.cast<String, dynamic>());
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_tokenKey, _token);
    notifyListeners();
  }

  Future<UserProfile?> refreshProfile() async {
    if (_token.isEmpty) return _user;
    _user = await api.getProfile();
    notifyListeners();
    return _user;
  }

  void updateUser(UserProfile user) {
    _user = user;
    notifyListeners();
  }

  void setUnreadNotifications(int value) {
    final normalized = value < 0 ? 0 : value;
    if (_unreadNotifications == normalized) return;
    _unreadNotifications = normalized;
    notifyListeners();
  }

  Future<void> logout() async {
    try {
      if (_token.isNotEmpty && isConfigured) await api.logout();
    } catch (_) {
      // Local logout must still work when network is unavailable.
    }
    _token = '';
    _user = null;
    _unreadNotifications = 0;
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(_tokenKey);
    notifyListeners();
  }
}
