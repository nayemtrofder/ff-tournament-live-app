import 'dart:async';

import 'package:flutter/material.dart';

import '../core/app_theme.dart';
import '../core/formatters.dart';
import '../models/live_session.dart';
import '../models/tournament.dart';
import 'common.dart';

class HeroSlideData {
  const HeroSlideData({
    required this.id,
    required this.title,
    required this.subtitle,
    required this.status,
    required this.prize,
    required this.icon,
    required this.accent,
    required this.buttonLabel,
    this.thumbnailUrl = '',
    this.onTap,
  });
  /// Stable identity used to detect a newly-prioritized live slide.
  final String id;
  final String title;
  final String subtitle;
  final String status;
  final String prize;
  final IconData icon;
  final Color accent;
  final String buttonLabel;
  final String thumbnailUrl;
  final VoidCallback? onTap;

  factory HeroSlideData.live(LiveSession live, VoidCallback? onTap) => HeroSlideData(
        id: 'live:${live.matchId}:${live.status}:${live.bestWatchUrl}',
        title: live.match?.title.isNotEmpty == true ? live.match!.title : live.title,
        subtitle: 'Live leaderboard এখনই পরিবর্তন হচ্ছে',
        status: 'LIVE NOW',
        prize: live.match?.prize.isNotEmpty == true ? live.match!.prize : 'Watch live',
        icon: Icons.play_circle_fill_rounded,
        accent: AppColors.red,
        buttonLabel: 'WATCH LIVE',
        thumbnailUrl: live.match?.bannerUrl.isNotEmpty == true ? live.match!.bannerUrl : (live.match?.thumbnailUrl ?? ''),
        onTap: onTap,
      );

  factory HeroSlideData.tournament(Tournament tournament, VoidCallback? onTap) => HeroSlideData(
        id: 'tournament:${tournament.id}:${tournament.status}',
        title: tournament.title,
        subtitle: '${tournament.mode.toUpperCase()} • ${conciseDate(tournament.startAt, tournament.matchDate, tournament.matchTime)}',
        status: tournament.statusLabel,
        prize: tournament.prize.isNotEmpty ? tournament.prize : goldText(tournament.entryGold),
        icon: Icons.emoji_events_rounded,
        accent: tournament.isLive ? AppColors.red : AppColors.orange,
        buttonLabel: tournament.isLive ? 'VIEW MATCH' : 'JOIN NOW',
        thumbnailUrl: tournament.bannerUrl.isNotEmpty ? tournament.bannerUrl : tournament.thumbnailUrl,
        onTap: onTap,
      );
}

class HeroCarousel extends StatefulWidget {
  const HeroCarousel({super.key, required this.items});
  final List<HeroSlideData> items;

  @override
  State<HeroCarousel> createState() => _HeroCarouselState();
}

class _HeroCarouselState extends State<HeroCarousel> {
  late final PageController _controller;
  Timer? _timer;
  int _page = 0;

  @override
  void initState() {
    super.initState();
    _controller = PageController(viewportFraction: .92);
    _startTimer();
  }

  @override
  void didUpdateWidget(covariant HeroCarousel oldWidget) {
    super.didUpdateWidget(oldWidget);
    final oldFirst = oldWidget.items.isEmpty ? '' : oldWidget.items.first.id;
    final newFirst = widget.items.isEmpty ? '' : widget.items.first.id;
    final hasNewPriorityFirstSlide = oldFirst != newFirst;

    if (widget.items.length != oldWidget.items.length && _page >= widget.items.length) {
      _page = 0;
    }

    // A live item is inserted at index 0 by Home. Move users to it immediately
    // instead of waiting for the normal carousel timer.
    if (hasNewPriorityFirstSlide && widget.items.isNotEmpty) {
      _page = 0;
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (!mounted || !_controller.hasClients) return;
        _controller.animateToPage(0, duration: const Duration(milliseconds: 320), curve: Curves.easeOutCubic);
      });
    }
  }

  void _startTimer() {
    _timer?.cancel();
    _timer = Timer.periodic(const Duration(seconds: 5), (_) {
      if (!mounted || widget.items.length < 2) return;
      _page = (_page + 1) % widget.items.length;
      _controller.animateToPage(_page, duration: const Duration(milliseconds: 480), curve: Curves.easeOutCubic);
    });
  }

  @override
  void dispose() {
    _timer?.cancel();
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (widget.items.isEmpty) return const SizedBox.shrink();
    return Column(
      children: [
        SizedBox(
          height: 205,
          child: PageView.builder(
            controller: _controller,
            itemCount: widget.items.length,
            onPageChanged: (index) => setState(() => _page = index),
            itemBuilder: (context, index) => Padding(
              padding: const EdgeInsets.only(right: 10),
              child: _HeroSlide(item: widget.items[index]),
            ),
          ),
        ),
        const SizedBox(height: 10),
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: List.generate(widget.items.length, (index) => AnimatedContainer(
            duration: const Duration(milliseconds: 220),
            margin: const EdgeInsets.symmetric(horizontal: 3),
            width: _page == index ? 19 : 6,
            height: 6,
            decoration: BoxDecoration(
              color: _page == index ? AppColors.orange : AppColors.border,
              borderRadius: BorderRadius.circular(10),
            ),
          )),
        ),
      ],
    );
  }
}

class _HeroSlide extends StatelessWidget {
  const _HeroSlide({required this.item});
  final HeroSlideData item;

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: item.onTap,
      borderRadius: BorderRadius.circular(26),
      child: Container(
        clipBehavior: Clip.antiAlias,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(26),
          color: AppColors.surface,
          border: Border.all(color: item.accent.withValues(alpha: .55)),
        ),
        child: Stack(
          fit: StackFit.expand,
          children: [
            if (item.thumbnailUrl.isNotEmpty)
              Image.network(item.thumbnailUrl, fit: BoxFit.cover, errorBuilder: (_, __, ___) => const SizedBox.shrink()),
            DecoratedBox(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [
                    item.accent.withValues(alpha: .43),
                    AppColors.surface.withValues(alpha: .78),
                    AppColors.bg,
                  ],
                ),
              ),
            ),
            Positioned(
              right: -28,
              bottom: -33,
              child: Icon(item.icon, size: 178, color: Colors.white.withValues(alpha: .10)),
            ),
            Padding(
              padding: const EdgeInsets.all(19),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(children: [StatusBadge(status: item.status), const Spacer(), const Icon(Icons.bolt_rounded, color: AppColors.gold, size: 20)]),
                  const Spacer(),
                  Text(item.title, maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w900, height: 1.05, letterSpacing: -.5)),
                  const SizedBox(height: 7),
                  Text(item.subtitle, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: AppColors.muted, fontWeight: FontWeight.w600)),
                  const SizedBox(height: 10),
                  Row(
                    children: [
                      Expanded(child: GoldPill(value: item.prize, compact: true)),
                      const SizedBox(width: 10),
                      FilledButton(
                        onPressed: item.onTap,
                        style: FilledButton.styleFrom(backgroundColor: item.accent, foregroundColor: Colors.white, padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 9)),
                        child: Text(item.buttonLabel, style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w900)),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
