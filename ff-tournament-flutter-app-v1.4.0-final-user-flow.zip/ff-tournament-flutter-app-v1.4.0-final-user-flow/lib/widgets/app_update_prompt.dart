import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:url_launcher/url_launcher.dart';

import '../core/app_config.dart';
import '../core/app_state.dart';
import '../core/app_theme.dart';
import '../models/app_update_info.dart';
import 'common.dart';

/// Checks the Bridge `/app-update` endpoint. The server controls whether an
/// update is optional or required; this app never downloads or silently
/// installs APK files itself.
Future<void> checkForAppUpdate(
  BuildContext context, {
  bool showNoUpdateMessage = false,
}) async {
  final state = context.read<AppState>();
  if (!state.isConfigured) return;

  try {
    final update = await state.api.getAppUpdate(AppConfig.appVersionCode);
    if (!context.mounted) return;
    if (!update.enabled || !update.updateAvailable || !update.canOpenDownload) {
      if (showNoUpdateMessage) {
        showAppMessage(context, 'আপনার App ইতিমধ্যে latest version-এ আছে।');
      }
      return;
    }
    await showAppUpdateDialog(context, update);
  } catch (_) {
    if (context.mounted && showNoUpdateMessage) {
      showAppMessage(context, 'Update check করা যায়নি। পরে আবার চেষ্টা করুন।', error: true);
    }
  }
}

Future<void> showAppUpdateDialog(BuildContext context, AppUpdateInfo update) async {
  final force = update.forceUpdate;
  await showDialog<void>(
    context: context,
    barrierDismissible: !force,
    builder: (dialogContext) => PopScope(
      canPop: !force,
      child: AlertDialog(
        icon: const Icon(Icons.system_update_rounded, color: AppColors.orange, size: 34),
        title: Text(force ? 'Update প্রয়োজন' : 'নতুন App Update'),
        content: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 360),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Text(
                update.latestVersion.isEmpty ? 'নতুন version পাওয়া গেছে।' : 'Version ${update.latestVersion} available',
                style: const TextStyle(fontWeight: FontWeight.w800),
              ),
              if (update.releaseNotes.trim().isNotEmpty) ...<Widget>[
                const SizedBox(height: 10),
                Text(update.releaseNotes, style: const TextStyle(color: AppColors.muted, height: 1.45)),
              ],
              const SizedBox(height: 12),
              const Text(
                'Update Now চাপলে APK download link browser-এ খুলবে। Download শেষ হলে APK install করতে হবে।',
                style: TextStyle(color: AppColors.muted, fontSize: 12, height: 1.4),
              ),
            ],
          ),
        ),
        actions: <Widget>[
          if (!force)
            TextButton(
              onPressed: () => Navigator.of(dialogContext).pop(),
              child: const Text('LATER'),
            ),
          FilledButton.icon(
            onPressed: () async {
              final launched = await launchUrl(Uri.parse(update.downloadUrl), mode: LaunchMode.externalApplication);
              if (dialogContext.mounted && !launched) {
                showAppMessage(dialogContext, 'Download link open করা যায়নি।', error: true);
              }
            },
            icon: const Icon(Icons.download_rounded),
            label: const Text('UPDATE NOW'),
          ),
        ],
      ),
    ),
  );
}
