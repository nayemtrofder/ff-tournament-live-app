import 'tournament.dart';
import 'video_item.dart';

export 'video_item.dart';

class LiveSession {
  const LiveSession({
    required this.isLive,
    required this.status,
    required this.title,
    required this.matchId,
    required this.match,
    required this.startedAt,
    required this.endsAt,
    required this.playbackUrl,
    required this.youtubeUrl,
    required this.facebookUrl,
    required this.appEnabled,
    this.linkedVideo,
  });

  final bool isLive;
  final String status;
  final String title;
  final int matchId;
  final Tournament? match;
  final String startedAt;
  final String endsAt;
  final String playbackUrl;
  final String youtubeUrl;
  final String facebookUrl;
  final bool appEnabled;
  final VideoItem? linkedVideo;

  factory LiveSession.fromJson(Map<String, dynamic> json) {
    final matchJson = json['match'];
    final linkedVideo = json['linked_video'];
    return LiveSession(
      isLive: json['is_live'] == true || json['live'] == true,
      status: (json['status'] ?? 'offline').toString(),
      title: (json['title'] ?? '').toString(),
      matchId: _int(json['match_id']),
      match: matchJson is Map ? Tournament.fromJson(matchJson.cast<String, dynamic>()) : null,
      startedAt: (json['started_at'] ?? '').toString(),
      endsAt: (json['ends_at'] ?? '').toString(),
      playbackUrl: (json['playback_url'] ?? '').toString(),
      youtubeUrl: (json['youtube_url'] ?? '').toString(),
      facebookUrl: (json['facebook_url'] ?? '').toString(),
      appEnabled: json['app_enabled'] == true,
      linkedVideo: linkedVideo is Map ? VideoItem.fromJson(linkedVideo.cast<String, dynamic>()) : null,
    );
  }

  String get bestWatchUrl {
    if (youtubeUrl.isNotEmpty) return youtubeUrl;
    if (linkedVideo?.url.isNotEmpty == true) return linkedVideo!.url;
    if (playbackUrl.isNotEmpty) return playbackUrl;
    return facebookUrl;
  }
}

