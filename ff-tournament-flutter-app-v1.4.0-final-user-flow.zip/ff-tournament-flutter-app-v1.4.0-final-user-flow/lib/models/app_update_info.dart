class AppUpdateInfo {
  const AppUpdateInfo({
    required this.enabled,
    required this.updateAvailable,
    required this.forceUpdate,
    required this.latestVersion,
    required this.latestVersionCode,
    required this.downloadUrl,
    required this.releaseNotes,
    required this.updateType,
    required this.minimumSupportedVersionCode,
  });

  final bool enabled;
  final bool updateAvailable;
  final bool forceUpdate;
  final String latestVersion;
  final int latestVersionCode;
  final String downloadUrl;
  final String releaseNotes;
  final String updateType;
  final int minimumSupportedVersionCode;

  factory AppUpdateInfo.fromJson(Map<String, dynamic> json) => AppUpdateInfo(
        enabled: json['enabled'] == true,
        updateAvailable: json['update_available'] == true,
        forceUpdate: json['force_update'] == true,
        latestVersion: '${json['latest_version'] ?? ''}',
        latestVersionCode: _int(json['latest_version_code']),
        downloadUrl: '${json['download_url'] ?? ''}',
        releaseNotes: '${json['release_notes'] ?? ''}',
        updateType: '${json['update_type'] ?? 'optional'}',
        minimumSupportedVersionCode: _int(json['min_version_code']),
      );

  bool get canOpenDownload => downloadUrl.trim().isNotEmpty;
}

int _int(dynamic value) => value is num ? value.toInt() : int.tryParse('$value') ?? 0;
