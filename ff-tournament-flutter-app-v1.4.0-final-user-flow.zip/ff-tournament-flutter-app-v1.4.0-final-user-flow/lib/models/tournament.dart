import 'video_item.dart';
import 'tournament_interaction.dart';

class Tournament {
  const Tournament({
    required this.id,
    required this.title,
    required this.mode,
    required this.prize,
    required this.entryGold,
    required this.slots,
    required this.joined,
    required this.slotsLeft,
    required this.startAt,
    required this.matchDate,
    required this.matchTime,
    required this.status,
    required this.description,
    required this.rules,
    required this.thumbnailUrl,
    required this.bannerUrl,
    required this.resultPublished,
    required this.isJoined,
    required this.canJoin,
    required this.roomId,
    required this.roomPassword,
    required this.leaderboard,
    required this.myKills,
    required this.myPlacement,
    required this.myPoints,
    required this.prizeCredited,
    required this.interactions,
    required this.videos,
    required this.comments,
    this.liveVideo,
  });

  final int id;
  final String title;
  final String mode;
  final String prize;
  final double entryGold;
  final int slots;
  final int joined;
  final int slotsLeft;
  final String startAt;
  final String matchDate;
  final String matchTime;
  final String status;
  final String description;
  final String rules;
  final String thumbnailUrl;
  final String bannerUrl;
  final bool resultPublished;
  final bool isJoined;
  final bool canJoin;
  final String roomId;
  final String roomPassword;
  final List<LeaderboardEntry> leaderboard;
  final int myKills;
  final int myPlacement;
  final double myPoints;
  final double prizeCredited;
  final TournamentInteractions interactions;
  final List<VideoItem> videos;
  final List<TournamentComment> comments;
  final VideoItem? liveVideo;

  factory Tournament.fromJson(Map<String, dynamic> json) {
    final rows = (json['leaderboard'] as List?) ?? const [];
    final registration = (json['my_registration'] as Map?)?.cast<String, dynamic>() ?? const <String, dynamic>{};
    final interactionData = (json['interactions'] as Map?)?.cast<String, dynamic>() ?? json;
    final rawVideos = (json['videos'] as List?) ?? const [];
    final rawComments = (json['comments'] as List?) ?? const [];
    final liveVideoData = json['live_video'];
    final explicitBanner = _asString(json['banner_url']);
    final fallbackThumbnail = _asString(json['thumbnail_url']);
    final interactionBanner = _asString(interactionData['banner_url']);
    return Tournament(
      id: _asInt(json['id'] ?? json['match_id']),
      title: _asString(json['title']),
      mode: _asString(json['mode']).isEmpty ? 'Solo' : _asString(json['mode']),
      prize: _asString(json['prize']),
      entryGold: _asDouble(json['entry_gold'] ?? json['entry_fee']),
      slots: _asInt(json['slots']),
      joined: _asInt(json['joined_count'] ?? json['joined']),
      slotsLeft: _asInt(json['slots_left']),
      startAt: _asString(json['start_at'] ?? json['scheduled_at']),
      matchDate: _asString(json['match_date']),
      matchTime: _asString(json['match_time']),
      status: _asString(json['status']).isEmpty ? 'upcoming' : _asString(json['status']),
      description: _asString(json['description']),
      rules: _asString(json['rules']),
      thumbnailUrl: fallbackThumbnail.isNotEmpty ? fallbackThumbnail : (explicitBanner.isNotEmpty ? explicitBanner : interactionBanner),
      bannerUrl: explicitBanner.isNotEmpty ? explicitBanner : (interactionBanner.isNotEmpty ? interactionBanner : fallbackThumbnail),
      resultPublished: json['result_published'] == true,
      isJoined: json['is_joined'] == true,
      canJoin: json['can_join'] == true,
      roomId: _asString(json['room_id']),
      roomPassword: _asString(json['room_password']),
      leaderboard: rows.whereType<Map>().map((row) => LeaderboardEntry.fromJson(row.cast<String, dynamic>())).toList(),
      myKills: _asInt(registration['kills']),
      myPlacement: _asInt(registration['placement']),
      myPoints: _asDouble(registration['points']),
      prizeCredited: _asDouble(registration['prize_credited']),
      interactions: TournamentInteractions.fromJson(interactionData),
      videos: rawVideos.whereType<Map>().map((row) => VideoItem.fromJson(row.cast<String, dynamic>())).toList(),
      comments: rawComments.whereType<Map>().map((row) => TournamentComment.fromJson(row.cast<String, dynamic>())).toList(),
      liveVideo: liveVideoData is Map ? VideoItem.fromJson(liveVideoData.cast<String, dynamic>()) : null,
    );
  }

  bool get isLive => status.toLowerCase() == 'live';
  bool get isUpcoming => status.toLowerCase() == 'upcoming';
  bool get isEnded => status.toLowerCase() == 'ended';
  bool get isCancelled => status.toLowerCase() == 'cancelled';
  double get slotProgress => slots == 0 ? 0 : (joined / slots).clamp(0, 1);

  String get statusLabel {
    switch (status.toLowerCase()) {
      case 'live':
        return 'LIVE NOW';
      case 'ended':
        return 'COMPLETED';
      case 'cancelled':
        return 'CANCELLED';
      default:
        return 'UPCOMING';
    }
  }
}

class LeaderboardEntry {
  const LeaderboardEntry({
    required this.rank,
    required this.userId,
    required this.name,
    required this.avatarUrl,
    required this.points,
    required this.kills,
    required this.placement,
    required this.matches,
    required this.isMe,
  });

  final int rank;
  final int userId;
  final String name;
  final String avatarUrl;
  final double points;
  final int kills;
  final int placement;
  final int matches;
  final bool isMe;

  factory LeaderboardEntry.fromJson(Map<String, dynamic> json) => LeaderboardEntry(
        rank: _asInt(json['rank'] ?? json['position']),
        userId: _asInt(json['user_id']),
        name: _asString(json['player_name']).isNotEmpty ? _asString(json['player_name']) : _asString(json['name']),
        avatarUrl: _asString(json['profile_photo_url']).isNotEmpty ? _asString(json['profile_photo_url']) : _asString(json['avatar_url']),
        points: _asDouble(json['total_points'] ?? json['points']),
        kills: _asInt(json['total_kills'] ?? json['kills']),
        placement: _asInt(json['placement']),
        matches: _asInt(json['matches_played'] ?? json['matches']),
        isMe: json['is_me'] == true,
      );
}

class LeaderboardData {
  const LeaderboardData({
    required this.scope,
    required this.mode,
    required this.title,
    required this.entries,
    required this.currentMatch,
    required this.currentMatchEntries,
    required this.myRank,
  });

  final String scope;
  final String mode;
  final String title;
  final List<LeaderboardEntry> entries;
  final Tournament? currentMatch;
  final List<LeaderboardEntry> currentMatchEntries;
  final LeaderboardEntry? myRank;

  factory LeaderboardData.fromJson(Map<String, dynamic> json) {
    List<LeaderboardEntry> parseRows(dynamic rows) => (rows as List? ?? const [])
        .whereType<Map>()
        .map((row) => LeaderboardEntry.fromJson(row.cast<String, dynamic>()))
        .toList();
    final current = json['current_match'];
    final my = json['my_rank'];
    return LeaderboardData(
      scope: _asString(json['scope']),
      mode: _asString(json['mode']),
      title: _asString(json['title']),
      entries: parseRows(json['entries'] ?? json['leaderboard']),
      currentMatch: current is Map ? Tournament.fromJson(current.cast<String, dynamic>()) : null,
      currentMatchEntries: parseRows(json['current_match_leaderboard']),
      myRank: my is Map ? LeaderboardEntry.fromJson(my.cast<String, dynamic>()) : null,
    );
  }
}

class MyMatchesPayload {
  const MyMatchesPayload({required this.items, required this.summary});
  final List<Tournament> items;
  final Map<String, int> summary;

  factory MyMatchesPayload.fromJson(Map<String, dynamic> json) {
    final rows = (json['items'] ?? json['matches']) as List? ?? const [];
    final summarySource = (json['summary'] as Map?)?.cast<String, dynamic>() ?? const <String, dynamic>{};
    return MyMatchesPayload(
      items: rows.whereType<Map>().map((row) => Tournament.fromJson(row.cast<String, dynamic>())).toList(),
      summary: summarySource.map((key, value) => MapEntry(key, _asInt(value))),
    );
  }
}

String _asString(dynamic value) => value?.toString() ?? '';
int _asInt(dynamic value) => value is num ? value.toInt() : int.tryParse('$value') ?? 0;
double _asDouble(dynamic value) => value is num ? value.toDouble() : double.tryParse('$value') ?? 0;
