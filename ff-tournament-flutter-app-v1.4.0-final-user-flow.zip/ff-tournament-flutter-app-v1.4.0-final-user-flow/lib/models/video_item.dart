class VideoItem {
  const VideoItem({
    required this.id,
    required this.matchId,
    required this.title,
    required this.url,
    required this.thumbnailUrl,
    required this.publishedAt,
    required this.videoType,
    required this.duration,
  });

  final int id;
  final int matchId;
  final String title;
  final String url;
  final String thumbnailUrl;
  final String publishedAt;
  final String videoType;
  final String duration;

  factory VideoItem.fromJson(Map<String, dynamic> json) => VideoItem(
        id: _int(json['video_id'] ?? json['id']),
        matchId: _int(json['match_id']),
        title: (json['title'] ?? 'Tournament Video').toString(),
        url: (json['video_url'] ?? json['url'] ?? '').toString(),
        thumbnailUrl: (json['thumbnail_url'] ?? '').toString(),
        publishedAt: (json['published_at'] ?? json['created_at'] ?? '').toString(),
        videoType: (json['type'] ?? json['video_type'] ?? '').toString().toLowerCase(),
        duration: (json['duration'] ?? '').toString(),
      );

  bool get isLive => videoType == 'live';
  bool get isReplay => videoType == 'replay';
  bool get isHighlight => videoType == 'highlight';

  String get typeLabel {
    switch (videoType) {
      case 'live':
        return 'LIVE';
      case 'replay':
        return 'REPLAY';
      case 'highlight':
        return 'HIGHLIGHT';
      default:
        return 'VIDEO';
    }
  }
}

int _int(dynamic value) => value is num ? value.toInt() : int.tryParse('$value') ?? 0;
