class TournamentInteractions {
  const TournamentInteractions({
    required this.bannerAttachmentId,
    required this.bannerUrl,
    required this.likeCount,
    required this.userHasLiked,
    required this.likesEnabled,
    required this.commentsEnabled,
    required this.commentsLocked,
    required this.canComment,
    required this.commentCount,
    required this.viewCount,
    required this.showViewCount,
  });

  final int bannerAttachmentId;
  final String bannerUrl;
  final int likeCount;
  final bool userHasLiked;
  final bool likesEnabled;
  final bool commentsEnabled;
  final bool commentsLocked;
  final bool canComment;
  final int commentCount;
  final int viewCount;
  final bool showViewCount;

  factory TournamentInteractions.empty() => const TournamentInteractions(
        bannerAttachmentId: 0,
        bannerUrl: '',
        likeCount: 0,
        userHasLiked: false,
        likesEnabled: false,
        commentsEnabled: false,
        commentsLocked: true,
        canComment: false,
        commentCount: 0,
        viewCount: 0,
        showViewCount: false,
      );

  factory TournamentInteractions.fromJson(Map<String, dynamic> json) => TournamentInteractions(
        bannerAttachmentId: _int(json['banner_attachment_id']),
        bannerUrl: '${json['banner_url'] ?? ''}',
        likeCount: _int(json['like_count']),
        userHasLiked: json['user_has_liked'] == true,
        likesEnabled: json['likes_enabled'] == true,
        commentsEnabled: json['comments_enabled'] == true,
        commentsLocked: json['comments_locked'] == true,
        canComment: json['can_comment'] == true,
        commentCount: _int(json['comment_count']),
        viewCount: _int(json['view_count']),
        showViewCount: json['show_view_count'] == true,
      );
}

class TournamentComment {
  const TournamentComment({
    required this.id,
    required this.matchId,
    required this.userId,
    required this.name,
    required this.avatarUrl,
    required this.text,
    required this.createdAt,
    required this.canDelete,
  });

  final int id;
  final int matchId;
  final int userId;
  final String name;
  final String avatarUrl;
  final String text;
  final String createdAt;
  final bool canDelete;

  factory TournamentComment.fromJson(Map<String, dynamic> json) => TournamentComment(
        id: _int(json['comment_id'] ?? json['id']),
        matchId: _int(json['match_id']),
        userId: _int(json['user_id']),
        name: '${json['display_name'] ?? json['name'] ?? 'Player'}',
        avatarUrl: '${json['avatar_url'] ?? ''}',
        text: '${json['comment_text'] ?? json['text'] ?? ''}',
        createdAt: '${json['created_at'] ?? ''}',
        canDelete: json['can_delete'] == true,
      );
}

int _int(dynamic value) => value is num ? value.toInt() : int.tryParse('$value') ?? 0;
