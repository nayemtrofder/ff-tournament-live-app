# Test Checklist — FF Tournament App v1.4.0

## Account / Profile
- [ ] Header-এ current Gold দেখা যাচ্ছে
- [ ] Header Gold chip চাপলে Buy Gold open হয়
- [ ] Profile → Edit Profile থেকে IGN ও FF UID save হয়
- [ ] Save করার পর Profile page-এ নতুন data দেখা যায়
- [ ] Profile complete করে tournament Join করা যায়

## Buy Gold
- [ ] Buy Gold App-এর ভিতরে open হয়
- [ ] Website login আবার চাইছে না
- [ ] OPEN IN WEBSITE fallback কাজ করে
- [ ] Payment-এর পর REFRESH GOLD নতুন balance আনে

## Tournament interaction
- [ ] Card heart চাপলে Like হয়
- [ ] আবার চাপলে Unlike হয়
- [ ] Like count দ্রুত বদলায়
- [ ] Comment post করলে success message দেখা যায়
- [ ] Comment list ও count দ্রুত update হয়

## Fresh data
- [ ] Profile website-এ edit করে App Profile tab খুললে updated data আসে
- [ ] App Home-এ Live Start/End সাধারণত 0–5 সেকেন্ডে reflect হয়
- [ ] Banner/tournament status pull-to-refresh এ latest আসে

## Icon
- [ ] Phone Home Screen-এ trophy app icon দেখা যায়
