# App v1.3.1 API Mapping

| App feature | API route |
|---|---|
| Home + auto refresh | `GET /home` |
| Tournament detail + view count | `GET /tournaments/{id}?track_view=1` |
| Like / Unlike | `POST /tournaments/{id}/like` |
| Comment list | `GET /tournaments/{id}/comments` |
| Add comment | `POST /tournaments/{id}/comments` |
| Explicit interaction data | `GET /tournaments/{id}/interactions` |
| Linked live/highlight/replay videos | tournament detail `videos` field, `GET /videos?match_id={id}` |
| App update check | `GET /app-update?version_code=4` |

সব route API base URL-এর পরে ব্যবহার হবে:

```text
https://fftrustbd.com/wp-json/ffts-app/v1
```
