# 5-second Live Priority কীভাবে কাজ করে

এই App update প্রতি 5 সেকেন্ডে পুরো Home API download করে না। শুধু ছোট `/live/current` endpoint check করে। Live status বদলালে তখনই পুরো Home API reload হয় এবং Hero slider-এর প্রথম banner update হয়।

Polling শুধু App foreground-এ এবং Home tab visible থাকলে চলে। এতে অপ্রয়োজনীয় battery/API load কম থাকে।
