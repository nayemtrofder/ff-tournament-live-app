/// Build-time configuration and app release metadata.
///
/// Android build example:
/// flutter build apk --release --dart-define=FFTS_API_BASE_URL=https://example.com/wp-json/ffts-app/v1
class AppConfig {
  const AppConfig._();

  static const String apiBaseUrl = String.fromEnvironment(
    'FFTS_API_BASE_URL',
    defaultValue: '',
  );

  /// Keep these values aligned with pubspec.yaml. The Bridge plugin compares
  /// this code with the version code set in its App Update Center.
  static const String appVersionName = '1.3.1';
  static const int appVersionCode = 5;

  static bool get hasApiBaseUrl => apiBaseUrl.trim().isNotEmpty;
}
