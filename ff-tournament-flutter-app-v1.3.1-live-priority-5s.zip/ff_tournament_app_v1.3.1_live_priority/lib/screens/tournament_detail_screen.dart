import 'dart:async';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../core/api_client.dart';
import '../core/app_state.dart';
import '../core/app_theme.dart';
import '../core/formatters.dart';
import '../models/live_session.dart';
import '../models/tournament.dart';
import '../models/tournament_interaction.dart';
import '../widgets/common.dart';
import '../widgets/leaderboard_widgets.dart';
import 'login_screen.dart';
import 'youtube_player_screen.dart';

class TournamentDetailScreen extends StatefulWidget {
  const TournamentDetailScreen({super.key, required this.matchId});
  final int matchId;

  @override
  State<TournamentDetailScreen> createState() => _TournamentDetailScreenState();
}

class _TournamentDetailScreenState extends State<TournamentDetailScreen> {
  late Future<Tournament> _future;
  final TextEditingController _commentController = TextEditingController();
  Timer? _refreshTimer;
  bool _joining = false;
  bool _liking = false;
  bool _sendingComment = false;

  @override
  void initState() {
    super.initState();
    _future = _loadData();
    _refreshTimer = Timer.periodic(const Duration(seconds: 20), (_) {
      if (mounted) _reload();
    });
  }

  Future<Tournament> _loadData() => context.read<AppState>().api.getTournament(widget.matchId, trackView: true);

  void _reload() => setState(() => _future = _loadData());

  @override
  void dispose() {
    _refreshTimer?.cancel();
    _commentController.dispose();
    super.dispose();
  }

  Future<void> _join(Tournament tournament) async {
    final state = context.read<AppState>();
    if (!state.isLoggedIn) {
      await Navigator.push(context, MaterialPageRoute<bool>(builder: (_) => const LoginScreen()));
      if (mounted) _reload();
      return;
    }
    setState(() => _joining = true);
    try {
      final result = await state.api.joinTournament(tournament.id);
      await state.refreshProfile();
      if (!mounted) return;
      showAppMessage(context, (result['message'] ?? 'Tournament joined successfully.').toString());
      _reload();
    } on ApiException catch (error) {
      if (mounted) showAppMessage(context, error.message, error: true);
    } finally {
      if (mounted) setState(() => _joining = false);
    }
  }

  Future<void> _toggleLike(Tournament tournament) async {
    final state = context.read<AppState>();
    if (!state.isLoggedIn) {
      await Navigator.push(context, MaterialPageRoute<bool>(builder: (_) => const LoginScreen()));
      if (mounted) _reload();
      return;
    }
    if (tournament.interactions.likesEnabled == false || _liking) return;
    setState(() => _liking = true);
    try {
      await state.api.toggleTournamentLike(tournament.id);
      if (mounted) _reload();
    } on ApiException catch (error) {
      if (mounted) showAppMessage(context, error.message, error: true);
    } finally {
      if (mounted) setState(() => _liking = false);
    }
  }

  Future<void> _sendComment(Tournament tournament) async {
    final text = _commentController.text.trim();
    if (text.isEmpty || _sendingComment) return;
    final state = context.read<AppState>();
    if (!state.isLoggedIn) {
      await Navigator.push(context, MaterialPageRoute<bool>(builder: (_) => const LoginScreen()));
      if (mounted) _reload();
      return;
    }
    setState(() => _sendingComment = true);
    try {
      await state.api.addTournamentComment(tournament.id, text);
      _commentController.clear();
      if (mounted) {
        FocusScope.of(context).unfocus();
        _reload();
      }
    } on ApiException catch (error) {
      if (mounted) showAppMessage(context, error.message, error: true);
    } finally {
      if (mounted) setState(() => _sendingComment = false);
    }
  }

  Future<void> _watchVideo(VideoItem video) async {
    if (video.url.trim().isEmpty) {
      if (mounted) showAppMessage(context, 'এই ভিডিওর YouTube link দেওয়া হয়নি।', error: true);
      return;
    }
    await Navigator.push<void>(
      context,
      MaterialPageRoute<void>(
        builder: (_) => YouTubePlayerScreen(
          title: video.title,
          youtubeUrl: video.url,
          subtitle: video.typeLabel,
          isLive: video.isLive,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('Tournament Details')),
        body: FutureBuilder<Tournament>(
          future: _future,
          builder: (context, snapshot) {
            final tournament = snapshot.data;
            if (snapshot.connectionState == ConnectionState.waiting && tournament == null) {
              return const PageLoading(label: 'Tournament details loading...');
            }
            if (snapshot.hasError && tournament == null) {
              return Padding(padding: const EdgeInsets.all(16), child: ErrorPanel(message: snapshot.error.toString(), onRetry: _reload));
            }
            if (tournament == null) {
              return Padding(padding: const EdgeInsets.all(16), child: ErrorPanel(message: 'Tournament data পাওয়া যায়নি।', onRetry: _reload));
            }
            final state = context.watch<AppState>();
            final hasRoom = tournament.roomId.isNotEmpty || tournament.roomPassword.isNotEmpty;
            final videos = _orderedVideos(tournament);
            return RefreshIndicator(
              color: AppColors.orange,
              onRefresh: () async {
                _reload();
                await _future;
              },
              child: ListView(
                padding: const EdgeInsets.fromLTRB(16, 14, 16, 30),
                physics: const AlwaysScrollableScrollPhysics(),
                children: <Widget>[
                  _Banner(tournament: tournament),
                  const SizedBox(height: 16),
                  SurfaceBox(
                    child: Row(
                      children: <Widget>[
                        Expanded(child: _InfoCell(label: 'MODE', value: tournament.mode.toUpperCase())),
                        Container(width: 1, height: 42, color: AppColors.border),
                        Expanded(child: _InfoCell(label: 'SLOTS', value: '${tournament.joined}/${tournament.slots}')),
                        Container(width: 1, height: 42, color: AppColors.border),
                        Expanded(child: _InfoCell(label: 'ENTRY', value: '${tournament.entryGold.toStringAsFixed(0)} Gold')),
                      ],
                    ),
                  ),
                  const SizedBox(height: 16),
                  _InteractionBar(
                    interactions: tournament.interactions,
                    likeLoading: _liking,
                    onLike: () => _toggleLike(tournament),
                  ),
                  const SizedBox(height: 16),
                  const SectionHeading(title: 'Match Information'),
                  const SizedBox(height: 9),
                  SurfaceBox(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        _DetailRow(icon: Icons.calendar_today_rounded, label: 'Schedule', value: conciseDate(tournament.startAt, tournament.matchDate, tournament.matchTime)),
                        const Divider(height: 20),
                        _DetailRow(icon: Icons.workspace_premium_rounded, label: 'Prize', value: tournament.prize.isEmpty ? 'Not published' : tournament.prize, valueColor: AppColors.gold),
                        const Divider(height: 20),
                        _DetailRow(icon: Icons.group_outlined, label: 'Slots Left', value: '${tournament.slotsLeft}'),
                      ],
                    ),
                  ),
                  if (tournament.description.isNotEmpty || tournament.rules.isNotEmpty) ...<Widget>[
                    const SizedBox(height: 22),
                    const SectionHeading(title: 'Rules'),
                    const SizedBox(height: 9),
                    SurfaceBox(child: Text(tournament.rules.isNotEmpty ? tournament.rules : tournament.description, style: const TextStyle(color: AppColors.muted, height: 1.55))),
                  ],
                  if (videos.isNotEmpty) ...<Widget>[
                    const SizedBox(height: 22),
                    const SectionHeading(title: 'Watch'),
                    const SizedBox(height: 9),
                    ...videos.map(
                      (video) => Padding(
                        padding: const EdgeInsets.only(bottom: 9),
                        child: _WatchVideoCard(video: video, onTap: () => _watchVideo(video)),
                      ),
                    ),
                  ],
                  if (hasRoom) ...<Widget>[
                    const SizedBox(height: 22),
                    const SectionHeading(title: 'Room Details'),
                    const SizedBox(height: 9),
                    SurfaceBox(
                      color: AppColors.cyan.withValues(alpha: .08),
                      borderColor: AppColors.cyan.withValues(alpha: .35),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget>[
                          const Text('Joined player room access', style: TextStyle(fontWeight: FontWeight.w900)),
                          const SizedBox(height: 12),
                          _DetailRow(icon: Icons.meeting_room_outlined, label: 'Room ID', value: tournament.roomId.isEmpty ? 'TBA' : tournament.roomId, valueColor: AppColors.cyan),
                          const Divider(height: 20),
                          _DetailRow(icon: Icons.key_outlined, label: 'Password', value: tournament.roomPassword.isEmpty ? 'TBA' : tournament.roomPassword, valueColor: AppColors.cyan),
                        ],
                      ),
                    ),
                  ],
                  if (tournament.isEnded && (tournament.myPlacement > 0 || tournament.myKills > 0 || tournament.myPoints > 0)) ...<Widget>[
                    const SizedBox(height: 22),
                    const SectionHeading(title: 'Your Result'),
                    const SizedBox(height: 9),
                    SurfaceBox(child: Row(children: <Widget>[Expanded(child: _InfoCell(label: 'RANK', value: tournament.myPlacement > 0 ? '#${tournament.myPlacement}' : '—')), Expanded(child: _InfoCell(label: 'KILLS', value: '${tournament.myKills}')), Expanded(child: _InfoCell(label: 'POINTS', value: tournament.myPoints.toStringAsFixed(0)))])),
                  ],
                  if (tournament.leaderboard.isNotEmpty) ...<Widget>[
                    const SizedBox(height: 22),
                    const SectionHeading(title: 'Leaderboard'),
                    const SizedBox(height: 9),
                    LeaderboardList(entries: tournament.leaderboard),
                  ],
                  if (tournament.interactions.commentsEnabled) ...<Widget>[
                    const SizedBox(height: 22),
                    _CommentSection(
                      tournament: tournament,
                      isLoggedIn: state.isLoggedIn,
                      controller: _commentController,
                      sending: _sendingComment,
                      onSend: () => _sendComment(tournament),
                      onLogin: () async {
                        await Navigator.push(context, MaterialPageRoute<bool>(builder: (_) => const LoginScreen()));
                        if (mounted) _reload();
                      },
                      onRefresh: _reload,
                    ),
                  ],
                  const SizedBox(height: 24),
                  if (tournament.isJoined)
                    const SurfaceBox(
                      color: Color(0x1527C96F),
                      borderColor: AppColors.green,
                      child: Row(children: <Widget>[Icon(Icons.check_circle_rounded, color: AppColors.green), SizedBox(width: 10), Expanded(child: Text('You have joined this tournament.', style: TextStyle(fontWeight: FontWeight.w900)))]),
                    )
                  else if (!state.isLoggedIn && tournament.isUpcoming && tournament.slotsLeft > 0)
                    SizedBox(
                      width: double.infinity,
                      child: FilledButton.icon(
                        onPressed: () => _join(tournament),
                        icon: const Icon(Icons.login_rounded),
                        label: Text('LOGIN TO JOIN FOR ${tournament.entryGold.toStringAsFixed(0)} GOLD'),
                      ),
                    )
                  else if (tournament.canJoin)
                    SizedBox(
                      width: double.infinity,
                      child: FilledButton.icon(
                        onPressed: _joining ? null : () => _join(tournament),
                        icon: _joining ? const SizedBox.square(dimension: 18, child: CircularProgressIndicator(color: Colors.black, strokeWidth: 2)) : const Icon(Icons.add_circle_rounded),
                        label: Text(_joining ? 'JOINING...' : 'JOIN FOR ${tournament.entryGold.toStringAsFixed(0)} GOLD'),
                      ),
                    )
                  else
                    SurfaceBox(
                      color: AppColors.surfaceSoft,
                      child: Text(
                        tournament.isUpcoming ? 'এই tournament এখন join করা যাচ্ছে না। Slot full অথবা registration বন্ধ।' : 'এই tournament-এর registration শেষ হয়েছে।',
                        style: const TextStyle(color: AppColors.muted),
                      ),
                    ),
                ],
              ),
            );
          },
        ),
      );

  List<VideoItem> _orderedVideos(Tournament tournament) {
    final result = <VideoItem>[];
    if (tournament.liveVideo != null) result.add(tournament.liveVideo!);
    for (final video in tournament.videos) {
      if (result.any((item) => item.id != 0 && item.id == video.id)) continue;
      result.add(video);
    }
    result.sort((a, b) {
      int weight(VideoItem item) => item.isLive ? 0 : (item.isHighlight ? 1 : 2);
      return weight(a).compareTo(weight(b));
    });
    return result;
  }
}

class _Banner extends StatelessWidget {
  const _Banner({required this.tournament});
  final Tournament tournament;

  @override
  Widget build(BuildContext context) {
    final image = tournament.bannerUrl.isNotEmpty ? tournament.bannerUrl : tournament.thumbnailUrl;
    return Container(
      height: 195,
      clipBehavior: Clip.antiAlias,
      decoration: BoxDecoration(color: AppColors.surface, borderRadius: BorderRadius.circular(25), border: Border.all(color: AppColors.orange.withValues(alpha: .42))),
      child: Stack(
        fit: StackFit.expand,
        children: <Widget>[
          if (image.isNotEmpty) Image.network(image, fit: BoxFit.cover, errorBuilder: (_, __, ___) => const SizedBox.shrink()),
          DecoratedBox(decoration: BoxDecoration(gradient: LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: <Color>[AppColors.orange.withValues(alpha: .40), AppColors.surface.withValues(alpha: .76), AppColors.bg]))),
          Padding(
            padding: const EdgeInsets.all(18),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                StatusBadge(status: tournament.statusLabel),
                const Spacer(),
                Text(tournament.title, maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 25, fontWeight: FontWeight.w900, height: 1.03)),
                const SizedBox(height: 6),
                Text('${tournament.mode.toUpperCase()} • ${conciseDate(tournament.startAt, tournament.matchDate, tournament.matchTime)}', style: const TextStyle(color: AppColors.muted, fontWeight: FontWeight.w700)),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _InteractionBar extends StatelessWidget {
  const _InteractionBar({required this.interactions, required this.likeLoading, required this.onLike});
  final TournamentInteractions interactions;
  final bool likeLoading;
  final VoidCallback onLike;

  @override
  Widget build(BuildContext context) {
    final hasAny = interactions.likesEnabled || interactions.commentsEnabled || interactions.showViewCount;
    if (!hasAny) return const SizedBox.shrink();
    return SurfaceBox(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
      color: AppColors.surfaceSoft,
      child: Row(
        children: <Widget>[
          if (interactions.showViewCount) _Metric(icon: Icons.visibility_outlined, label: '${interactions.viewCount} views'),
          if (interactions.showViewCount && interactions.likesEnabled) const SizedBox(width: 12),
          if (interactions.likesEnabled)
            InkWell(
              onTap: likeLoading ? null : onLike,
              borderRadius: BorderRadius.circular(16),
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 3, vertical: 3),
                child: likeLoading
                    ? const SizedBox.square(dimension: 18, child: CircularProgressIndicator(strokeWidth: 2, color: AppColors.red))
                    : _Metric(
                        icon: interactions.userHasLiked ? Icons.favorite_rounded : Icons.favorite_border_rounded,
                        label: '${interactions.likeCount}',
                        color: interactions.userHasLiked ? AppColors.red : AppColors.muted,
                      ),
              ),
            ),
          if ((interactions.showViewCount || interactions.likesEnabled) && interactions.commentsEnabled) const SizedBox(width: 12),
          if (interactions.commentsEnabled) _Metric(icon: Icons.chat_bubble_outline_rounded, label: '${interactions.commentCount} comments'),
          const Spacer(),
          if (interactions.commentsEnabled && interactions.commentsLocked)
            const Icon(Icons.lock_outline_rounded, color: AppColors.muted, size: 19),
        ],
      ),
    );
  }
}

class _Metric extends StatelessWidget {
  const _Metric({required this.icon, required this.label, this.color});
  final IconData icon;
  final String label;
  final Color? color;

  @override
  Widget build(BuildContext context) => Row(
        mainAxisSize: MainAxisSize.min,
        children: <Widget>[
          Icon(icon, size: 18, color: color ?? AppColors.muted),
          const SizedBox(width: 5),
          Text(label, style: TextStyle(color: color ?? AppColors.muted, fontSize: 12, fontWeight: FontWeight.w800)),
        ],
      );
}

class _WatchVideoCard extends StatelessWidget {
  const _WatchVideoCard({required this.video, required this.onTap});
  final VideoItem video;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final color = video.isLive ? AppColors.red : (video.isHighlight ? AppColors.cyan : AppColors.orange);
    final label = video.isLive ? 'WATCH LIVE' : (video.isHighlight ? 'WATCH HIGHLIGHT' : 'WATCH REPLAY');
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(18),
      child: SurfaceBox(
        padding: const EdgeInsets.all(12),
        borderColor: color.withValues(alpha: .48),
        child: Row(
          children: <Widget>[
            Container(
              width: 48,
              height: 48,
              alignment: Alignment.center,
              decoration: BoxDecoration(color: color.withValues(alpha: .14), borderRadius: BorderRadius.circular(14)),
              child: Icon(video.isLive ? Icons.sensors_rounded : Icons.play_circle_fill_rounded, color: color),
            ),
            const SizedBox(width: 11),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Text(video.title, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w900)),
                  const SizedBox(height: 4),
                  Text(video.duration.isEmpty ? video.typeLabel : '${video.typeLabel} • ${video.duration}', style: const TextStyle(color: AppColors.muted, fontSize: 11, fontWeight: FontWeight.w700)),
                ],
              ),
            ),
            Text(label, style: TextStyle(color: color, fontSize: 11, fontWeight: FontWeight.w900)),
          ],
        ),
      ),
    );
  }
}

class _CommentSection extends StatelessWidget {
  const _CommentSection({
    required this.tournament,
    required this.isLoggedIn,
    required this.controller,
    required this.sending,
    required this.onSend,
    required this.onLogin,
    required this.onRefresh,
  });

  final Tournament tournament;
  final bool isLoggedIn;
  final TextEditingController controller;
  final bool sending;
  final VoidCallback onSend;
  final VoidCallback onLogin;
  final VoidCallback onRefresh;

  @override
  Widget build(BuildContext context) {
    final interactions = tournament.interactions;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        SectionHeading(title: 'Comments (${interactions.commentCount})', actionLabel: 'REFRESH', onAction: onRefresh),
        const SizedBox(height: 9),
        if (tournament.comments.isEmpty)
          const SurfaceBox(
            child: Row(
              children: <Widget>[
                Icon(Icons.chat_bubble_outline_rounded, color: AppColors.muted),
                SizedBox(width: 10),
                Expanded(child: Text('এখনও কোনো comment নেই। প্রথম comment করুন।', style: TextStyle(color: AppColors.muted))),
              ],
            ),
          )
        else
          ...tournament.comments.map((comment) => Padding(padding: const EdgeInsets.only(bottom: 9), child: _CommentCard(comment: comment))),
        const SizedBox(height: 9),
        if (interactions.commentsLocked)
          const SurfaceBox(
            color: AppColors.surfaceSoft,
            child: Row(
              children: <Widget>[
                Icon(Icons.lock_outline_rounded, color: AppColors.muted),
                SizedBox(width: 10),
                Expanded(child: Text('এই tournament-এর comment এখন বন্ধ আছে।', style: TextStyle(color: AppColors.muted))),
              ],
            ),
          )
        else if (!isLoggedIn)
          SizedBox(
            width: double.infinity,
            child: OutlinedButton.icon(
              onPressed: onLogin,
              icon: const Icon(Icons.login_rounded),
              label: const Text('LOGIN TO COMMENT'),
            ),
          )
        else
          SurfaceBox(
            color: AppColors.surfaceSoft,
            child: Column(
              children: <Widget>[
                TextField(
                  controller: controller,
                  minLines: 1,
                  maxLines: 4,
                  maxLength: 500,
                  textInputAction: TextInputAction.newline,
                  decoration: const InputDecoration(
                    hintText: 'এই tournament নিয়ে comment লিখুন...',
                    counterText: '',
                  ),
                ),
                const SizedBox(height: 9),
                Align(
                  alignment: Alignment.centerRight,
                  child: FilledButton.icon(
                    onPressed: sending ? null : onSend,
                    icon: sending
                        ? const SizedBox.square(dimension: 17, child: CircularProgressIndicator(color: Colors.black, strokeWidth: 2))
                        : const Icon(Icons.send_rounded),
                    label: Text(sending ? 'SENDING...' : 'POST COMMENT'),
                  ),
                ),
              ],
            ),
          ),
      ],
    );
  }
}

class _CommentCard extends StatelessWidget {
  const _CommentCard({required this.comment});
  final TournamentComment comment;

  @override
  Widget build(BuildContext context) => SurfaceBox(
        padding: const EdgeInsets.all(12),
        color: AppColors.surfaceSoft,
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            NetworkAvatar(url: comment.avatarUrl, name: comment.name, radius: 17),
            const SizedBox(width: 10),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Row(
                    children: <Widget>[
                      Expanded(child: Text(comment.name, style: const TextStyle(fontWeight: FontWeight.w900))),
                      Text(_commentTime(comment.createdAt), style: const TextStyle(color: AppColors.muted, fontSize: 10)),
                    ],
                  ),
                  const SizedBox(height: 5),
                  Text(comment.text, style: const TextStyle(color: AppColors.text, height: 1.4)),
                ],
              ),
            ),
          ],
        ),
      );
}

class _InfoCell extends StatelessWidget {
  const _InfoCell({required this.label, required this.value});
  final String label;
  final String value;

  @override
  Widget build(BuildContext context) => Column(children: <Widget>[Text(label, style: const TextStyle(color: AppColors.muted, fontSize: 10, fontWeight: FontWeight.w900, letterSpacing: .7)), const SizedBox(height: 6), Text(value, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 13))]);
}

class _DetailRow extends StatelessWidget {
  const _DetailRow({required this.icon, required this.label, required this.value, this.valueColor});
  final IconData icon;
  final String label;
  final String value;
  final Color? valueColor;

  @override
  Widget build(BuildContext context) => Row(children: <Widget>[Icon(icon, color: AppColors.muted, size: 19), const SizedBox(width: 10), Expanded(child: Text(label, style: const TextStyle(fontWeight: FontWeight.w800))), Flexible(child: Text(value, textAlign: TextAlign.right, style: TextStyle(fontWeight: FontWeight.w900, color: valueColor ?? Colors.white)))]);
}

String _commentTime(String raw) {
  final parsed = DateTime.tryParse(raw);
  if (parsed == null) return '';
  final local = parsed.toLocal();
  final now = DateTime.now();
  final difference = now.difference(local);
  if (difference.inMinutes < 1) return 'now';
  if (difference.inMinutes < 60) return '${difference.inMinutes}m';
  if (difference.inHours < 24) return '${difference.inHours}h';
  return '${local.day}/${local.month}/${local.year}';
}
