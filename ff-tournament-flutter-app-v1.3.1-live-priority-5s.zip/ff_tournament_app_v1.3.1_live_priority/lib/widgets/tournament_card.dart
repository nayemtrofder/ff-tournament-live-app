import 'package:flutter/material.dart';

import '../core/app_theme.dart';
import '../core/formatters.dart';
import '../models/tournament.dart';
import 'common.dart';

class TournamentCard extends StatelessWidget {
  const TournamentCard({super.key, required this.tournament, this.onTap, this.compact = false});
  final Tournament tournament;
  final VoidCallback? onTap;
  final bool compact;

  @override
  Widget build(BuildContext context) {
    final image = tournament.bannerUrl.isNotEmpty ? tournament.bannerUrl : tournament.thumbnailUrl;
    final showInteractions = tournament.interactions.likesEnabled || tournament.interactions.commentsEnabled || tournament.interactions.showViewCount;
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(22),
      child: Container(
        height: compact ? 166 : 205,
        clipBehavior: Clip.antiAlias,
        decoration: BoxDecoration(
          color: AppColors.surface,
          borderRadius: BorderRadius.circular(22),
          border: Border.all(color: tournament.isLive ? AppColors.red.withValues(alpha: .75) : AppColors.border),
        ),
        child: Stack(
          fit: StackFit.expand,
          children: [
            if (image.isNotEmpty)
              Image.network(image, fit: BoxFit.cover, errorBuilder: (_, __, ___) => const SizedBox.shrink()),
            DecoratedBox(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [
                    Colors.black.withValues(alpha: image.isNotEmpty ? .12 : .02),
                    AppColors.surface.withValues(alpha: .74),
                    AppColors.surface,
                  ],
                ),
              ),
            ),
            if (image.isEmpty)
              const Positioned(
                right: -18,
                top: -20,
                child: Icon(Icons.sports_esports_rounded, size: 150, color: AppColors.surfaceSoft),
              ),
            Padding(
              padding: const EdgeInsets.all(15),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      StatusBadge(status: tournament.statusLabel),
                      const Spacer(),
                      GoldPill(value: goldText(tournament.entryGold), compact: true),
                    ],
                  ),
                  const Spacer(),
                  Text(
                    tournament.title,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w900, letterSpacing: -.25),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    '${tournament.mode.toUpperCase()} • ${conciseDate(tournament.startAt, tournament.matchDate, tournament.matchTime)}',
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(color: AppColors.muted, fontSize: 12),
                  ),
                  const SizedBox(height: 10),
                  Row(
                    children: [
                      const Icon(Icons.workspace_premium_rounded, color: AppColors.gold, size: 17),
                      const SizedBox(width: 5),
                      Expanded(
                        child: Text(
                          tournament.prize.isNotEmpty ? tournament.prize : 'Prize announced soon',
                          style: const TextStyle(color: AppColors.gold, fontWeight: FontWeight.w800),
                        ),
                      ),
                      Text('${tournament.joined}/${tournament.slots}', style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 12)),
                    ],
                  ),
                  if (showInteractions) ...[
                    const SizedBox(height: 9),
                    _InteractionRow(tournament: tournament),
                  ],
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _InteractionRow extends StatelessWidget {
  const _InteractionRow({required this.tournament});
  final Tournament tournament;

  @override
  Widget build(BuildContext context) => Row(
        children: <Widget>[
          if (tournament.interactions.showViewCount)
            _CountChip(icon: Icons.visibility_outlined, value: '${tournament.interactions.viewCount}'),
          if (tournament.interactions.showViewCount && tournament.interactions.likesEnabled) const SizedBox(width: 7),
          if (tournament.interactions.likesEnabled)
            _CountChip(
              icon: tournament.interactions.userHasLiked ? Icons.favorite_rounded : Icons.favorite_border_rounded,
              value: '${tournament.interactions.likeCount}',
              active: tournament.interactions.userHasLiked,
            ),
          if ((tournament.interactions.showViewCount || tournament.interactions.likesEnabled) && tournament.interactions.commentsEnabled) const SizedBox(width: 7),
          if (tournament.interactions.commentsEnabled) _CountChip(icon: Icons.chat_bubble_outline_rounded, value: '${tournament.interactions.commentCount}'),
        ],
      );
}

class _CountChip extends StatelessWidget {
  const _CountChip({required this.icon, required this.value, this.active = false});
  final IconData icon;
  final String value;
  final bool active;

  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 5),
        decoration: BoxDecoration(
          color: Colors.black.withValues(alpha: .18),
          border: Border.all(color: active ? AppColors.red.withValues(alpha: .65) : AppColors.border.withValues(alpha: .7)),
          borderRadius: BorderRadius.circular(99),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: <Widget>[
            Icon(icon, size: 14, color: active ? AppColors.red : AppColors.muted),
            const SizedBox(width: 4),
            Text(value, style: TextStyle(color: active ? AppColors.red : AppColors.muted, fontSize: 11, fontWeight: FontWeight.w800)),
          ],
        ),
      );
}
