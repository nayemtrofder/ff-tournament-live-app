# Flutter App v1.3.1 Build নির্দেশনা

এই source update-এ `lib/`, `pubspec.yaml` ও documentation আছে। আপনার আগের Codespaces Flutter project-এ তৈরি করা `android/` folder ও `AndroidManifest.xml` রেখে দিতে হবে।

## ১. বর্তমান source replace

1. নতুন ZIP Codespaces-এ upload করুন এবং extract করুন।
2. Extracted folder থেকে শুধু `lib/` folder ও `pubspec.yaml` আপনার বর্তমান Flutter project-এ replace করুন।
3. বর্তমান `android/` folder delete করবেন না।

## ২. Internet permission verify

`android/app/src/main/AndroidManifest.xml`-এ নিচের line থাকতে হবে:

```xml
<uses-permission android:name="android.permission.INTERNET" />
```

## ৩. Package install

Project root-এ:

```bash
flutter pub get
```

## ৪. Release APK build

```bash
flutter build apk --release --dart-define=FFTS_API_BASE_URL=https://fftrustbd.com/wp-json/ffts-app/v1
```

APK file:

```text
build/app/outputs/flutter-apk/app-release.apk
```

## ৫. GitHub Release upload

নতুন version-এর জন্য নতুন tag ব্যবহার করুন:

```bash
gh release create v1.3.1 build/app/outputs/flutter-apk/app-release.apk --title "FF Tournament App v1.3.1" --notes "5-second live priority refresh"
```

যদি tag আগে থেকে থাকে, APK replace করতে:

```bash
gh release upload v1.3.1 build/app/outputs/flutter-apk/app-release.apk --clobber
```

## ৬. WordPress App Update Center সেট করুন

FF Tournament Live Bridge → App Update Center:

- App update check: ON
- Latest Version: `1.3.1`
- Version Code: `5`
- APK Download Link: GitHub Release-এর direct APK link
- Update Type: Optional (জরুরি হলে Force Update)
- Minimum Supported Version Code: `0`
- What's New: 5-second live banner priority and auto refresh
