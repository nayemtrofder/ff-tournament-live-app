# FF Tournament App v1.3.1 — Live Priority Update

## নতুন পরিবর্তন

- Home tab visible থাকা অবস্থায় প্রতি **5 সেকেন্ডে** হালকা `live/current` API check হবে।
- Live শুরু বা শেষ হলে App সঙ্গে সঙ্গে পুরো Home data reload করবে।
- নতুন Live item আসলে Hero slider user যে slide-এই থাকুক, banner **অটোমেটিক প্রথম slide-এ** চলে যাবে।
- Home tab ছাড়লে বা App background-এ গেলে 5-second live polling বন্ধ হবে। তাই অপ্রয়োজনীয় API load হবে না।
- Full Home refresh আগের মতো server hint অনুযায়ী চলবে; দ্রুত Live detection-এর জন্য আলাদা ছোট endpoint ব্যবহার করা হয়েছে।
- Android/App version: **1.3.1**, version code: **5**.

## বাস্তব আচরণ

App খোলা এবং Home tab-এ থাকলে Host Live Start/End করার পর সাধারণত **0–5 সেকেন্ডের মধ্যে** Home banner বদলাবে। ইন্টারনেট, server response বা WordPress cache ধীর হলে আরও কিছু সময় লাগতে পারে।

App background/বন্ধ থাকলে automatic banner change দেখানো সম্ভব নয়। App খুললে বা Home tab-এ ফিরলে সঙ্গে সঙ্গে refresh হবে। Push notification আলাদা feature।
