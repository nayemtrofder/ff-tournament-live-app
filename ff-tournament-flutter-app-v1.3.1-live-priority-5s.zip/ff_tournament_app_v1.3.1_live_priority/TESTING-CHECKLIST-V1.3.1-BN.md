# FF Tournament App v1.3.1 — Testing Checklist

- [ ] App Home tab খোলা রেখে WordPress থেকে একটি Live Session Start করুন।
- [ ] সর্বোচ্চ প্রায় 5 সেকেন্ডে `LIVE NOW` banner Hero slider-এর প্রথম slide-এ আসে।
- [ ] User slider-এর অন্য slide-এ থাকলেও Live আসলে slider প্রথম slide-এ ফিরে আসে।
- [ ] Live End করলে সর্বোচ্চ প্রায় 5 সেকেন্ডে Live banner সরে যায়।
- [ ] Home tab থেকে অন্য tab-এ গেলে polling বন্ধ থাকে।
- [ ] App background থেকে আবার খুললে Home নতুন Live status reload করে।
- [ ] Tournament banner, highlight card ও Today’s Highlights আগের মতো কাজ করে।
- [ ] Profile, Join, Notifications, Leaderboard এবং video player আগের মতো কাজ করে।
