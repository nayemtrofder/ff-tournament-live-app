# Build Fix — v1.2.0 source

এই ZIP source-only Flutter project। তাই `android/` folder না থাকা স্বাভাবিক; প্রথমবার build করার আগে `flutter create --platforms=android .` চালাতে হবে।

এই package-এ `lib/screens/leaderboard_screen.dart`-এর `Podium(...)` call ঠিক করে `LeaderboardPodium(...)` করা হয়েছে।

Build command:

```bash
flutter pub get
flutter build apk --release --dart-define=FFTS_API_BASE_URL=https://YOUR-DOMAIN.com/wp-json/ffts-app/v1
```
