# FF Tournament Flutter App — v1.2.0 (Real Data + YouTube In‑App Player)

এই Flutter source আপনার **FF Tournament System** এবং **FF Tournament Live Bridge v1.4.0**-এর জন্য তৈরি।

## সবচেয়ে গুরুত্বপূর্ণ কথা

এই app-এ কোনো demo tournament, fake player, fake team/logo, fake Gold balance, fake prize, fake leaderboard বা sample slider data নেই।

প্রতিটি screen শুধু WordPress/plugin database থেকে আসা API data দেখাবে:

- website-এ live match না থাকলে Live screen খালি থাকবে
- upcoming tournament না থাকলে Home slider/card খালি থাকবে
- user join না করলে My Matches খালি থাকবে
- result publish না হলে leaderboard-এ ranking খালি থাকবে
- Gold transaction না থাকলে wallet history খালি থাকবে
- notification না থাকলে notification list খালি থাকবে

অর্থাৎ app-এ যা দেখাবে, সেটাই আপনার website/plugin-এ সত্যি আছে।

## নতুন: YouTube video app-এর ভিতরে

- Live Match → `WATCH LIVE IN APP` চাপলে YouTube live app-এর ভিতরেই play হবে।
- Replay / Highlights → card চাপলে YouTube video app-এর ভিতরেই play হবে।
- Browser বা YouTube app auto open হবে না।
- Player-এ fullscreen এবং YouTube-এর নিজের controls থাকবে।
- Link অবশ্যই valid YouTube URL বা 11-character YouTube Video ID হতে হবে।

বিস্তারিত setup: `YOUTUBE-IN-APP-SETUP-BN.md`

## Real API Version প্রয়োজন

Release build চালাতে **FF Tournament Live Bridge v1.4.0 Full App API** install/replace করা লাগবে। এই version-এ নিচের route আছে:

```text
GET  /home
GET  /live/current
GET  /leaderboards
GET  /tournaments
GET  /tournaments/{id}
POST /tournaments/{id}/join
POST /auth/login
POST /auth/logout
GET  /profile
GET  /wallet
GET  /wallet/history
GET  /buy-gold-url
GET  /videos
GET  /my-matches
GET  /notifications
POST /notifications/{id}/read
POST /notifications/read-all
POST /live/verify
POST /live/start
POST /live/end
```

## App screens

- Splash + secure login session
- Home: auto slider, live match, real leaderboard preview, upcoming matches, replay/highlight
- Tournaments: upcoming/live/completed match list
- Tournament details: real match data, Gold join, private room ID/password only when server allows
- Leaderboard: Live, Weekly, All Time ranking; live tab 25 seconds পরপর refresh হয়
- My Matches: joined upcoming/live/completed/cancelled matches
- Profile: website profile photo, IGN, FF UID, Guild, Server, mode, rank, matches, wins, kills
- Gold Wallet: real balance, held Gold, winning balance, real transaction history, Buy Gold website button
- Notifications: real database notification list + read status
- Live Watch: real YouTube live in app
- Replays & Highlights: real YouTube video in app
- Host Live Control: authorised Stream Host/Admin-এর জন্য verify/start/end

## API Base URL

App player-এর কাছে কোনো API URL input চাইবে না। Release build করার সময় developer একবার actual API URL set করবে:

```text
https://YOUR-DOMAIN.com/wp-json/ffts-app/v1
```

## Android Build

এই ZIP source project। Android platform folder প্রথমবার তৈরি করতে:

```bash
flutter create . --platforms=android
flutter pub get
flutter test
```

`platform_setup/AndroidManifest.xml.snippet` থেকে এই permission generated Android manifest-এ যোগ করবেন:

```xml
<uses-permission android:name="android.permission.INTERNET" />
```

তারপর APK:

```bash
flutter build apk --release --dart-define=FFTS_API_BASE_URL=https://YOUR-DOMAIN.com/wp-json/ffts-app/v1
```

Play Store AAB:

```bash
flutter build appbundle --release --dart-define=FFTS_API_BASE_URL=https://YOUR-DOMAIN.com/wp-json/ffts-app/v1
```

## Data security rules

- Join, slot limit, duplicate join, Gold hold/refund, result, prize, room visibility সব server/plugin নিয়ন্ত্রণ করে।
- App কখনো Gold, prize, room password বা rank নিজে তৈরি বা edit করে না।
- Buy Gold payment/verification, withdrawal approval, tournament create/edit এবং result publish website admin panel-এই থাকবে।
- Room ID/password শুধু API server eligible joined user-কে পাঠালে app দেখাবে।
- App video storage ব্যবহার করে না; plugin/API থেকে পাওয়া YouTube link শুধু embedded player-এ দেখায়।

---

## v1.3.1 Update

v1.3.1-এ Banner image, Like/Comment/View, linked YouTube video buttons, Home auto refresh এবং App Update Center support যোগ হয়েছে। Build করার আগে `CHANGELOG-V1.3.0-BN.md` এবং `APP-UPDATE-BUILD-INSTRUCTIONS-BN.md` পড়ুন।
