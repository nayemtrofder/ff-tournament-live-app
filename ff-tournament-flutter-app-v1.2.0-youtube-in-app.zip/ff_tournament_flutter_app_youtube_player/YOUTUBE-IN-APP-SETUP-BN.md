# YouTube In‑App Player Setup — v1.2.0

এই version-এ YouTube live, replay ও highlight **app-এর ভিতরেই** play হবে। User-কে browser বা YouTube app-এ পাঠানো হবে না।

## আপনার কাজ

### Live tournament-এর জন্য

1. আপনার mobile থেকে YouTube-এ live শুরু করুন।
2. YouTube-এর live watch URL কপি করুন। যেমন:

```text
https://www.youtube.com/watch?v=VIDEO_ID
```

3. WordPress Live Session-এর **YouTube URL** field-এ link দিন।
4. Match status live করুন বা Host Live Control দিয়ে `Start Live` দিন।
5. App Home slider এবং Live Match page-এ `WATCH LIVE IN APP` দেখা যাবে।

### Replay / highlight-এর জন্য

1. Live শেষ হলে YouTube replay public রাখুন।
2. WordPress-এর App Videos / Replay / Highlight section-এ YouTube URL দিন।
3. App-এর Home highlight card বা Replays & Highlights page থেকে video app-এর ভিতরে চলবে।

## Accepted YouTube formats

```text
https://www.youtube.com/watch?v=VIDEO_ID
https://youtu.be/VIDEO_ID
https://www.youtube.com/live/VIDEO_ID
https://www.youtube.com/shorts/VIDEO_ID
https://www.youtube.com/embed/VIDEO_ID
VIDEO_ID
```

## গুরুত্বপূর্ণ নিয়ম

- YouTube URL public বা embed-allowed হতে হবে।
- Live বা video private/deleted হলে app player তা চালাতে পারবে না।
- Facebook, Drive বা অন্য video link এই release-এর in-app YouTube player-এ চলবে না। সেগুলোকে YouTube URL-এ বদলাতে হবে।
- YouTube-এর logo, ad, fullscreen ও নিজের player controls YouTube-এর নিয়ম অনুসারে থাকবে। এগুলো app থেকে লুকানো যাবে না।
- App কোনো video file নিজের storage-এ download বা store করে না। শুধু WordPress API থেকে পাওয়া YouTube link play করে।

## Developer commands

```bash
flutter pub get
flutter test
flutter build apk --release --dart-define=FFTS_API_BASE_URL=https://YOUR-DOMAIN.com/wp-json/ffts-app/v1
```
