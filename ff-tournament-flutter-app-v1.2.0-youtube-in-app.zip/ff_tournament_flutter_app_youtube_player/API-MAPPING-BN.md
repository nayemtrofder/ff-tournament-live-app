# Full Real Data API Mapping — v1.2.0 App / v1.4.0 API

| App feature | API route | Data source |
|---|---|---|
| Home auto slider | `GET /home` | Actual current live session, actual upcoming tournaments, actual videos |
| Live match + in-app YouTube player | `GET /live/current` | Live Bridge session + main tournament match + `youtube_url` or YouTube playback URL |
| Tournament list | `GET /tournaments?status=...` | `ffts_matches` |
| Tournament details | `GET /tournaments/{id}` | Match, registration status, real leaderboard, secure room rule |
| Gold join | `POST /tournaments/{id}/join` | Real registration + Gold wallet transaction |
| Live/weekly/all-time leaderboard | `GET /leaderboards?scope=...` | Main plugin scoreboard/registrations |
| Login/logout | `POST /auth/login`, `POST /auth/logout` | Live Bridge token table |
| Profile/avatar/stats | `GET /profile` | WordPress user profile + FF Tournament profile/meta/stats |
| Gold balance | `GET /wallet` | Main plugin Gold wallet |
| Wallet transaction history | `GET /wallet/history` | `tournament_gold_history` |
| Buy Gold link | `GET /buy-gold-url` | Main plugin Buy Gold page URL |
| Replays/highlights + in-app YouTube player | `GET /videos?scope=today|all` | Live Bridge App Videos settings → YouTube URL |
| My Matches | `GET /my-matches` | Logged-in user registrations + matches |
| Notifications | `GET /notifications` | Main plugin notifications table |
| Mark one/all notification read | `POST /notifications/{id}/read`, `POST /notifications/read-all` | Main plugin notifications table |
| Host live control | `POST /live/verify`, `/live/start`, `/live/end` | Live Bridge host session |

## YouTube video link rules

- Live API: `youtube_url` first priority। এটি না থাকলে `playback_url` YouTube URL হলে ব্যবহার হবে।
- Video API: `url` / `video_url` অবশ্যই YouTube URL বা direct YouTube Video ID হতে হবে।
- Accepted: watch, youtu.be, live, shorts, embed এবং direct 11-character ID.
- Facebook/Drive/other URL হলে app in-app player video চালাবে না; valid YouTube link-এর error দেখাবে।

## No local fallback

App-এর code-এ কোনো local tournament/player/Gold/leaderboard/slides data নেই। API empty হলে screen empty state দেখাবে; API error হলে error state দেখাবে। Video URL ভুল হলে app external browser open করবে না।
