# Real Data Audit — v1.2.0

## Local demo data removed

- `lib/data/demo_data.dart` নেই।
- কোনো screen API fail হলে fake tournament/player/Gold/leaderboard দেখায় না।
- Website/API থেকে data না এলে loading, empty state বা error state দেখায়।
- API URL player input screen নেই; release build-এর সময় একবার actual API base URL দেওয়া হয়।

## Real data-backed screens

| Screen | Real source |
|---|---|
| Home | `/home` |
| Tournament list/details | `/tournaments`, `/tournaments/{id}` |
| Join | `/tournaments/{id}/join` |
| Leaderboard | `/leaderboards` |
| My Matches | `/my-matches` |
| Profile | `/profile` |
| Wallet + history | `/wallet`, `/wallet/history` |
| Notifications | `/notifications` |
| Videos | `/videos` → real YouTube URL → in-app player |
| Live Watch | `/live/current` → `youtube_url` / YouTube playback URL → in-app player |
| Host live status | `/live/verify`, `/live/start`, `/live/end` |

## YouTube player validation

- YouTube URL/Video ID parsing unit test যোগ করা হয়েছে: `test/youtube_utils_test.dart`.
- Accepted formats: watch, short `youtu.be`, live, shorts, embed এবং direct video ID.
- Non-YouTube URL local fallback বা external open করবে না; user-কে valid YouTube link-এর error দেখাবে।
- Player overlay দিয়ে YouTube controls আড়াল করা হয়নি।

## What cannot be verified without your live server

এই environment-এ আপনার WordPress server/API Base URL বা actual tournament database নেই। Flutter SDK-ও এখানে install করা নেই। তাই server response, Android compilation, YouTube playback এবং phone screen live connection এখানে চালিয়ে দেখা সম্ভব হয়নি। Release build-এর আগে `flutter pub get`, `flutter test` ও real-device playback check চালাতে হবে।
