# Release Build Checklist — Real Data + YouTube In‑App Player

1. WordPress-এ **FF Tournament System** active রাখুন।
2. পরে যখন ready হবেন, `ff-tournament-live-bridge-v1.4.0-full-app-api.zip` install/replace করুন।
3. Live Bridge dashboard থেকে API Base URL কপি করুন।
4. Flutter source extract করে terminal-এ চালান:

```bash
flutter create . --platforms=android
flutter pub get
flutter test
```

5. `android/app/src/main/AndroidManifest.xml`-এ INTERNET permission যোগ করুন:

```xml
<uses-permission android:name="android.permission.INTERNET" />
```

6. WordPress Live Session-এ YouTube live URL দিন এবং App Videos-এ YouTube replay/highlight URL দিন। বিস্তারিত `YOUTUBE-IN-APP-SETUP-BN.md`-এ আছে।

7. Actual API URL দিয়ে release APK build করুন:

```bash
flutter build apk --release --dart-define=FFTS_API_BASE_URL=https://YOUR-DOMAIN.com/wp-json/ffts-app/v1
```

8. Play Store-এর জন্য:

```bash
flutter build appbundle --release --dart-define=FFTS_API_BASE_URL=https://YOUR-DOMAIN.com/wp-json/ffts-app/v1
```

## Build করার আগে মনে রাখবেন

- `YOUR-DOMAIN.com` জায়গায় আপনার actual website domain বসবে।
- API plugin v1.4.0 ছাড়া My Matches, notifications এবং Gold history route পাওয়া যাবে না।
- App release package name, app icon, signing key ও privacy policy আলাদা করে set করতে হবে।
- App-এ কোনো demo data নেই; website-এ record না থাকলে app খালি দেখাবে।
- YouTube link public ও embed-allowed না হলে app-এর ভিতরে video চলবে না।
