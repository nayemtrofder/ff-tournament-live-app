import 'package:flutter_test/flutter_test.dart';

import '../lib/core/youtube_utils.dart';

void main() {
  group('YouTubeVideoRef', () {
    test('accepts common YouTube link formats', () {
      const id = 'dQw4w9WgXcQ';
      final sources = <String>[
        id,
        'https://www.youtube.com/watch?v=$id',
        'https://youtu.be/$id',
        'https://www.youtube.com/live/$id',
        'https://www.youtube.com/shorts/$id',
        'https://www.youtube-nocookie.com/embed/$id',
      ];

      for (final source in sources) {
        expect(YouTubeVideoRef.tryParse(source)?.videoId, id);
      }
    });

    test('rejects non-YouTube and incomplete links', () {
      expect(YouTubeVideoRef.tryParse('https://facebook.com/live/example'), isNull);
      expect(YouTubeVideoRef.tryParse('https://youtube.com/watch?v=short'), isNull);
      expect(YouTubeVideoRef.tryParse(''), isNull);
    });
  });
}
