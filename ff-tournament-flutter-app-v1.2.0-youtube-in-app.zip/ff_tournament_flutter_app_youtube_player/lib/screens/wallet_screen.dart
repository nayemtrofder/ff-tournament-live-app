import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:url_launcher/url_launcher.dart';

import '../core/api_client.dart';
import '../core/app_state.dart';
import '../core/app_theme.dart';
import '../core/formatters.dart';
import '../models/wallet_transaction.dart';
import '../widgets/common.dart';

class WalletScreen extends StatefulWidget {
  const WalletScreen({super.key});

  @override
  State<WalletScreen> createState() => _WalletScreenState();
}

class _WalletScreenState extends State<WalletScreen> {
  late Future<_WalletBundle> _future;
  bool _opening = false;

  @override
  void initState() {
    super.initState();
    _future = _loadData();
  }

  Future<_WalletBundle> _loadData() async {
    final api = context.read<AppState>().api;
    final results = await Future.wait<dynamic>(<Future<dynamic>>[api.getWallet(), api.getWalletHistory()]);
    return _WalletBundle(wallet: results[0] as WalletPayload, history: results[1] as WalletHistoryPayload);
  }

  void _reload() => setState(() => _future = _loadData());

  Future<void> _buyGold() async {
    setState(() => _opening = true);
    try {
      final url = await context.read<AppState>().api.getBuyGoldUrl();
      if (url.isEmpty || !await launchUrl(Uri.parse(url), mode: LaunchMode.externalApplication)) {
        throw const ApiException('Buy Gold page open করা যায়নি।');
      }
    } on ApiException catch (error) {
      if (mounted) showAppMessage(context, error.message, error: true);
    } finally {
      if (mounted) setState(() => _opening = false);
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('Gold Wallet')),
        body: FutureBuilder<_WalletBundle>(
          future: _future,
          builder: (context, snapshot) {
            if (snapshot.connectionState == ConnectionState.waiting) return const PageLoading(label: 'Wallet loading...');
            if (snapshot.hasError) return Padding(padding: const EdgeInsets.all(16), child: ErrorPanel(message: snapshot.error.toString(), onRetry: _reload));
            final bundle = snapshot.data;
            if (bundle == null) return Padding(padding: const EdgeInsets.all(16), child: ErrorPanel(message: 'Wallet data পাওয়া যায়নি।', onRetry: _reload));
            final wallet = bundle.wallet;
            return RefreshIndicator(
              color: AppColors.orange,
              onRefresh: () async => _reload(),
              child: ListView(
                padding: const EdgeInsets.all(16),
                physics: const AlwaysScrollableScrollPhysics(),
                children: <Widget>[
                  Container(
                    padding: const EdgeInsets.all(23),
                    decoration: BoxDecoration(borderRadius: BorderRadius.circular(26), gradient: const LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: <Color>[Color(0xFF4C3511), Color(0xFF151A25)]), border: Border.all(color: AppColors.gold.withValues(alpha: .5))),
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: <Widget>[const Icon(Icons.workspace_premium_rounded, color: AppColors.gold, size: 39), const SizedBox(height: 18), const Text('AVAILABLE GOLD', style: TextStyle(color: AppColors.muted, fontWeight: FontWeight.w900, letterSpacing: 1.1)), const SizedBox(height: 5), Text('${wallet.gold.toStringAsFixed(0)} Gold', style: const TextStyle(color: AppColors.gold, fontSize: 37, fontWeight: FontWeight.w900)), const SizedBox(height: 7), Text('Held for entries: ${goldText(wallet.heldGold)}', style: const TextStyle(color: AppColors.muted))]),
                  ),
                  const SizedBox(height: 12),
                  if (wallet.winningBalance > 0)
                    SurfaceBox(color: AppColors.green.withValues(alpha: .08), borderColor: AppColors.green.withValues(alpha: .38), child: Row(children: <Widget>[const Icon(Icons.emoji_events_rounded, color: AppColors.green), const SizedBox(width: 10), const Expanded(child: Text('Winning balance', style: TextStyle(fontWeight: FontWeight.w800))), Text(wallet.winningBalance.toStringAsFixed(2), style: const TextStyle(color: AppColors.green, fontSize: 18, fontWeight: FontWeight.w900))])),
                  const SizedBox(height: 16),
                  FilledButton.icon(onPressed: _opening ? null : _buyGold, icon: _opening ? const SizedBox.square(dimension: 18, child: CircularProgressIndicator(color: Colors.black, strokeWidth: 2)) : const Icon(Icons.add_circle_rounded), label: Text(_opening ? 'OPENING...' : 'BUY GOLD ON WEBSITE')),
                  const SizedBox(height: 22),
                  const SectionHeading(title: 'Gold History'),
                  const SizedBox(height: 9),
                  if (bundle.history.items.isEmpty)
                    const SurfaceBox(child: Text('Gold transaction history এখনো নেই। Website থেকে Gold buy, join, refund বা prize হলে এখানে real history আসবে।', style: TextStyle(color: AppColors.muted, height: 1.45)))
                  else
                    ...bundle.history.items.map((item) => Padding(padding: const EdgeInsets.only(bottom: 9), child: _TransactionRow(item: item))),
                  const SizedBox(height: 12),
                  const Text('Buy Gold/payment verification website-এর existing secure system থেকেই হবে।', textAlign: TextAlign.center, style: TextStyle(color: AppColors.muted, fontSize: 11, height: 1.4)),
                ],
              ),
            );
          },
        ),
      );
}

class _WalletBundle {
  const _WalletBundle({required this.wallet, required this.history});
  final WalletPayload wallet;
  final WalletHistoryPayload history;
}

class _TransactionRow extends StatelessWidget {
  const _TransactionRow({required this.item});
  final WalletTransaction item;

  @override
  Widget build(BuildContext context) {
    final settled = item.direction == 'settled';
    final debit = item.direction == 'debit';
    final color = settled ? AppColors.muted : debit ? AppColors.red : AppColors.green;
    final sign = settled ? '' : debit ? '−' : '+';
    final amount = settled ? item.amount.toStringAsFixed(0) : item.effectiveAmount.abs().toStringAsFixed(0);
    return SurfaceBox(
      padding: const EdgeInsets.symmetric(horizontal: 13, vertical: 12),
      child: Row(children: <Widget>[
        Container(width: 38, height: 38, alignment: Alignment.center, decoration: BoxDecoration(shape: BoxShape.circle, color: color.withValues(alpha: .14)), child: Icon(settled ? Icons.lock_clock_rounded : debit ? Icons.remove_circle_outline_rounded : Icons.add_circle_outline_rounded, color: color, size: 20)),
        const SizedBox(width: 11),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: <Widget>[Text(item.description.isEmpty ? item.type.toUpperCase() : item.description, maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w800)), const SizedBox(height: 3), Text(item.matchTitle.isNotEmpty ? item.matchTitle : item.type.toUpperCase(), style: const TextStyle(color: AppColors.muted, fontSize: 11))])),
        const SizedBox(width: 8),
        Text('$sign$amount', style: TextStyle(color: color, fontWeight: FontWeight.w900, fontSize: 17)),
      ]),
    );
  }
}
