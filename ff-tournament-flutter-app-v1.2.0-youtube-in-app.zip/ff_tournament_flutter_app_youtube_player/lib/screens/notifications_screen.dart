import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../core/api_client.dart';
import '../core/app_state.dart';
import '../core/app_theme.dart';
import '../models/notification_item.dart';
import '../widgets/common.dart';
import 'login_screen.dart';

class NotificationsScreen extends StatefulWidget {
  const NotificationsScreen({super.key});

  @override
  State<NotificationsScreen> createState() => _NotificationsScreenState();
}

class _NotificationsScreenState extends State<NotificationsScreen> {
  late Future<NotificationsPayload> _future;
  bool _markingAll = false;

  @override
  void initState() {
    super.initState();
    _future = _loadData();
  }

  Future<NotificationsPayload> _loadData() {
    final state = context.read<AppState>();
    if (!state.isLoggedIn) return Future<NotificationsPayload>.value(const NotificationsPayload(items: <AppNotification>[], unreadCount: 0, total: 0));
    return state.api.getNotifications();
  }

  void _reload() => setState(() => _future = _loadData());

  Future<void> _markAllRead() async {
    setState(() => _markingAll = true);
    try {
      final unread = await context.read<AppState>().api.markAllNotificationsRead();
      context.read<AppState>().setUnreadNotifications(unread);
      _reload();
    } on ApiException catch (error) {
      if (mounted) showAppMessage(context, error.message, error: true);
    } finally {
      if (mounted) setState(() => _markingAll = false);
    }
  }

  Future<void> _markRead(AppNotification item) async {
    if (item.isRead) return;
    try {
      final unread = await context.read<AppState>().api.markNotificationRead(item.id);
      context.read<AppState>().setUnreadNotifications(unread);
      _reload();
    } on ApiException catch (error) {
      if (mounted) showAppMessage(context, error.message, error: true);
    }
  }

  @override
  Widget build(BuildContext context) {
    final loggedIn = context.watch<AppState>().isLoggedIn;
    if (!loggedIn) {
      return Scaffold(
        appBar: AppBar(title: const Text('Notifications')),
        body: Center(child: EmptyState(icon: Icons.notifications_off_outlined, title: 'Login required', message: 'Room ID release, match reminder, result এবং Gold update দেখতে login করুন।', action: FilledButton.icon(onPressed: () async { await Navigator.push(context, MaterialPageRoute<bool>(builder: (_) => const LoginScreen())); if (mounted) _reload(); }, icon: const Icon(Icons.login_rounded), label: const Text('LOGIN')))),
      );
    }
    return Scaffold(
      appBar: AppBar(
        title: const Text('Notifications'),
        actions: <Widget>[
          TextButton(
            onPressed: _markingAll ? null : _markAllRead,
            child: Text(_markingAll ? '...' : 'READ ALL', style: const TextStyle(color: AppColors.orange, fontWeight: FontWeight.w900, fontSize: 11)),
          ),
        ],
      ),
      body: FutureBuilder<NotificationsPayload>(
        future: _future,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) return const PageLoading(label: 'Notifications loading...');
          if (snapshot.hasError) return Padding(padding: const EdgeInsets.all(16), child: ErrorPanel(message: snapshot.error.toString(), onRetry: _reload));
          final payload = snapshot.data ?? const NotificationsPayload(items: <AppNotification>[], unreadCount: 0, total: 0);
          WidgetsBinding.instance.addPostFrameCallback((_) {
            if (mounted) context.read<AppState>().setUnreadNotifications(payload.unreadCount);
          });
          if (payload.items.isEmpty) {
            return const Center(child: EmptyState(icon: Icons.notifications_none_rounded, title: 'No notifications yet', message: 'Tournament join, room release, result বা Gold update হলে এখানে আসবে।'));
          }
          return RefreshIndicator(
            color: AppColors.orange,
            onRefresh: () async => _reload(),
            child: ListView.separated(
              padding: const EdgeInsets.fromLTRB(16, 14, 16, 28),
              physics: const AlwaysScrollableScrollPhysics(),
              itemCount: payload.items.length,
              separatorBuilder: (_, __) => const SizedBox(height: 10),
              itemBuilder: (_, index) {
                final item = payload.items[index];
                return InkWell(
                  onTap: () => _markRead(item),
                  borderRadius: BorderRadius.circular(18),
                  child: SurfaceBox(
                    color: item.isRead ? AppColors.surface : AppColors.cyan.withValues(alpha: .08),
                    borderColor: item.isRead ? AppColors.border : AppColors.cyan.withValues(alpha: .42),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        Container(
                          width: 40,
                          height: 40,
                          alignment: Alignment.center,
                          decoration: BoxDecoration(shape: BoxShape.circle, color: _typeColor(item.type).withValues(alpha: .16)),
                          child: Icon(_typeIcon(item.type), color: _typeColor(item.type), size: 20),
                        ),
                        const SizedBox(width: 11),
                        Expanded(
                          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: <Widget>[
                            Row(children: <Widget>[Expanded(child: Text(item.title, style: TextStyle(fontWeight: item.isRead ? FontWeight.w700 : FontWeight.w900))), if (!item.isRead) Container(width: 7, height: 7, decoration: const BoxDecoration(color: AppColors.cyan, shape: BoxShape.circle))]),
                            const SizedBox(height: 4),
                            Text(item.message, style: const TextStyle(color: AppColors.muted, height: 1.35)),
                            const SizedBox(height: 7),
                            Text(_shortDate(item.createdAt), style: const TextStyle(color: AppColors.muted, fontSize: 10)),
                          ]),
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
          );
        },
      ),
    );
  }
}

IconData _typeIcon(String value) {
  switch (value.toLowerCase()) {
    case 'join_success':
    case 'join':
      return Icons.emoji_events_rounded;
    case 'payment_success':
    case 'payment':
      return Icons.account_balance_wallet_rounded;
    case 'reward':
      return Icons.workspace_premium_rounded;
    default:
      return Icons.notifications_rounded;
  }
}

Color _typeColor(String value) {
  switch (value.toLowerCase()) {
    case 'join_success':
    case 'join':
      return AppColors.gold;
    case 'payment_success':
    case 'payment':
      return AppColors.cyan;
    case 'reward':
      return AppColors.green;
    default:
      return AppColors.orange;
  }
}

String _shortDate(String value) {
  final date = DateTime.tryParse(value);
  if (date == null) return value;
  final now = DateTime.now();
  final diff = now.difference(date.toLocal());
  if (diff.inMinutes < 1) return 'Just now';
  if (diff.inHours < 1) return '${diff.inMinutes}m ago';
  if (diff.inDays < 1) return '${diff.inHours}h ago';
  return '${date.toLocal().day}/${date.toLocal().month}/${date.toLocal().year}';
}
