import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../core/app_state.dart';
import '../core/app_theme.dart';
import '../core/formatters.dart';
import '../core/youtube_utils.dart';
import '../models/live_session.dart';
import '../widgets/common.dart';
import '../widgets/leaderboard_widgets.dart';
import 'tournament_detail_screen.dart';
import 'youtube_player_screen.dart';

class LiveWatchScreen extends StatefulWidget {
  const LiveWatchScreen({super.key});

  @override
  State<LiveWatchScreen> createState() => _LiveWatchScreenState();
}

class _LiveWatchScreenState extends State<LiveWatchScreen> {
  late Future<LiveSession> _future;

  @override
  void initState() {
    super.initState();
    _future = _load();
  }

  Future<LiveSession> _load() => context.read<AppState>().api.getCurrentLive();

  Future<void> _watchLive(LiveSession live) async {
    // Prefer the API's explicit YouTube URL. Playback URL is accepted as a
    // fallback only when it is also a valid YouTube URL.
    final candidate = YouTubeVideoRef.isYouTubeUrlOrId(live.youtubeUrl)
        ? live.youtubeUrl
        : live.bestWatchUrl;

    if (!YouTubeVideoRef.isYouTubeUrlOrId(candidate)) {
      if (mounted) {
        showAppMessage(
          context,
          'এই live-এর জন্য YouTube link পাওয়া যায়নি। Live Session-এ YouTube URL দিন।',
          error: true,
        );
      }
      return;
    }

    final match = live.match;
    await Navigator.push<void>(
      context,
      MaterialPageRoute<void>(
        builder: (_) => YouTubePlayerScreen(
          title: match?.title ?? live.title,
          youtubeUrl: candidate,
          subtitle: match == null ? 'Tournament live stream' : '${match.mode.toUpperCase()} • Tournament live stream',
          isLive: true,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('Live Match')),
        body: FutureBuilder<LiveSession>(
          future: _future,
          builder: (context, snapshot) {
            if (snapshot.connectionState == ConnectionState.waiting) {
              return const PageLoading(label: 'Live match checking...');
            }
            if (snapshot.hasError) {
              return Padding(
                padding: const EdgeInsets.all(16),
                child: ErrorPanel(
                  message: snapshot.error.toString(),
                  onRetry: () => setState(() => _future = _load()),
                ),
              );
            }
            final live = snapshot.data;
            if (live == null || !live.isLive) {
              return const EmptyState(
                icon: Icons.sensors_off_rounded,
                title: 'এখন কোনো live match নেই',
                message: 'Admin match live করলে এখানে আসল YouTube stream ও live leaderboard দেখা যাবে।',
              );
            }
            final match = live.match;
            return RefreshIndicator(
              color: AppColors.orange,
              onRefresh: () async => setState(() => _future = _load()),
              child: ListView(
                padding: const EdgeInsets.all(16),
                physics: const AlwaysScrollableScrollPhysics(),
                children: <Widget>[
                  Container(
                    height: 218,
                    clipBehavior: Clip.antiAlias,
                    decoration: BoxDecoration(
                      color: AppColors.surface,
                      borderRadius: BorderRadius.circular(24),
                      border: Border.all(color: AppColors.red.withValues(alpha: .65)),
                    ),
                    child: Stack(
                      fit: StackFit.expand,
                      children: <Widget>[
                        if (match?.thumbnailUrl.isNotEmpty == true)
                          Image.network(
                            match!.thumbnailUrl,
                            fit: BoxFit.cover,
                            errorBuilder: (_, __, ___) => const SizedBox.shrink(),
                          ),
                        DecoratedBox(
                          decoration: BoxDecoration(
                            gradient: LinearGradient(
                              begin: Alignment.topCenter,
                              end: Alignment.bottomCenter,
                              colors: <Color>[AppColors.red.withValues(alpha: .12), AppColors.bg.withValues(alpha: .94)],
                            ),
                          ),
                        ),
                        const Positioned(left: 16, top: 16, child: StatusBadge(status: 'LIVE NOW')),
                        const Center(child: Icon(Icons.play_circle_fill_rounded, color: Colors.white, size: 72)),
                        Positioned(
                          left: 18,
                          right: 18,
                          bottom: 17,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: <Widget>[
                              Text(match?.title ?? live.title, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w900)),
                              const SizedBox(height: 3),
                              Text(
                                match == null ? 'Live stream' : conciseDate(match.startAt, match.matchDate, match.matchTime),
                                style: const TextStyle(color: AppColors.muted),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 14),
                  SizedBox(
                    width: double.infinity,
                    child: FilledButton.icon(
                      onPressed: () => _watchLive(live),
                      icon: const Icon(Icons.play_arrow_rounded),
                      label: const Text('WATCH LIVE IN APP'),
                    ),
                  ),
                  if (match != null) ...<Widget>[
                    const SizedBox(height: 22),
                    const SectionHeading(title: 'Live Match Details'),
                    const SizedBox(height: 9),
                    SurfaceBox(
                      child: Row(
                        children: <Widget>[
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: <Widget>[
                                Text('${match.mode.toUpperCase()} • ${match.joined}/${match.slots} players', style: const TextStyle(fontWeight: FontWeight.w900)),
                                const SizedBox(height: 4),
                                Text(
                                  match.prize.isEmpty ? 'Prize এখনো প্রকাশ হয়নি' : match.prize,
                                  style: const TextStyle(color: AppColors.gold, fontWeight: FontWeight.w900),
                                ),
                              ],
                            ),
                          ),
                          OutlinedButton(
                            onPressed: () => Navigator.push(
                              context,
                              MaterialPageRoute<void>(builder: (_) => TournamentDetailScreen(matchId: match.id)),
                            ),
                            child: const Text('VIEW'),
                          ),
                        ],
                      ),
                    ),
                    if (match.leaderboard.isNotEmpty) ...<Widget>[
                      const SizedBox(height: 22),
                      const SectionHeading(title: 'Live Rankings'),
                      const SizedBox(height: 9),
                      LeaderboardList(entries: match.leaderboard),
                    ],
                  ],
                  const SizedBox(height: 15),
                  const Text(
                    'Live stream link ও match data website/plugin থেকে আসে। Video app-এর ভিতরেই YouTube player-এ চলবে।',
                    style: TextStyle(color: AppColors.muted, height: 1.4, fontSize: 11),
                    textAlign: TextAlign.center,
                  ),
                ],
              ),
            );
          },
        ),
      );
}
