import 'package:flutter/material.dart';

import '../core/app_theme.dart';
import 'main_shell.dart';

class LaunchScreen extends StatefulWidget {
  const LaunchScreen({super.key});

  @override
  State<LaunchScreen> createState() => _LaunchScreenState();
}

class _LaunchScreenState extends State<LaunchScreen> {
  @override
  void initState() {
    super.initState();
    Future<void>.delayed(const Duration(milliseconds: 850), () {
      if (mounted) Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (_) => const MainShell()));
    });
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        body: Container(
          width: double.infinity,
          decoration: const BoxDecoration(
            gradient: LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: [Color(0xFF14284A), AppColors.bg, Color(0xFF1D1224)]),
          ),
          child: Center(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  width: 96,
                  height: 96,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(30),
                    gradient: const LinearGradient(colors: [AppColors.orange, AppColors.gold]),
                    boxShadow: [BoxShadow(color: AppColors.orange.withValues(alpha: .35), blurRadius: 30)],
                  ),
                  child: const Icon(Icons.emoji_events_rounded, color: Colors.black, size: 54),
                ),
                const SizedBox(height: 20),
                const Text('FF TOURNAMENT', style: TextStyle(fontSize: 25, fontWeight: FontWeight.w900, letterSpacing: 1.3)),
                const SizedBox(height: 6),
                const Text('PLAY • COMPETE • RANK', style: TextStyle(color: AppColors.orange, fontWeight: FontWeight.w800, letterSpacing: 2, fontSize: 11)),
              ],
            ),
          ),
        ),
      );
}
