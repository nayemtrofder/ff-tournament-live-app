import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../core/app_state.dart';
import '../core/app_theme.dart';
import '../models/live_session.dart';
import '../widgets/common.dart';
import 'youtube_player_screen.dart';

class VideosScreen extends StatefulWidget {
  const VideosScreen({super.key});

  @override
  State<VideosScreen> createState() => _VideosScreenState();
}

class _VideosScreenState extends State<VideosScreen> {
  late Future<List<VideoItem>> _future;

  @override
  void initState() {
    super.initState();
    _future = _load();
  }

  Future<List<VideoItem>> _load() => context.read<AppState>().api.getVideos(scope: 'all');

  Future<void> _open(VideoItem video) async {
    if (video.url.trim().isEmpty) {
      if (mounted) showAppMessage(context, 'এই ভিডিওর YouTube link দেওয়া হয়নি।', error: true);
      return;
    }
    await Navigator.push<void>(
      context,
      MaterialPageRoute<void>(
        builder: (_) => YouTubePlayerScreen(
          title: video.title,
          youtubeUrl: video.url,
          subtitle: video.videoType.isEmpty ? 'Tournament replay / highlight' : video.videoType.toUpperCase(),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('Replays & Highlights')),
        body: FutureBuilder<List<VideoItem>>(
          future: _future,
          builder: (context, snapshot) {
            if (snapshot.connectionState == ConnectionState.waiting) return const PageLoading(label: 'Videos loading...');
            if (snapshot.hasError) return Padding(padding: const EdgeInsets.all(16), child: ErrorPanel(message: snapshot.error.toString(), onRetry: () => setState(() => _future = _load())));
            final videos = snapshot.data ?? const [];
            if (videos.isEmpty) return const EmptyState(icon: Icons.video_library_outlined, title: 'Video নেই', message: 'Dashboard থেকে YouTube video link যোগ করলে এখানে app-এর ভিতরে দেখা যাবে।');
            return ListView.separated(
              padding: const EdgeInsets.all(16),
              itemCount: videos.length,
              separatorBuilder: (_, __) => const SizedBox(height: 10),
              itemBuilder: (_, index) {
                final video = videos[index];
                return InkWell(
                  onTap: () => _open(video),
                  borderRadius: BorderRadius.circular(18),
                  child: SurfaceBox(
                    padding: const EdgeInsets.all(11),
                    child: Row(children: [
                      Container(width: 108, height: 68, clipBehavior: Clip.antiAlias, decoration: BoxDecoration(color: AppColors.surfaceSoft, borderRadius: BorderRadius.circular(13)), child: video.thumbnailUrl.isNotEmpty ? Image.network(video.thumbnailUrl, fit: BoxFit.cover, errorBuilder: (_, __, ___) => const Icon(Icons.play_circle_fill_rounded, color: AppColors.red, size: 38)) : const Icon(Icons.play_circle_fill_rounded, color: AppColors.red, size: 38)),
                      const SizedBox(width: 12),
                      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(video.title, maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w900)), const SizedBox(height: 6), Text(video.videoType.isNotEmpty ? video.videoType.toUpperCase() : 'HIGHLIGHT', style: const TextStyle(color: AppColors.muted, fontSize: 11, fontWeight: FontWeight.w800))])),
                      const Icon(Icons.play_arrow_rounded, color: AppColors.orange),
                    ]),
                  ),
                );
              },
            );
          },
        ),
      );
}
