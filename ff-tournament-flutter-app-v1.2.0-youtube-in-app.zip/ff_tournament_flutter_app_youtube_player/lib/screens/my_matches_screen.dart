import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../core/app_state.dart';
import '../core/app_theme.dart';
import '../models/tournament.dart';
import '../widgets/common.dart';
import '../widgets/tournament_card.dart';
import 'login_screen.dart';
import 'tournament_detail_screen.dart';

class MyMatchesScreen extends StatefulWidget {
  const MyMatchesScreen({super.key});

  @override
  State<MyMatchesScreen> createState() => _MyMatchesScreenState();
}

class _MyMatchesScreenState extends State<MyMatchesScreen> {
  late Future<MyMatchesPayload> _future;

  @override
  void initState() {
    super.initState();
    _future = _loadData();
  }

  Future<MyMatchesPayload> _loadData() {
    final state = context.read<AppState>();
    if (!state.isLoggedIn) return Future<MyMatchesPayload>.value(const MyMatchesPayload(items: <Tournament>[], summary: <String, int>{}));
    return state.api.getMyMatches();
  }

  void _reload() => setState(() => _future = _loadData());

  @override
  Widget build(BuildContext context) {
    final loggedIn = context.watch<AppState>().isLoggedIn;
    if (!loggedIn) {
      return Center(child: EmptyState(icon: Icons.lock_outline_rounded, title: 'Login to see your matches', message: 'আপনি যে tournament-এ join করেছেন সেগুলো এখানে থাকবে।', action: FilledButton.icon(onPressed: () async { await Navigator.push(context, MaterialPageRoute<bool>(builder: (_) => const LoginScreen())); if (mounted) _reload(); }, icon: const Icon(Icons.login_rounded), label: const Text('LOGIN'))));
    }
    return FutureBuilder<MyMatchesPayload>(
      future: _future,
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) return const PageLoading(label: 'Your matches loading...');
        if (snapshot.hasError) return Padding(padding: const EdgeInsets.all(16), child: ErrorPanel(message: snapshot.error.toString(), onRetry: _reload));
        final payload = snapshot.data ?? const MyMatchesPayload(items: <Tournament>[], summary: <String, int>{});
        final matches = payload.items;
        return RefreshIndicator(
          color: AppColors.orange,
          onRefresh: () async => _reload(),
          child: ListView(
            padding: const EdgeInsets.fromLTRB(16, 16, 16, 28),
            physics: const AlwaysScrollableScrollPhysics(),
            children: <Widget>[
              Row(children: <Widget>[const Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: <Widget>[Text('My Matches', style: TextStyle(fontSize: 24, fontWeight: FontWeight.w900)), SizedBox(height: 3), Text('Your joined tournaments and room access', style: TextStyle(color: AppColors.muted))])), IconButton(onPressed: _reload, icon: const Icon(Icons.refresh_rounded))]),
              const SizedBox(height: 16),
              _Summary(summary: payload.summary),
              const SizedBox(height: 18),
              if (matches.isEmpty)
                const EmptyState(icon: Icons.calendar_month_outlined, title: 'No joined tournament yet', message: 'Tournament page থেকে আপনার পছন্দের match-এ Join Now চাপুন।')
              else ...<Widget>[
                _Group(title: 'LIVE NOW', items: matches.where((item) => item.isLive).toList(), onReload: _reload),
                _Group(title: 'UPCOMING', items: matches.where((item) => item.isUpcoming).toList(), onReload: _reload),
                _Group(title: 'COMPLETED', items: matches.where((item) => item.isEnded).toList(), onReload: _reload),
                _Group(title: 'CANCELLED', items: matches.where((item) => item.isCancelled).toList(), onReload: _reload),
              ],
            ],
          ),
        );
      },
    );
  }
}

class _Summary extends StatelessWidget {
  const _Summary({required this.summary});
  final Map<String, int> summary;

  @override
  Widget build(BuildContext context) => SurfaceBox(
        padding: const EdgeInsets.symmetric(vertical: 13, horizontal: 10),
        child: Row(children: <Widget>[
          Expanded(child: _Count(label: 'LIVE', value: summary['live'] ?? 0, color: AppColors.red)),
          Expanded(child: _Count(label: 'UPCOMING', value: summary['upcoming'] ?? 0, color: AppColors.orange)),
          Expanded(child: _Count(label: 'COMPLETED', value: summary['ended'] ?? 0, color: AppColors.green)),
        ]),
      );
}

class _Count extends StatelessWidget {
  const _Count({required this.label, required this.value, required this.color});
  final String label;
  final int value;
  final Color color;

  @override
  Widget build(BuildContext context) => Column(children: <Widget>[Text('$value', style: TextStyle(color: color, fontSize: 21, fontWeight: FontWeight.w900)), const SizedBox(height: 3), Text(label, style: const TextStyle(color: AppColors.muted, fontSize: 9, fontWeight: FontWeight.w900))]);
}

class _Group extends StatelessWidget {
  const _Group({required this.title, required this.items, required this.onReload});
  final String title;
  final List<Tournament> items;
  final VoidCallback onReload;

  @override
  Widget build(BuildContext context) {
    if (items.isEmpty) return const SizedBox.shrink();
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        Padding(padding: const EdgeInsets.only(bottom: 10, top: 4), child: Text(title, style: const TextStyle(color: AppColors.orange, fontSize: 11, fontWeight: FontWeight.w900, letterSpacing: 1.1))),
        ...items.map((item) => Padding(padding: const EdgeInsets.only(bottom: 12), child: TournamentCard(tournament: item, onTap: () => Navigator.push(context, MaterialPageRoute<void>(builder: (_) => TournamentDetailScreen(matchId: item.id))).then((_) => onReload())))),
      ],
    );
  }
}
