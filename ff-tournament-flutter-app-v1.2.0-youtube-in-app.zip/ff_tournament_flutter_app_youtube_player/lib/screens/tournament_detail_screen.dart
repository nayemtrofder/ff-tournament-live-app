import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../core/api_client.dart';
import '../core/app_state.dart';
import '../core/app_theme.dart';
import '../core/formatters.dart';
import '../models/tournament.dart';
import '../widgets/common.dart';
import '../widgets/leaderboard_widgets.dart';
import 'login_screen.dart';

class TournamentDetailScreen extends StatefulWidget {
  const TournamentDetailScreen({super.key, required this.matchId});
  final int matchId;

  @override
  State<TournamentDetailScreen> createState() => _TournamentDetailScreenState();
}

class _TournamentDetailScreenState extends State<TournamentDetailScreen> {
  late Future<Tournament> _future;
  bool _joining = false;

  @override
  void initState() {
    super.initState();
    _future = _loadData();
  }

  Future<Tournament> _loadData() => context.read<AppState>().api.getTournament(widget.matchId);

  void _reload() => setState(() => _future = _loadData());

  Future<void> _join(Tournament tournament) async {
    final state = context.read<AppState>();
    if (!state.isLoggedIn) {
      await Navigator.push(context, MaterialPageRoute<bool>(builder: (_) => const LoginScreen()));
      if (mounted) _reload();
      return;
    }
    setState(() => _joining = true);
    try {
      final result = await state.api.joinTournament(tournament.id);
      await state.refreshProfile();
      if (!mounted) return;
      showAppMessage(context, (result['message'] ?? 'Tournament joined successfully.').toString());
      _reload();
    } on ApiException catch (error) {
      if (mounted) showAppMessage(context, error.message, error: true);
    } finally {
      if (mounted) setState(() => _joining = false);
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('Tournament Details')),
        body: FutureBuilder<Tournament>(
          future: _future,
          builder: (context, snapshot) {
            if (snapshot.connectionState == ConnectionState.waiting) return const PageLoading(label: 'Tournament details loading...');
            if (snapshot.hasError) return Padding(padding: const EdgeInsets.all(16), child: ErrorPanel(message: snapshot.error.toString(), onRetry: _reload));
            final tournament = snapshot.data;
            if (tournament == null) return Padding(padding: const EdgeInsets.all(16), child: ErrorPanel(message: 'Tournament data পাওয়া যায়নি।', onRetry: _reload));
            final hasRoom = tournament.roomId.isNotEmpty || tournament.roomPassword.isNotEmpty;
            return RefreshIndicator(
              color: AppColors.orange,
              onRefresh: () async => _reload(),
              child: ListView(
                padding: const EdgeInsets.fromLTRB(16, 14, 16, 30),
                physics: const AlwaysScrollableScrollPhysics(),
                children: <Widget>[
                  _Banner(tournament: tournament),
                  const SizedBox(height: 16),
                  SurfaceBox(
                    child: Row(
                      children: <Widget>[
                        Expanded(child: _InfoCell(label: 'MODE', value: tournament.mode.toUpperCase())),
                        Container(width: 1, height: 42, color: AppColors.border),
                        Expanded(child: _InfoCell(label: 'SLOTS', value: '${tournament.joined}/${tournament.slots}')),
                        Container(width: 1, height: 42, color: AppColors.border),
                        Expanded(child: _InfoCell(label: 'ENTRY', value: '${tournament.entryGold.toStringAsFixed(0)} Gold')),
                      ],
                    ),
                  ),
                  const SizedBox(height: 16),
                  const SectionHeading(title: 'Match Information'),
                  const SizedBox(height: 9),
                  SurfaceBox(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        _DetailRow(icon: Icons.calendar_today_rounded, label: 'Schedule', value: conciseDate(tournament.startAt, tournament.matchDate, tournament.matchTime)),
                        const Divider(height: 20),
                        _DetailRow(icon: Icons.workspace_premium_rounded, label: 'Prize', value: tournament.prize.isEmpty ? 'Not published' : tournament.prize, valueColor: AppColors.gold),
                        const Divider(height: 20),
                        _DetailRow(icon: Icons.group_outlined, label: 'Slots Left', value: '${tournament.slotsLeft}'),
                      ],
                    ),
                  ),
                  if (tournament.description.isNotEmpty || tournament.rules.isNotEmpty) ...<Widget>[
                    const SizedBox(height: 22),
                    const SectionHeading(title: 'Rules'),
                    const SizedBox(height: 9),
                    SurfaceBox(child: Text(tournament.rules.isNotEmpty ? tournament.rules : tournament.description, style: const TextStyle(color: AppColors.muted, height: 1.55))),
                  ],
                  if (hasRoom) ...<Widget>[
                    const SizedBox(height: 22),
                    const SectionHeading(title: 'Room Details'),
                    const SizedBox(height: 9),
                    SurfaceBox(
                      color: AppColors.cyan.withValues(alpha: .08),
                      borderColor: AppColors.cyan.withValues(alpha: .35),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget>[
                          const Text('Joined player room access', style: TextStyle(fontWeight: FontWeight.w900)),
                          const SizedBox(height: 12),
                          _DetailRow(icon: Icons.meeting_room_outlined, label: 'Room ID', value: tournament.roomId.isEmpty ? 'TBA' : tournament.roomId, valueColor: AppColors.cyan),
                          const Divider(height: 20),
                          _DetailRow(icon: Icons.key_outlined, label: 'Password', value: tournament.roomPassword.isEmpty ? 'TBA' : tournament.roomPassword, valueColor: AppColors.cyan),
                        ],
                      ),
                    ),
                  ],
                  if (tournament.isEnded && (tournament.myPlacement > 0 || tournament.myKills > 0 || tournament.myPoints > 0)) ...<Widget>[
                    const SizedBox(height: 22),
                    const SectionHeading(title: 'Your Result'),
                    const SizedBox(height: 9),
                    SurfaceBox(child: Row(children: <Widget>[Expanded(child: _InfoCell(label: 'RANK', value: tournament.myPlacement > 0 ? '#${tournament.myPlacement}' : '—')), Expanded(child: _InfoCell(label: 'KILLS', value: '${tournament.myKills}')), Expanded(child: _InfoCell(label: 'POINTS', value: tournament.myPoints.toStringAsFixed(0)))])),
                  ],
                  if (tournament.leaderboard.isNotEmpty) ...<Widget>[
                    const SizedBox(height: 22),
                    const SectionHeading(title: 'Leaderboard'),
                    const SizedBox(height: 9),
                    LeaderboardList(entries: tournament.leaderboard),
                  ],
                  const SizedBox(height: 24),
                  if (tournament.isJoined)
                    const SurfaceBox(
                      color: Color(0x1527C96F),
                      borderColor: AppColors.green,
                      child: Row(children: <Widget>[Icon(Icons.check_circle_rounded, color: AppColors.green), SizedBox(width: 10), Expanded(child: Text('You have joined this tournament.', style: TextStyle(fontWeight: FontWeight.w900)))]),
                    )
                  else if (tournament.canJoin)
                    SizedBox(
                      width: double.infinity,
                      child: FilledButton.icon(
                        onPressed: _joining ? null : () => _join(tournament),
                        icon: _joining ? const SizedBox.square(dimension: 18, child: CircularProgressIndicator(color: Colors.black, strokeWidth: 2)) : const Icon(Icons.add_circle_rounded),
                        label: Text(_joining ? 'JOINING...' : 'JOIN FOR ${tournament.entryGold.toStringAsFixed(0)} GOLD'),
                      ),
                    )
                  else
                    SurfaceBox(
                      color: AppColors.surfaceSoft,
                      child: Text(
                        tournament.isUpcoming ? 'এই tournament এখন join করা যাচ্ছে না। Slot full অথবা registration বন্ধ।' : 'এই tournament-এর registration শেষ হয়েছে।',
                        style: const TextStyle(color: AppColors.muted),
                      ),
                    ),
                ],
              ),
            );
          },
        ),
      );
}

class _Banner extends StatelessWidget {
  const _Banner({required this.tournament});
  final Tournament tournament;

  @override
  Widget build(BuildContext context) => Container(
        height: 195,
        clipBehavior: Clip.antiAlias,
        decoration: BoxDecoration(color: AppColors.surface, borderRadius: BorderRadius.circular(25), border: Border.all(color: AppColors.orange.withValues(alpha: .42))),
        child: Stack(
          fit: StackFit.expand,
          children: <Widget>[
            if (tournament.thumbnailUrl.isNotEmpty) Image.network(tournament.thumbnailUrl, fit: BoxFit.cover, errorBuilder: (_, __, ___) => const SizedBox.shrink()),
            DecoratedBox(decoration: BoxDecoration(gradient: LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: <Color>[AppColors.orange.withValues(alpha: .40), AppColors.surface.withValues(alpha: .76), AppColors.bg]))),
            Padding(
              padding: const EdgeInsets.all(18),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  StatusBadge(status: tournament.statusLabel),
                  const Spacer(),
                  Text(tournament.title, maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 25, fontWeight: FontWeight.w900, height: 1.03)),
                  const SizedBox(height: 6),
                  Text('${tournament.mode.toUpperCase()} • ${conciseDate(tournament.startAt, tournament.matchDate, tournament.matchTime)}', style: const TextStyle(color: AppColors.muted, fontWeight: FontWeight.w700)),
                ],
              ),
            ),
          ],
        ),
      );
}

class _InfoCell extends StatelessWidget {
  const _InfoCell({required this.label, required this.value});
  final String label;
  final String value;

  @override
  Widget build(BuildContext context) => Column(children: <Widget>[Text(label, style: const TextStyle(color: AppColors.muted, fontSize: 10, fontWeight: FontWeight.w900, letterSpacing: .7)), const SizedBox(height: 6), Text(value, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 13))]);
}

class _DetailRow extends StatelessWidget {
  const _DetailRow({required this.icon, required this.label, required this.value, this.valueColor});
  final IconData icon;
  final String label;
  final String value;
  final Color? valueColor;

  @override
  Widget build(BuildContext context) => Row(children: <Widget>[Icon(icon, color: AppColors.muted, size: 19), const SizedBox(width: 10), Expanded(child: Text(label, style: const TextStyle(fontWeight: FontWeight.w800))), Flexible(child: Text(value, textAlign: TextAlign.right, style: TextStyle(fontWeight: FontWeight.w900, color: valueColor ?? Colors.white)))]);
}
