import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../core/api_client.dart';
import '../core/app_state.dart';
import '../core/app_theme.dart';
import '../models/live_session.dart';
import '../models/tournament.dart';
import '../widgets/common.dart';
import '../widgets/hero_carousel.dart';
import '../widgets/leaderboard_widgets.dart';
import '../widgets/tournament_card.dart';
import 'live_watch_screen.dart';
import 'login_screen.dart';
import 'notifications_screen.dart';
import 'tournament_detail_screen.dart';
import 'videos_screen.dart';
import 'youtube_player_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  late Future<HomePayload> _future;

  @override
  void initState() {
    super.initState();
    _future = _loadData();
  }

  Future<HomePayload> _loadData() async {
    final data = await context.read<AppState>().api.getHome();
    if (mounted) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (mounted) context.read<AppState>().setUnreadNotifications(data.unreadNotifications);
      });
    }
    return data;
  }

  void _reload() => setState(() => _future = _loadData());

  Future<void> _openVideo(VideoItem video) async {
    if (video.url.trim().isEmpty) {
      if (mounted) showAppMessage(context, 'এই ভিডিওর YouTube link দেওয়া হয়নি।', error: true);
      return;
    }
    await Navigator.push<void>(
      context,
      MaterialPageRoute<void>(
        builder: (_) => YouTubePlayerScreen(
          title: video.title,
          youtubeUrl: video.url,
          subtitle: video.videoType.isEmpty ? 'Tournament replay / highlight' : video.videoType.toUpperCase(),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();
    return RefreshIndicator(
      color: AppColors.orange,
      onRefresh: () async => _reload(),
      child: ListView(
        padding: const EdgeInsets.fromLTRB(16, 14, 16, 28),
        physics: const AlwaysScrollableScrollPhysics(),
        children: <Widget>[
          _Header(
            onProfileTap: () {
              if (!state.isLoggedIn) {
                Navigator.push(context, MaterialPageRoute<bool>(builder: (_) => const LoginScreen())).then((_) => _reload());
              }
            },
            onNotificationTap: () => Navigator.push(context, MaterialPageRoute<void>(builder: (_) => const NotificationsScreen())).then((_) => _reload()),
          ),
          const SizedBox(height: 18),
          FutureBuilder<HomePayload>(
            future: _future,
            builder: (context, snapshot) {
              if (snapshot.connectionState == ConnectionState.waiting) return const PageLoading(label: 'Home data loading...');
              if (snapshot.hasError) return ErrorPanel(message: snapshot.error.toString(), onRetry: _reload);
              final data = snapshot.data;
              if (data == null) return ErrorPanel(message: 'Home data পাওয়া যায়নি।', onRetry: _reload);
              return _HomeBody(
                data: data,
                onTournamentTap: (tournament) => Navigator.push(context, MaterialPageRoute<void>(builder: (_) => TournamentDetailScreen(matchId: tournament.id))).then((_) => _reload()),
                onLiveTap: (live) => Navigator.push(context, MaterialPageRoute<void>(builder: (_) => const LiveWatchScreen())).then((_) => _reload()),
                onVideoTap: _openVideo,
              );
            },
          ),
        ],
      ),
    );
  }
}

class _Header extends StatelessWidget {
  const _Header({required this.onProfileTap, required this.onNotificationTap});
  final VoidCallback onProfileTap;
  final VoidCallback onNotificationTap;

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();
    final user = state.user;
    final unread = state.unreadNotifications;
    return Row(
      children: <Widget>[
        Container(
          width: 42,
          height: 42,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(13),
            gradient: const LinearGradient(colors: <Color>[AppColors.orange, AppColors.gold]),
          ),
          child: const Icon(Icons.emoji_events_rounded, color: Colors.black),
        ),
        const SizedBox(width: 10),
        const Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Text('FF TOURNAMENT', style: TextStyle(fontSize: 17, fontWeight: FontWeight.w900, letterSpacing: .4)),
              Text('PLAY • COMPETE • RANK', style: TextStyle(fontSize: 9, color: AppColors.orange, fontWeight: FontWeight.w900, letterSpacing: 1.2)),
            ],
          ),
        ),
        IconButton(
          onPressed: onNotificationTap,
          icon: Badge(
            isLabelVisible: unread > 0,
            label: Text(unread > 99 ? '99+' : '$unread'),
            child: const Icon(Icons.notifications_none_rounded),
          ),
        ),
        GestureDetector(
          onTap: onProfileTap,
          child: user == null
              ? Container(
                  width: 38,
                  height: 38,
                  alignment: Alignment.center,
                  decoration: BoxDecoration(color: AppColors.surface, shape: BoxShape.circle, border: Border.all(color: AppColors.border)),
                  child: const Icon(Icons.login_rounded, color: AppColors.orange, size: 20),
                )
              : NetworkAvatar(url: user.avatarUrl, name: user.displayName, radius: 19),
        ),
      ],
    );
  }
}

class _HomeBody extends StatelessWidget {
  const _HomeBody({required this.data, required this.onTournamentTap, required this.onLiveTap, required this.onVideoTap});
  final HomePayload data;
  final ValueChanged<Tournament> onTournamentTap;
  final ValueChanged<LiveSession> onLiveTap;
  final ValueChanged<VideoItem> onVideoTap;

  @override
  Widget build(BuildContext context) {
    final slides = <HeroSlideData>[];
    final live = data.live;
    if (live != null && live.isLive) slides.add(HeroSlideData.live(live, () => onLiveTap(live)));
    slides.addAll(data.upcoming.take(4).map((tournament) => HeroSlideData.tournament(tournament, () => onTournamentTap(tournament))));
    if (slides.length < 5 && data.videos.isNotEmpty) {
      final video = data.videos.first;
      slides.add(HeroSlideData(
        title: video.title,
        subtitle: 'Latest tournament highlight',
        status: 'HIGHLIGHT',
        prize: video.videoType.isEmpty ? 'WATCH VIDEO' : video.videoType.toUpperCase(),
        icon: Icons.play_circle_fill_rounded,
        accent: AppColors.cyan,
        buttonLabel: 'WATCH',
        thumbnailUrl: video.thumbnailUrl,
        onTap: () => onVideoTap(video),
      ));
    }

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        if (slides.isEmpty)
          const SurfaceBox(
            child: EmptyState(
              icon: Icons.emoji_events_outlined,
              title: 'No active tournament yet',
              message: 'Admin live বা upcoming tournament publish করলে এখানে real slider দেখা যাবে।',
            ),
          )
        else
          HeroCarousel(items: slides),
        const SizedBox(height: 23),
        if (data.viewer != null) ...<Widget>[
          SurfaceBox(
            color: AppColors.gold.withValues(alpha: .09),
            borderColor: AppColors.gold.withValues(alpha: .38),
            child: Row(
              children: <Widget>[
                NetworkAvatar(url: data.viewer!.avatarUrl, name: data.viewer!.displayName, radius: 22),
                const SizedBox(width: 10),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Text('Welcome back, ${data.viewer!.displayName}', style: const TextStyle(fontWeight: FontWeight.w900)),
                      const SizedBox(height: 3),
                      const Text('Your current balance', style: TextStyle(color: AppColors.muted, fontSize: 12)),
                    ],
                  ),
                ),
                GoldPill(value: '${data.viewer!.gold.toStringAsFixed(0)} Gold'),
              ],
            ),
          ),
          const SizedBox(height: 22),
        ],
        const SectionHeading(title: 'Live Leaderboard'),
        if (data.leaderboardPreview.isEmpty)
          const EmptyState(icon: Icons.leaderboard_outlined, title: 'Leaderboard অপেক্ষায় আছে', message: 'Live match বা result publish হলে real ranking এখানে দেখা যাবে।')
        else ...<Widget>[
          LeaderboardList(entries: data.leaderboardPreview, limit: 5),
          const SizedBox(height: 23),
        ],
        const SectionHeading(title: 'Upcoming Tournaments'),
        const SizedBox(height: 10),
        if (data.upcoming.isEmpty)
          const EmptyState(icon: Icons.event_busy_rounded, title: 'Upcoming match নেই', message: 'Admin নতুন tournament publish করলে এখানে আসবে।')
        else
          SizedBox(
            height: 185,
            child: ListView.separated(
              scrollDirection: Axis.horizontal,
              itemCount: data.upcoming.length,
              separatorBuilder: (_, __) => const SizedBox(width: 12),
              itemBuilder: (_, index) => SizedBox(width: 285, child: TournamentCard(tournament: data.upcoming[index], onTap: () => onTournamentTap(data.upcoming[index]))),
            ),
          ),
        const SizedBox(height: 24),
        SectionHeading(
          title: 'Today’s Highlights',
          actionLabel: data.videos.isNotEmpty ? 'SEE ALL' : null,
          onAction: data.videos.isNotEmpty ? () => Navigator.push(context, MaterialPageRoute<void>(builder: (_) => const VideosScreen())) : null,
        ),
        const SizedBox(height: 10),
        if (data.videos.isEmpty)
          const EmptyState(icon: Icons.movie_outlined, title: 'No highlight today', message: 'Admin App Videos panel থেকে video যোগ করলে এখানে real replay/highlight আসবে।')
        else
          ...data.videos.take(3).map(
                (video) => Padding(
                  padding: const EdgeInsets.only(bottom: 10),
                  child: InkWell(
                    onTap: () => onVideoTap(video),
                    borderRadius: BorderRadius.circular(18),
                    child: SurfaceBox(
                      padding: EdgeInsets.zero,
                      child: Row(
                        children: <Widget>[
                          Container(
                            width: 88,
                            height: 64,
                            clipBehavior: Clip.antiAlias,
                            decoration: BoxDecoration(color: AppColors.surfaceSoft, borderRadius: BorderRadius.circular(17)),
                            child: video.thumbnailUrl.isEmpty
                                ? const Icon(Icons.play_circle_fill_rounded, color: AppColors.cyan, size: 32)
                                : Image.network(video.thumbnailUrl, fit: BoxFit.cover, errorBuilder: (_, __, ___) => const Icon(Icons.play_circle_fill_rounded, color: AppColors.cyan, size: 32)),
                          ),
                          const SizedBox(width: 12),
                          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: <Widget>[Text(video.title, maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w900)), const SizedBox(height: 4), Text(video.videoType.isEmpty ? 'Tournament video' : video.videoType.toUpperCase(), style: const TextStyle(color: AppColors.muted, fontSize: 11))])),
                          const Padding(padding: EdgeInsets.only(right: 12), child: Icon(Icons.play_arrow_rounded, color: AppColors.orange)),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
      ],
    );
  }
}
