import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:youtube_player_iframe/youtube_player_iframe.dart';

import '../core/app_theme.dart';
import '../core/youtube_utils.dart';
import '../widgets/common.dart';

/// One real, in-app player used by both live matches and replay/highlight videos.
/// The URL always comes from the WordPress API; no local video/demo data is used.
class YouTubePlayerScreen extends StatefulWidget {
  const YouTubePlayerScreen({
    super.key,
    required this.title,
    required this.youtubeUrl,
    this.subtitle = '',
    this.isLive = false,
  });

  final String title;
  final String youtubeUrl;
  final String subtitle;
  final bool isLive;

  @override
  State<YouTubePlayerScreen> createState() => _YouTubePlayerScreenState();
}

class _YouTubePlayerScreenState extends State<YouTubePlayerScreen> {
  YoutubePlayerController? _controller;
  String? _error;

  @override
  void initState() {
    super.initState();
    final ref = YouTubeVideoRef.tryParse(widget.youtubeUrl);
    if (ref == null) {
      _error = 'এই stream/video-র জন্য valid YouTube link পাওয়া যায়নি। Admin panel-এ YouTube watch link বা video ID দিন।';
      return;
    }

    _controller = YoutubePlayerController.fromVideoId(
      videoId: ref.videoId,
      autoPlay: true,
      params: const YoutubePlayerParams(
        showControls: true,
        showFullscreenButton: true,
        privacyEnhancedMode: true,
        strictRelatedVideos: true,
        playsInline: true,
      ),
    );
  }

  @override
  void dispose() {
    _controller?.close();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: Text(widget.isLive ? 'Watch Live' : 'Watch Video')),
        body: _error != null
            ? Padding(
                padding: const EdgeInsets.all(16),
                child: ErrorPanel(message: _error!),
              )
            : ListView(
                padding: const EdgeInsets.fromLTRB(16, 14, 16, 28),
                children: <Widget>[
                  ClipRRect(
                    borderRadius: BorderRadius.circular(20),
                    child: LayoutBuilder(
                      builder: (context, constraints) {
                        final playerHeight = math.max(constraints.maxWidth * 9 / 16, 200.0).toDouble();
                        return SizedBox(
                          height: playerHeight,
                          child: YoutubePlayer(controller: _controller!),
                        );
                      },
                    ),
                  ),
                  const SizedBox(height: 16),
                  if (widget.isLive)
                    const Align(
                      alignment: Alignment.centerLeft,
                      child: StatusBadge(status: 'LIVE NOW'),
                    ),
                  if (widget.isLive) const SizedBox(height: 9),
                  Text(widget.title, style: const TextStyle(fontSize: 21, fontWeight: FontWeight.w900, height: 1.18)),
                  if (widget.subtitle.trim().isNotEmpty) ...<Widget>[
                    const SizedBox(height: 6),
                    Text(widget.subtitle, style: const TextStyle(color: AppColors.muted, height: 1.4)),
                  ],
                  const SizedBox(height: 18),
                  const SurfaceBox(
                    child: Row(
                      children: <Widget>[
                        Icon(Icons.ondemand_video_rounded, color: AppColors.red),
                        SizedBox(width: 10),
                        Expanded(
                          child: Text(
                            'Video YouTube থেকে app-এর ভিতরেই চলছে। Fullscreen ও YouTube-এর নিজের player controls ব্যবহার করা যাবে।',
                            style: TextStyle(color: AppColors.muted, height: 1.35, fontSize: 12),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
      );
}
