import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../core/api_client.dart';
import '../core/app_state.dart';
import '../core/app_theme.dart';
import '../widgets/common.dart';

class HostLiveScreen extends StatefulWidget {
  const HostLiveScreen({super.key});

  @override
  State<HostLiveScreen> createState() => _HostLiveScreenState();
}

class _HostLiveScreenState extends State<HostLiveScreen> {
  final _liveId = TextEditingController();
  HostSession? _session;
  bool _loading = false;

  @override
  void dispose() {
    _liveId.dispose();
    super.dispose();
  }

  Future<void> _verify() async {
    if (_liveId.text.trim().isEmpty) {
      showAppMessage(context, 'Live ID লিখুন।', error: true);
      return;
    }
    setState(() => _loading = true);
    try {
      final result = await context.read<AppState>().api.verifyLive(_liveId.text.trim());
      if (mounted) setState(() => _session = result);
    } on ApiException catch (error) {
      if (mounted) showAppMessage(context, error.message, error: true);
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  Future<void> _action(bool start) async {
    final session = _session;
    if (session == null) return;
    setState(() => _loading = true);
    try {
      final updated = start
          ? await context.read<AppState>().api.startLive(sessionId: session.sessionId, liveId: session.liveId)
          : await context.read<AppState>().api.endLive(sessionId: session.sessionId, liveId: session.liveId);
      if (!mounted) return;
      setState(() => _session = updated);
      showAppMessage(context, start ? 'Live status started.' : 'Live status ended.');
    } on ApiException catch (error) {
      if (mounted) showAppMessage(context, error.message, error: true);
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('Host Live Control')),
        body: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            SurfaceBox(
              color: AppColors.red.withValues(alpha: .08),
              borderColor: AppColors.red.withValues(alpha: .42),
              child: const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Row(children: [Icon(Icons.sensors_rounded, color: AppColors.red), SizedBox(width: 8), Text('Private host panel', style: TextStyle(fontWeight: FontWeight.w900))]),
                SizedBox(height: 8),
                Text('এই panel শুধু assigned FF Stream Host বা Administrator-এর জন্য।', style: TextStyle(color: AppColors.muted, height: 1.4)),
              ]),
            ),
            const SizedBox(height: 20),
            TextField(controller: _liveId, textCapitalization: TextCapitalization.characters, decoration: const InputDecoration(labelText: 'Live ID', hintText: 'Example: FFTS-LIVE-ABC123', prefixIcon: Icon(Icons.key_rounded))),
            const SizedBox(height: 12),
            FilledButton.icon(onPressed: _loading ? null : _verify, icon: _loading ? const SizedBox.square(dimension: 18, child: CircularProgressIndicator(color: Colors.black, strokeWidth: 2)) : const Icon(Icons.verified_rounded), label: const Text('VERIFY LIVE ID')),
            if (_session != null) ...[
              const SizedBox(height: 22),
              _SessionCard(session: _session!),
              const SizedBox(height: 14),
              Row(children: [
                Expanded(child: OutlinedButton.icon(onPressed: _loading || _session!.status == 'live' ? null : () => _action(true), icon: const Icon(Icons.play_arrow_rounded), label: const Text('START LIVE'))),
                const SizedBox(width: 10),
                Expanded(child: FilledButton.icon(style: FilledButton.styleFrom(backgroundColor: AppColors.red, foregroundColor: Colors.white), onPressed: _loading || _session!.status == 'ended' ? null : () => _action(false), icon: const Icon(Icons.stop_circle_rounded), label: const Text('END LIVE'))),
              ]),
            ],
            const SizedBox(height: 25),
            const SurfaceBox(color: AppColors.surfaceSoft, child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('Important', style: TextStyle(fontWeight: FontWeight.w900)), SizedBox(height: 7), Text('এই app API live verify/start/end করে। কিন্তু ফোন screen broadcast করতে real streaming gateway/SDK connect থাকতে হবে। Playback URL website dashboard থেকে configured না থাকলে API intentionally live start করবে না।', style: TextStyle(color: AppColors.muted, height: 1.5))])),
          ],
        ),
      );
}

class _SessionCard extends StatelessWidget {
  const _SessionCard({required this.session});
  final HostSession session;
  @override
  Widget build(BuildContext context) => SurfaceBox(
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [const Icon(Icons.live_tv_rounded, color: AppColors.cyan), const SizedBox(width: 8), Expanded(child: Text(session.matchTitle.isEmpty ? 'Assigned match' : session.matchTitle, style: const TextStyle(fontWeight: FontWeight.w900))), StatusBadge(status: session.status)]),
          const SizedBox(height: 15),
          _Line(label: 'LIVE ID', value: session.liveId),
          const SizedBox(height: 8),
          _Line(label: 'SESSION', value: '#${session.sessionId}'),
          const SizedBox(height: 8),
          _Line(label: 'APP LIVE', value: session.appEnabled ? 'Enabled' : 'Disabled'),
          const SizedBox(height: 8),
          _Line(label: 'PLAYBACK', value: session.playbackUrl.isEmpty ? 'Not configured' : 'Configured'),
        ]),
      );
}

class _Line extends StatelessWidget {
  const _Line({required this.label, required this.value});
  final String label;
  final String value;
  @override
  Widget build(BuildContext context) => Row(children: [SizedBox(width: 88, child: Text(label, style: const TextStyle(color: AppColors.muted, fontSize: 11, fontWeight: FontWeight.w900))), Expanded(child: Text(value, style: const TextStyle(fontWeight: FontWeight.w800), overflow: TextOverflow.ellipsis))]);
}
