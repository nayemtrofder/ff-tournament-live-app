import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../core/app_state.dart';
import '../core/app_theme.dart';
import '../models/tournament.dart';
import '../widgets/common.dart';
import '../widgets/tournament_card.dart';
import 'tournament_detail_screen.dart';

class TournamentsScreen extends StatefulWidget {
  const TournamentsScreen({super.key});

  @override
  State<TournamentsScreen> createState() => _TournamentsScreenState();
}

class _TournamentsScreenState extends State<TournamentsScreen> {
  String _status = 'upcoming';
  late Future<List<Tournament>> _future;

  @override
  void initState() {
    super.initState();
    _future = _loadData();
  }

  Future<List<Tournament>> _loadData() => context.read<AppState>().api.getTournaments(status: _status);

  void _reload() => setState(() => _future = _loadData());

  @override
  Widget build(BuildContext context) => FutureBuilder<List<Tournament>>(
        future: _future,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) return const PageLoading(label: 'Tournaments loading...');
          if (snapshot.hasError) return Padding(padding: const EdgeInsets.all(16), child: ErrorPanel(message: snapshot.error.toString(), onRetry: _reload));
          final items = snapshot.data ?? const <Tournament>[];
          return RefreshIndicator(
            color: AppColors.orange,
            onRefresh: () async => _reload(),
            child: ListView(
              padding: const EdgeInsets.fromLTRB(16, 16, 16, 28),
              physics: const AlwaysScrollableScrollPhysics(),
              children: <Widget>[
                const Text('Tournaments', style: TextStyle(fontSize: 24, fontWeight: FontWeight.w900)),
                const SizedBox(height: 4),
                const Text('Choose a match and compete for rank.', style: TextStyle(color: AppColors.muted)),
                const SizedBox(height: 17),
                Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: <Widget>[
                    for (final option in const <MapEntry<String, String>>[
                      MapEntry<String, String>('upcoming', 'UPCOMING'),
                      MapEntry<String, String>('live', 'LIVE'),
                      MapEntry<String, String>('ended', 'COMPLETED'),
                    ])
                      ChoiceChip(
                        label: Text(option.value),
                        selected: _status == option.key,
                        onSelected: (_) {
                          setState(() => _status = option.key);
                          _reload();
                        },
                      ),
                  ],
                ),
                const SizedBox(height: 18),
                if (items.isEmpty)
                  EmptyState(
                    icon: Icons.emoji_events_outlined,
                    title: _status == 'upcoming' ? 'No upcoming tournament' : 'No ${_status == 'live' ? 'live' : 'completed'} tournament',
                    message: 'Website admin real tournament publish করলে list এখানে automatically update হবে।',
                  )
                else
                  ...items.map(
                    (item) => Padding(
                      padding: const EdgeInsets.only(bottom: 12),
                      child: TournamentCard(
                        tournament: item,
                        onTap: () => Navigator.push(context, MaterialPageRoute<void>(builder: (_) => TournamentDetailScreen(matchId: item.id))).then((_) => _reload()),
                      ),
                    ),
                  ),
              ],
            ),
          );
        },
      );
}
