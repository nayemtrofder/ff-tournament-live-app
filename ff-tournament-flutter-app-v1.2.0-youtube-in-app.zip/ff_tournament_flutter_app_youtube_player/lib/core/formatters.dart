String goldText(num value) {
  final number = value % 1 == 0 ? value.toInt().toString() : value.toStringAsFixed(1);
  return '$number Gold';
}

String conciseDate(String isoOrDate, String fallbackDate, String fallbackTime) {
  if (isoOrDate.isNotEmpty) {
    final date = DateTime.tryParse(isoOrDate);
    if (date != null) {
      final local = date.toLocal();
      const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
      final hour = local.hour % 12 == 0 ? 12 : local.hour % 12;
      final minute = local.minute.toString().padLeft(2, '0');
      final amPm = local.hour >= 12 ? 'PM' : 'AM';
      return '${local.day} ${months[local.month - 1]} • $hour:$minute $amPm';
    }
  }
  if (fallbackDate.isNotEmpty || fallbackTime.isNotEmpty) {
    return [fallbackDate, fallbackTime].where((value) => value.isNotEmpty).join(' • ');
  }
  return 'Schedule will be announced';
}
