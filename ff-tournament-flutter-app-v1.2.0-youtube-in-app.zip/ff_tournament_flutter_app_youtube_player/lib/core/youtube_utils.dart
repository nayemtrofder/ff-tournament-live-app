/// Utilities for safely using YouTube links returned by the WordPress API.
///
/// The app never guesses a video ID. A URL must be a valid YouTube watch,
/// short, live, shorts or embed URL, or an already supplied 11-character ID.
class YouTubeVideoRef {
  const YouTubeVideoRef._({required this.videoId});

  final String videoId;

  static final RegExp _idPattern = RegExp(r'^[A-Za-z0-9_-]{11}$');

  static YouTubeVideoRef? tryParse(String rawUrlOrId) {
    final raw = rawUrlOrId.trim();
    if (raw.isEmpty) return null;

    if (_idPattern.hasMatch(raw)) {
      return YouTubeVideoRef._(videoId: raw);
    }

    final uri = Uri.tryParse(raw);
    if (uri == null || uri.host.isEmpty) return null;

    final host = uri.host.toLowerCase().replaceFirst(RegExp(r'^www\.'), '');
    String? candidate;

    if (host == 'youtu.be') {
      if (uri.pathSegments.isNotEmpty) candidate = uri.pathSegments.first;
    } else if (host.endsWith('youtube.com') || host.endsWith('youtube-nocookie.com')) {
      if (uri.path == '/watch') {
        candidate = uri.queryParameters['v'];
      }

      if (candidate == null && uri.pathSegments.length >= 2) {
        final route = uri.pathSegments.first.toLowerCase();
        if (route == 'embed' || route == 'shorts' || route == 'live' || route == 'v') {
          candidate = uri.pathSegments[1];
        }
      }
    }

    if (candidate == null) return null;
    final cleaned = candidate.trim();
    return _idPattern.hasMatch(cleaned) ? YouTubeVideoRef._(videoId: cleaned) : null;
  }

  static bool isYouTubeUrlOrId(String value) => tryParse(value) != null;
}
