/// Build-time configuration only. Players never enter API URLs in the app.
///
/// Android build example:
/// flutter build appbundle --dart-define=FFTS_API_BASE_URL=https://example.com/wp-json/ffts-app/v1
class AppConfig {
  const AppConfig._();

  static const String apiBaseUrl = String.fromEnvironment(
    'FFTS_API_BASE_URL',
    defaultValue: '',
  );

  static bool get hasApiBaseUrl => apiBaseUrl.trim().isNotEmpty;
}
