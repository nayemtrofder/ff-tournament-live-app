import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'core/app_state.dart';
import 'core/app_theme.dart';
import 'screens/launch_screen.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final state = AppState();
  await state.initialize();
  runApp(FFTournamentApp(state: state));
}

class FFTournamentApp extends StatelessWidget {
  const FFTournamentApp({super.key, required this.state});
  final AppState state;

  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider.value(
      value: state,
      child: MaterialApp(
        title: 'FF Tournament',
        debugShowCheckedModeBanner: false,
        theme: buildAppTheme(),
        home: const LaunchScreen(),
      ),
    );
  }
}
