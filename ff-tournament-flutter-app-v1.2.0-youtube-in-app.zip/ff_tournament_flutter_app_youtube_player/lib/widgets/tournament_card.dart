import 'package:flutter/material.dart';

import '../core/app_theme.dart';
import '../core/formatters.dart';
import '../models/tournament.dart';
import 'common.dart';

class TournamentCard extends StatelessWidget {
  const TournamentCard({super.key, required this.tournament, this.onTap, this.compact = false});
  final Tournament tournament;
  final VoidCallback? onTap;
  final bool compact;

  @override
  Widget build(BuildContext context) {
    final image = tournament.thumbnailUrl;
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(22),
      child: Container(
        height: compact ? 154 : 185,
        clipBehavior: Clip.antiAlias,
        decoration: BoxDecoration(
          color: AppColors.surface,
          borderRadius: BorderRadius.circular(22),
          border: Border.all(color: tournament.isLive ? AppColors.red.withValues(alpha: .75) : AppColors.border),
        ),
        child: Stack(
          fit: StackFit.expand,
          children: [
            if (image.isNotEmpty)
              Image.network(image, fit: BoxFit.cover, errorBuilder: (_, __, ___) => const SizedBox.shrink()),
            DecoratedBox(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [
                    Colors.black.withValues(alpha: image.isNotEmpty ? .10 : .02),
                    AppColors.surface.withValues(alpha: .72),
                    AppColors.surface,
                  ],
                ),
              ),
            ),
            if (image.isEmpty)
              const Positioned(
                right: -18,
                top: -20,
                child: Icon(Icons.sports_esports_rounded, size: 150, color: AppColors.surfaceSoft),
              ),
            Padding(
              padding: const EdgeInsets.all(15),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      StatusBadge(status: tournament.statusLabel),
                      const Spacer(),
                      GoldPill(value: goldText(tournament.entryGold), compact: true),
                    ],
                  ),
                  const Spacer(),
                  Text(
                    tournament.title,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w900, letterSpacing: -.25),
                  ),
                  const SizedBox(height: 4),
                  Text('${tournament.mode.toUpperCase()} • ${conciseDate(tournament.startAt, tournament.matchDate, tournament.matchTime)}',
                      maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: AppColors.muted, fontSize: 12)),
                  const SizedBox(height: 10),
                  Row(
                    children: [
                      const Icon(Icons.workspace_premium_rounded, color: AppColors.gold, size: 17),
                      const SizedBox(width: 5),
                      Expanded(child: Text(tournament.prize.isNotEmpty ? tournament.prize : 'Prize announced soon', style: const TextStyle(color: AppColors.gold, fontWeight: FontWeight.w800))),
                      Text('${tournament.joined}/${tournament.slots}', style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 12)),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
