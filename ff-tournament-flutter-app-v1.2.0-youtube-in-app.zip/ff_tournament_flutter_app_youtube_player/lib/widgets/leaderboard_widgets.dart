import 'package:flutter/material.dart';

import '../core/app_theme.dart';
import '../models/tournament.dart';
import 'common.dart';

class LeaderboardPodium extends StatelessWidget {
  const LeaderboardPodium({super.key, required this.entries});
  final List<LeaderboardEntry> entries;

  @override
  Widget build(BuildContext context) {
    if (entries.isEmpty) return const SizedBox.shrink();
    final places = [
      _PodiumPlace(entry: entries.length > 1 ? entries[1] : null, place: 2, height: 96),
      _PodiumPlace(entry: entries.first, place: 1, height: 124),
      _PodiumPlace(entry: entries.length > 2 ? entries[2] : null, place: 3, height: 80),
    ];
    return SizedBox(
      height: 193,
      child: Row(crossAxisAlignment: CrossAxisAlignment.end, children: places.map((item) => Expanded(child: item)).toList()),
    );
  }
}

class _PodiumPlace extends StatelessWidget {
  const _PodiumPlace({required this.entry, required this.place, required this.height});
  final LeaderboardEntry? entry;
  final int place;
  final double height;

  @override
  Widget build(BuildContext context) {
    final accent = place == 1 ? AppColors.gold : place == 2 ? AppColors.cyan : AppColors.orange;
    if (entry == null) return const SizedBox.shrink();
    return Column(
      mainAxisAlignment: MainAxisAlignment.end,
      children: [
        if (place == 1) const Icon(Icons.workspace_premium_rounded, color: AppColors.gold, size: 25),
        NetworkAvatar(url: entry!.avatarUrl, name: entry!.name, radius: place == 1 ? 29 : 24),
        const SizedBox(height: 6),
        Text(entry!.name, maxLines: 1, overflow: TextOverflow.ellipsis, textAlign: TextAlign.center, style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w800)),
        const SizedBox(height: 5),
        Container(
          height: height,
          margin: const EdgeInsets.symmetric(horizontal: 5),
          alignment: Alignment.topCenter,
          padding: const EdgeInsets.only(top: 10),
          decoration: BoxDecoration(
            color: accent.withValues(alpha: .16),
            borderRadius: const BorderRadius.vertical(top: Radius.circular(14)),
            border: Border.all(color: accent.withValues(alpha: .55)),
          ),
          child: Column(
            children: [
              Text('#$place', style: TextStyle(color: accent, fontWeight: FontWeight.w900, fontSize: 20)),
              Text('${entry!.points.toStringAsFixed(0)} PTS', style: const TextStyle(color: AppColors.muted, fontWeight: FontWeight.w800, fontSize: 10)),
            ],
          ),
        ),
      ],
    );
  }
}

class LeaderboardList extends StatelessWidget {
  const LeaderboardList({super.key, required this.entries, this.limit});
  final List<LeaderboardEntry> entries;
  final int? limit;

  @override
  Widget build(BuildContext context) {
    final visible = limit == null ? entries : entries.take(limit!).toList();
    return SurfaceBox(
      padding: EdgeInsets.zero,
      child: Column(
        children: [
          const Padding(
            padding: EdgeInsets.fromLTRB(16, 12, 16, 10),
            child: Row(
              children: [
                SizedBox(width: 36, child: Text('RK', style: TextStyle(color: AppColors.muted, fontSize: 11, fontWeight: FontWeight.w800))),
                Expanded(child: Text('PLAYER', style: TextStyle(color: AppColors.muted, fontSize: 11, fontWeight: FontWeight.w800))),
                SizedBox(width: 44, child: Text('K', textAlign: TextAlign.center, style: TextStyle(color: AppColors.muted, fontSize: 11, fontWeight: FontWeight.w800))),
                SizedBox(width: 54, child: Text('PTS', textAlign: TextAlign.right, style: TextStyle(color: AppColors.muted, fontSize: 11, fontWeight: FontWeight.w800))),
              ],
            ),
          ),
          ...visible.map((entry) => _LeaderboardRow(entry: entry)),
        ],
      ),
    );
  }
}

class _LeaderboardRow extends StatelessWidget {
  const _LeaderboardRow({required this.entry});
  final LeaderboardEntry entry;

  @override
  Widget build(BuildContext context) {
    final highlight = entry.isMe;
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 9),
      decoration: BoxDecoration(
        color: highlight ? AppColors.orange.withValues(alpha: .10) : Colors.transparent,
        borderRadius: BorderRadius.circular(13),
        border: highlight ? Border.all(color: AppColors.orange.withValues(alpha: .45)) : null,
      ),
      child: Row(
        children: [
          SizedBox(width: 36, child: Text('#${entry.rank}', style: TextStyle(fontWeight: FontWeight.w900, color: entry.rank <= 3 ? AppColors.gold : AppColors.text))),
          NetworkAvatar(url: entry.avatarUrl, name: entry.name, radius: 17),
          const SizedBox(width: 9),
          Expanded(child: Text(entry.name, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w800))),
          SizedBox(width: 44, child: Text('${entry.kills}', textAlign: TextAlign.center, style: const TextStyle(color: AppColors.cyan, fontWeight: FontWeight.w900))),
          SizedBox(width: 54, child: Text(entry.points.toStringAsFixed(0), textAlign: TextAlign.right, style: const TextStyle(color: AppColors.gold, fontWeight: FontWeight.w900))),
        ],
      ),
    );
  }
}
