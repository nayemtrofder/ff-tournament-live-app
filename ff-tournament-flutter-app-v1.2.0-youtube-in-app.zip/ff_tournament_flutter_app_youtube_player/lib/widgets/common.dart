import 'package:flutter/material.dart';

import '../core/app_theme.dart';

class SurfaceBox extends StatelessWidget {
  const SurfaceBox({
    super.key,
    required this.child,
    this.padding = const EdgeInsets.all(16),
    this.margin,
    this.color,
    this.borderColor,
    this.radius = 20,
  });

  final Widget child;
  final EdgeInsetsGeometry padding;
  final EdgeInsetsGeometry? margin;
  final Color? color;
  final Color? borderColor;
  final double radius;

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: margin,
      padding: padding,
      decoration: BoxDecoration(
        color: color ?? AppColors.surface,
        borderRadius: BorderRadius.circular(radius),
        border: Border.all(color: borderColor ?? AppColors.border),
      ),
      child: child,
    );
  }
}

class PageLoading extends StatelessWidget {
  const PageLoading({super.key, this.label = 'Loading...'});
  final String label;

  @override
  Widget build(BuildContext context) => SizedBox(
        height: 230,
        child: Center(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const CircularProgressIndicator(color: AppColors.orange),
              const SizedBox(height: 12),
              Text(label, style: const TextStyle(color: AppColors.muted)),
            ],
          ),
        ),
      );
}

class ErrorPanel extends StatelessWidget {
  const ErrorPanel({super.key, required this.message, this.onRetry});
  final String message;
  final VoidCallback? onRetry;

  @override
  Widget build(BuildContext context) => SurfaceBox(
        color: AppColors.surfaceSoft,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Icon(Icons.cloud_off_rounded, color: AppColors.orange, size: 30),
            const SizedBox(height: 10),
            const Text('Data load করা যায়নি', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
            const SizedBox(height: 5),
            Text(message, style: const TextStyle(color: AppColors.muted, height: 1.4)),
            if (onRetry != null) ...[
              const SizedBox(height: 14),
              OutlinedButton.icon(
                onPressed: onRetry,
                icon: const Icon(Icons.refresh_rounded),
                label: const Text('আবার চেষ্টা করুন'),
              ),
            ],
          ],
        ),
      );
}

class SectionHeading extends StatelessWidget {
  const SectionHeading({super.key, required this.title, this.actionLabel, this.onAction});
  final String title;
  final String? actionLabel;
  final VoidCallback? onAction;

  @override
  Widget build(BuildContext context) => Row(
        children: [
          Expanded(
            child: Text(title, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w900, letterSpacing: -.2)),
          ),
          if (actionLabel != null)
            TextButton(
              onPressed: onAction,
              style: TextButton.styleFrom(foregroundColor: AppColors.orange),
              child: Text(actionLabel!, style: const TextStyle(fontWeight: FontWeight.w800)),
            ),
        ],
      );
}

class StatusBadge extends StatelessWidget {
  const StatusBadge({super.key, required this.status});
  final String status;

  @override
  Widget build(BuildContext context) {
    final live = status.toLowerCase().contains('live');
    final ended = status.toLowerCase().contains('completed') || status.toLowerCase().contains('ended');
    final cancelled = status.toLowerCase().contains('cancelled');
    final color = live
        ? AppColors.red
        : ended
            ? AppColors.green
            : cancelled
                ? AppColors.muted
                : AppColors.orange;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 6),
      decoration: BoxDecoration(
        color: color.withValues(alpha: .15),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: color.withValues(alpha: .55)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          if (live) ...[
            Container(width: 6, height: 6, decoration: const BoxDecoration(color: AppColors.red, shape: BoxShape.circle)),
            const SizedBox(width: 5),
          ],
          Text(status.toUpperCase(), style: TextStyle(color: color, fontWeight: FontWeight.w900, fontSize: 10, letterSpacing: .65)),
        ],
      ),
    );
  }
}

class GoldPill extends StatelessWidget {
  const GoldPill({super.key, required this.value, this.compact = false});
  final String value;
  final bool compact;

  @override
  Widget build(BuildContext context) => Container(
        padding: EdgeInsets.symmetric(horizontal: compact ? 8 : 10, vertical: compact ? 5 : 7),
        decoration: BoxDecoration(
          color: AppColors.gold.withValues(alpha: .12),
          border: Border.all(color: AppColors.gold.withValues(alpha: .55)),
          borderRadius: BorderRadius.circular(99),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.workspace_premium_rounded, color: AppColors.gold, size: 15),
            const SizedBox(width: 4),
            Text(value, style: const TextStyle(color: AppColors.gold, fontWeight: FontWeight.w900, fontSize: 12)),
          ],
        ),
      );
}

class NetworkAvatar extends StatelessWidget {
  const NetworkAvatar({super.key, required this.url, required this.name, this.radius = 20});
  final String url;
  final String name;
  final double radius;

  @override
  Widget build(BuildContext context) {
    final initials = name.trim().isEmpty
        ? '?'
        : name.trim().split(RegExp(r'\s+')).take(2).map((word) => word.isEmpty ? '' : word[0]).join().toUpperCase();
    return CircleAvatar(
      radius: radius,
      backgroundColor: AppColors.surfaceSoft,
      foregroundImage: url.isNotEmpty ? NetworkImage(url) : null,
      onForegroundImageError: (_, __) {},
      child: Text(initials, style: TextStyle(fontWeight: FontWeight.w900, fontSize: radius * .65, color: AppColors.cyan)),
    );
  }
}

class EmptyState extends StatelessWidget {
  const EmptyState({super.key, required this.icon, required this.title, required this.message, this.action});
  final IconData icon;
  final String title;
  final String message;
  final Widget? action;

  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 42),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              padding: const EdgeInsets.all(18),
              decoration: BoxDecoration(color: AppColors.surfaceSoft, borderRadius: BorderRadius.circular(22)),
              child: Icon(icon, color: AppColors.orange, size: 36),
            ),
            const SizedBox(height: 16),
            Text(title, textAlign: TextAlign.center, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 18)),
            const SizedBox(height: 7),
            Text(message, textAlign: TextAlign.center, style: const TextStyle(color: AppColors.muted, height: 1.45)),
            if (action != null) ...[const SizedBox(height: 18), action!],
          ],
        ),
      );
}

void showAppMessage(BuildContext context, String message, {bool error = false}) {
  ScaffoldMessenger.of(context)
    ..clearSnackBars()
    ..showSnackBar(SnackBar(
      backgroundColor: error ? AppColors.red : AppColors.surfaceSoft,
      content: Text(message),
      behavior: SnackBarBehavior.floating,
      margin: const EdgeInsets.all(16),
    ));
}
