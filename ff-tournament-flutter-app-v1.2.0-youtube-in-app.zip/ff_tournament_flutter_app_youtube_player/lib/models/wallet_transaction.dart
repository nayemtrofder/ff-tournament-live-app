class WalletTransaction {
  const WalletTransaction({
    required this.id,
    required this.type,
    required this.amount,
    required this.effectiveAmount,
    required this.direction,
    required this.matchId,
    required this.matchTitle,
    required this.description,
    required this.createdAt,
  });

  final int id;
  final String type;
  final double amount;
  final double effectiveAmount;
  final String direction;
  final int matchId;
  final String matchTitle;
  final String description;
  final String createdAt;

  factory WalletTransaction.fromJson(Map<String, dynamic> json) => WalletTransaction(
        id: _toInt(json['id']),
        type: (json['type'] ?? '').toString(),
        amount: _toDouble(json['amount']),
        effectiveAmount: _toDouble(json['effective_amount'] ?? json['amount']),
        direction: (json['direction'] ?? '').toString(),
        matchId: _toInt(json['match_id']),
        matchTitle: (json['match_title'] ?? '').toString(),
        description: (json['description'] ?? '').toString(),
        createdAt: (json['created_at'] ?? '').toString(),
      );
}

class WalletHistoryPayload {
  const WalletHistoryPayload({required this.items, required this.total});
  final List<WalletTransaction> items;
  final int total;

  factory WalletHistoryPayload.fromJson(Map<String, dynamic> json) {
    final rows = (json['items'] ?? json['history']) as List? ?? const [];
    return WalletHistoryPayload(
      items: rows.whereType<Map>().map((row) => WalletTransaction.fromJson(row.cast<String, dynamic>())).toList(),
      total: _toInt(json['total']),
    );
  }
}

int _toInt(dynamic value) => value is num ? value.toInt() : int.tryParse('$value') ?? 0;
double _toDouble(dynamic value) => value is num ? value.toDouble() : double.tryParse('$value') ?? 0;
