class AppNotification {
  const AppNotification({
    required this.id,
    required this.type,
    required this.title,
    required this.message,
    required this.isRead,
    required this.createdAt,
  });

  final int id;
  final String type;
  final String title;
  final String message;
  final bool isRead;
  final String createdAt;

  factory AppNotification.fromJson(Map<String, dynamic> json) => AppNotification(
        id: json['id'] is num ? (json['id'] as num).toInt() : int.tryParse('${json['id']}') ?? 0,
        type: (json['type'] ?? '').toString(),
        title: (json['title'] ?? '').toString(),
        message: (json['message'] ?? '').toString(),
        isRead: json['is_read'] == true,
        createdAt: (json['created_at'] ?? '').toString(),
      );
}

class NotificationsPayload {
  const NotificationsPayload({
    required this.items,
    required this.unreadCount,
    required this.total,
  });

  final List<AppNotification> items;
  final int unreadCount;
  final int total;

  factory NotificationsPayload.fromJson(Map<String, dynamic> json) {
    final rows = (json['items'] ?? json['notifications']) as List? ?? const [];
    return NotificationsPayload(
      items: rows.whereType<Map>().map((row) => AppNotification.fromJson(row.cast<String, dynamic>())).toList(),
      unreadCount: json['unread_count'] is num ? (json['unread_count'] as num).toInt() : int.tryParse('${json['unread_count']}') ?? 0,
      total: json['total'] is num ? (json['total'] as num).toInt() : int.tryParse('${json['total']}') ?? 0,
    );
  }
}
