class UserProfile {
  const UserProfile({
    required this.id,
    required this.name,
    required this.username,
    required this.ign,
    required this.ffUid,
    required this.avatarUrl,
    required this.guild,
    required this.server,
    required this.gameMode,
    required this.gold,
    required this.heldGold,
    required this.totalMatches,
    required this.totalWins,
    required this.totalKills,
    required this.rank,
    required this.profileComplete,
    required this.canStream,
    required this.profileEditUrl,
  });

  final int id;
  final String name;
  final String username;
  final String ign;
  final String ffUid;
  final String avatarUrl;
  final String guild;
  final String server;
  final String gameMode;
  final double gold;
  final double heldGold;
  final int totalMatches;
  final int totalWins;
  final int totalKills;
  final int rank;
  final bool profileComplete;
  final bool canStream;
  final String profileEditUrl;

  String get displayName => ign.isNotEmpty ? ign : name;

  factory UserProfile.fromJson(Map<String, dynamic> json) {
    final stats = (json['stats'] as Map?)?.cast<String, dynamic>() ?? const <String, dynamic>{};
    return UserProfile(
      id: _toInt(json['id']),
      name: _toString(json['name']).isNotEmpty ? _toString(json['name']) : _toString(json['display_name']),
      username: _toString(json['username']).isNotEmpty ? _toString(json['username']) : _toString(json['user_login']),
      ign: _toString(json['ign']),
      ffUid: _toString(json['ff_uid']),
      avatarUrl: _toString(json['profile_photo_url']).isNotEmpty ? _toString(json['profile_photo_url']) : _toString(json['avatar_url']),
      guild: _toString(json['guild']),
      server: _toString(json['server']),
      gameMode: _toString(json['game_mode']),
      gold: _toDouble(json['gold_balance'] ?? json['gold']),
      heldGold: _toDouble(json['held_gold']),
      totalMatches: _toInt(stats['total_matches'] ?? json['total_matches']),
      totalWins: _toInt(stats['total_wins'] ?? json['total_wins']),
      totalKills: _toInt(stats['total_kills'] ?? json['total_kills']),
      rank: _toInt(stats['rank'] ?? json['rank']),
      profileComplete: json['profile_complete'] == true,
      canStream: json['can_stream'] == true,
      profileEditUrl: _toString(json['profile_edit_url'] ?? json['profile_url']),
    );
  }
}

String _toString(dynamic value) => value?.toString() ?? '';
int _toInt(dynamic value) => value is num ? value.toInt() : int.tryParse('$value') ?? 0;
double _toDouble(dynamic value) => value is num ? value.toDouble() : double.tryParse('$value') ?? 0;
