import 'tournament.dart';

class LiveSession {
  const LiveSession({
    required this.isLive,
    required this.status,
    required this.title,
    required this.matchId,
    required this.match,
    required this.startedAt,
    required this.endsAt,
    required this.playbackUrl,
    required this.youtubeUrl,
    required this.facebookUrl,
    required this.appEnabled,
  });

  final bool isLive;
  final String status;
  final String title;
  final int matchId;
  final Tournament? match;
  final String startedAt;
  final String endsAt;
  final String playbackUrl;
  final String youtubeUrl;
  final String facebookUrl;
  final bool appEnabled;

  factory LiveSession.fromJson(Map<String, dynamic> json) {
    final matchJson = json['match'];
    return LiveSession(
      isLive: json['is_live'] == true || json['live'] == true,
      status: (json['status'] ?? 'offline').toString(),
      title: (json['title'] ?? '').toString(),
      matchId: json['match_id'] is num ? (json['match_id'] as num).toInt() : int.tryParse('${json['match_id']}') ?? 0,
      match: matchJson is Map ? Tournament.fromJson(matchJson.cast<String, dynamic>()) : null,
      startedAt: (json['started_at'] ?? '').toString(),
      endsAt: (json['ends_at'] ?? '').toString(),
      playbackUrl: (json['playback_url'] ?? '').toString(),
      youtubeUrl: (json['youtube_url'] ?? '').toString(),
      facebookUrl: (json['facebook_url'] ?? '').toString(),
      appEnabled: json['app_enabled'] == true,
    );
  }

  String get bestWatchUrl {
    if (playbackUrl.isNotEmpty) return playbackUrl;
    if (youtubeUrl.isNotEmpty) return youtubeUrl;
    return facebookUrl;
  }
}

class VideoItem {
  const VideoItem({
    required this.id,
    required this.title,
    required this.url,
    required this.thumbnailUrl,
    required this.publishedAt,
    required this.videoType,
  });

  final int id;
  final String title;
  final String url;
  final String thumbnailUrl;
  final String publishedAt;
  final String videoType;

  factory VideoItem.fromJson(Map<String, dynamic> json) => VideoItem(
        id: json['id'] is num ? (json['id'] as num).toInt() : int.tryParse('${json['id']}') ?? 0,
        title: (json['title'] ?? 'Tournament Highlight').toString(),
        url: (json['url'] ?? json['video_url'] ?? '').toString(),
        thumbnailUrl: (json['thumbnail_url'] ?? '').toString(),
        publishedAt: (json['published_at'] ?? '').toString(),
        videoType: (json['video_type'] ?? '').toString(),
      );
}
